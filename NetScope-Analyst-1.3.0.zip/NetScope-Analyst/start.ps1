$ErrorActionPreference = "Stop"
$appRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    $python = Get-Command py -ErrorAction SilentlyContinue
}
if (-not $python) {
    Write-Error "Python 3.11 or newer is required. Install Python, then run this script again."
}
Set-Location -LiteralPath $appRoot
& $python.Source "$appRoot\app.py"
