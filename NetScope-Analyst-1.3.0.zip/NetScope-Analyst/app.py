#!/usr/bin/env python3
"""NetScope Analyst launcher."""

from __future__ import annotations

import argparse
from pathlib import Path

from netscope.server import run_server


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Local multi-interface packet capture and scoped Nmap analysis workbench."
    )
    parser.add_argument("--host", default="127.0.0.1", help="Bind address (default: localhost)")
    parser.add_argument("--port", default=8765, type=int, help="HTTP port (default: 8765)")
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=Path(__file__).resolve().parent / "data",
        help="Session data directory",
    )
    parser.add_argument("--no-browser", action="store_true", help="Do not open the UI")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    run_server(
        host=args.host,
        port=args.port,
        data_dir=args.data_dir,
        open_browser=not args.no_browser,
    )


if __name__ == "__main__":
    main()
