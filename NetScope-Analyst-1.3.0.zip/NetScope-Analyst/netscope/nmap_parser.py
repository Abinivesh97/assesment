"""Nmap XML parsing into a stable report model."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
from typing import Any


DISCOVERY_PROFILES = {"automotive_discovery", "host_discovery"}


def _integer(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _script_element(node: ET.Element) -> dict[str, Any]:
    result: dict[str, Any] = {"id": node.get("id", ""), "output": node.get("output", "")}
    structured: list[dict[str, Any]] = []
    for child in list(node):
        structured.append(_xml_value(child))
    if structured:
        result["structured"] = structured
    return result


def _xml_value(node: ET.Element) -> dict[str, Any]:
    value: dict[str, Any] = {"type": node.tag}
    if node.get("key") is not None:
        value["key"] = node.get("key")
    if node.text and node.text.strip():
        value["value"] = node.text.strip()
    children = [_xml_value(child) for child in list(node)]
    if children:
        value["children"] = children
    return value


def parse_nmap_xml(path: str | Path) -> dict[str, Any]:
    xml_path = Path(path)
    try:
        root = ET.parse(xml_path).getroot()
    except (ET.ParseError, OSError) as exc:
        return {"path": str(xml_path), "parse_error": str(exc), "hosts": [], "scan": {}}

    scan: dict[str, Any] = {
        "scanner": root.get("scanner"),
        "args": root.get("args"),
        "start": root.get("start"),
        "startstr": root.get("startstr"),
        "version": root.get("version"),
    }
    scaninfos = [dict(node.attrib) for node in root.findall("scaninfo")]
    if scaninfos:
        # Preserve the original singular field for report-schema compatibility.
        scan["scaninfo"] = scaninfos[0]
        scan["scaninfos"] = scaninfos
    finished = root.find("./runstats/finished")
    hosts_stats = root.find("./runstats/hosts")
    if finished is not None:
        scan["finished"] = dict(finished.attrib)
    if hosts_stats is not None:
        scan["host_stats"] = dict(hosts_stats.attrib)

    hosts: list[dict[str, Any]] = []
    for host_node in root.findall("host"):
        status_node = host_node.find("status")
        addresses = [dict(node.attrib) for node in host_node.findall("address")]
        hostnames = [node.get("name", "") for node in host_node.findall("./hostnames/hostname") if node.get("name")]
        ports: list[dict[str, Any]] = []
        for port_node in host_node.findall("./ports/port"):
            state_node = port_node.find("state")
            service_node = port_node.find("service")
            scripts = [_script_element(script) for script in port_node.findall("script")]
            service = dict(service_node.attrib) if service_node is not None else {}
            if service_node is not None:
                cpes = [node.text.strip() for node in service_node.findall("cpe") if node.text and node.text.strip()]
                if cpes:
                    service["cpes"] = cpes
            port: dict[str, Any] = {
                "protocol": port_node.get("protocol"),
                "port": int(port_node.get("portid", "0")),
                "state": state_node.get("state") if state_node is not None else "unknown",
                "reason": state_node.get("reason") if state_node is not None else None,
                "reason_ttl": state_node.get("reason_ttl") if state_node is not None else None,
                "service": service,
                "scripts": scripts,
            }
            ports.append(port)
        extraports: list[dict[str, Any]] = []
        for extra_node in host_node.findall("./ports/extraports"):
            reasons = [dict(node.attrib) for node in extra_node.findall("extrareasons")]
            extraports.append(
                {
                    "state": extra_node.get("state", "unknown"),
                    "count": _integer(extra_node.get("count")),
                    "reasons": reasons,
                }
            )
        os_matches: list[dict[str, Any]] = []
        for os_node in host_node.findall("./os/osmatch"):
            os_matches.append(
                {
                    **dict(os_node.attrib),
                    "classes": [dict(child.attrib) for child in os_node.findall("osclass")],
                }
            )
        host_scripts = [_script_element(script) for script in host_node.findall("./hostscript/script")]
        uptime = host_node.find("uptime")
        distance = host_node.find("distance")
        hosts.append(
            {
                "status": dict(status_node.attrib) if status_node is not None else {},
                "addresses": addresses,
                "hostnames": hostnames,
                "ports": ports,
                "extraports": extraports,
                "timed_out": str(host_node.get("timedout", "")).strip().lower() == "true",
                "host_attributes": dict(host_node.attrib),
                "os_matches": os_matches,
                "host_scripts": host_scripts,
                "uptime": dict(uptime.attrib) if uptime is not None else None,
                "distance": dict(distance.attrib) if distance is not None else None,
                "starttime": host_node.get("starttime"),
                "endtime": host_node.get("endtime"),
            }
        )
    return {"path": str(xml_path), "hosts": hosts, "scan": scan}


def classify_nmap_result(
    parsed: dict[str, Any] | None,
    *,
    process_status: str | None = None,
    exit_code: int | None = None,
    profile: str | None = None,
) -> dict[str, Any]:
    """Classify Nmap evidence without equating process exit 0 with coverage.

    The four stable classifications are complete, partial-timeout,
    inconclusive, and failed. A successful Nmap process can still be partial
    when a host-level timeout is present, or inconclusive when targets were not
    observed up / no port-state results were produced.
    """

    result = parsed or {}
    hosts = list(result.get("hosts") or [])
    scan = result.get("scan") or {}
    finished = scan.get("finished") or {}
    host_stats = scan.get("host_stats") or {}
    status = str(process_status or "").strip().lower()
    failed_process_states = {"failed", "cancelled", "skipped", "interrupted"}
    timed_out_hosts = [host for host in hosts if host.get("timed_out") is True]
    up_hosts = [
        host
        for host in hosts
        if str((host.get("status") or {}).get("state", "")).strip().lower() == "up"
    ]
    hosts_total = _integer(host_stats.get("total"), len(hosts))
    hosts_up = _integer(host_stats.get("up"), len(up_hosts))
    hosts_down = _integer(host_stats.get("down"), max(0, hosts_total - hosts_up))
    scaninfos = list(scan.get("scaninfos") or ([] if not scan.get("scaninfo") else [scan.get("scaninfo")]))
    attempted_port_states_per_up_host = sum(
        max(0, _integer(row.get("numservices")))
        for row in scaninfos
        if isinstance(row, dict)
    )
    explicit_port_records = sum(len(host.get("ports") or []) for host in hosts)
    extraport_records = sum(len(host.get("extraports") or []) for host in hosts)
    extraport_count = sum(
        _integer(row.get("count"))
        for host in hosts
        for row in (host.get("extraports") or [])
    )
    explicit_port_state_counts = dict(
        Counter(
            str(port.get("state") or "unknown")
            for host in hosts
            for port in (host.get("ports") or [])
        )
    )
    extraport_state_counter: Counter[str] = Counter()
    for host in hosts:
        for row in host.get("extraports") or []:
            extraport_state_counter[str(row.get("state") or "unknown")] += _integer(row.get("count"))
    extraport_state_counts = dict(extraport_state_counter)
    port_state_coverage = []
    for host in up_hosts:
        observed = len(host.get("ports") or []) + sum(
            _integer(row.get("count")) for row in (host.get("extraports") or [])
        )
        port_state_coverage.append(
            {
                "expected": attempted_port_states_per_up_host,
                "observed": observed,
                "complete": bool(
                    attempted_port_states_per_up_host
                    and observed >= attempted_port_states_per_up_host
                ),
            }
        )
    base = {
        "classification": "failed",
        "reason": "unknown",
        "profile": profile,
        "process_status": process_status,
        "exit_code": exit_code,
        "nmap_exit": finished.get("exit"),
        "hosts_total": hosts_total,
        "hosts_up": hosts_up,
        "hosts_down": hosts_down,
        "timed_out_hosts": len(timed_out_hosts),
        "explicit_port_records": explicit_port_records,
        "extraport_records": extraport_records,
        "extraport_count": extraport_count,
        "attempted_port_states_per_up_host": attempted_port_states_per_up_host,
        "port_state_coverage": port_state_coverage,
        "explicit_port_state_counts": explicit_port_state_counts,
        "extraport_state_counts": extraport_state_counts,
    }

    if status in failed_process_states or (exit_code not in (None, 0)):
        return {**base, "classification": "failed", "reason": "process-failed-or-interrupted"}
    if result.get("parse_error"):
        return {**base, "classification": "failed", "reason": "xml-unavailable-or-invalid"}
    if not finished or str(finished.get("exit", "")).strip().lower() != "success":
        return {**base, "classification": "failed", "reason": "nmap-run-did-not-finish-successfully"}
    if timed_out_hosts:
        return {**base, "classification": "partial-timeout", "reason": "one-or-more-hosts-timed-out"}

    if profile in DISCOVERY_PROFILES:
        return {**base, "classification": "complete", "reason": "discovery-finished"}

    # A scaninfo element proves that Nmap attempted a port scan even when an
    # older caller does not supply the profile name. Discovery-only XML normally
    # has no scaninfo element.
    port_scan_attempted = bool(scan.get("scaninfos") or scan.get("scaninfo"))
    # Unknown/legacy discovery results retain successful-run compatibility.
    # Known/inferred port profiles require target responsiveness and actual
    # explicit/aggregate port-state evidence.
    if profile is None and not port_scan_attempted:
        return {**base, "classification": "complete", "reason": "nmap-run-finished"}
    if hosts_total and hosts_up == 0:
        return {**base, "classification": "inconclusive", "reason": "no-target-was-observed-up"}
    if hosts_down:
        return {**base, "classification": "inconclusive", "reason": "only-part-of-target-scope-was-observed-up"}
    up_hosts_with_port_evidence = sum(
        1
        for host in up_hosts
        if (host.get("ports") or []) or (host.get("extraports") or [])
    )
    if not up_hosts or up_hosts_with_port_evidence != len(up_hosts):
        return {**base, "classification": "inconclusive", "reason": "port-state-results-are-missing"}
    if attempted_port_states_per_up_host and any(
        row["observed"] < attempted_port_states_per_up_host
        for row in port_state_coverage
    ):
        return {
            **base,
            "classification": "inconclusive",
            "reason": "port-state-coverage-does-not-match-scaninfo",
        }
    return {**base, "classification": "complete", "reason": "port-state-results-complete-for-responsive-scope"}


def classify_nmap_outcome(
    parsed: dict[str, Any] | None,
    process_status: str | None = None,
    *,
    exit_code: int | None = None,
    profile: str | None = None,
) -> dict[str, Any]:
    """Return the report-facing scan outcome contract.

    Status is one of completed, partial, inconclusive, or failed. The original
    detailed classification and reason remain available for audit/report use.
    """

    detailed = classify_nmap_result(
        parsed,
        process_status=process_status,
        exit_code=exit_code,
        profile=profile,
    )
    status = {
        "complete": "completed",
        "partial-timeout": "partial",
        "inconclusive": "inconclusive",
        "failed": "failed",
    }[detailed["classification"]]
    if status == "completed":
        summary = "Nmap finished and returned complete evidence for the attempted scan scope."
    elif status == "partial":
        summary = (
            f"Nmap finished, but {detailed['timed_out_hosts']} host(s) reached the host timeout; "
            "port coverage is partial and absence of an open port is not a negative result."
        )
    elif status == "inconclusive":
        summary = (
            "Nmap finished, but target responsiveness or port-state evidence was insufficient "
            f"({detailed['reason']}); no closed/filtered conclusion should be inferred."
        )
    else:
        summary = (
            "Nmap execution or XML evidence did not finish successfully "
            f"({detailed['reason']})."
        )
    return {
        **detailed,
        "status": status,
        "complete": status == "completed",
        "summary": summary,
    }
