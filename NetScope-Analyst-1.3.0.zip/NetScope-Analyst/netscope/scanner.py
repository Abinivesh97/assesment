"""Allowlisted Nmap job construction and execution."""

from __future__ import annotations

import ipaddress
import math
import platform
import subprocess
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from .tools import CREATE_NO_WINDOW, list_interfaces
from .validation import (
    ValidationError,
    _automatic_protected_exclusions,
    _relevant_exclusions,
    _verify_selected_interface_routes,
)


SAFE_ENUMERATION_SCRIPTS = (
    "banner",
    "ssl-cert",
    "ssl-enum-ciphers",
    "http-security-headers",
    "ssh2-enum-algos",
    "smb2-security-mode",
    "rdp-enum-encryption",
    "ftp-anon",
    "dns-recursion",
)

CURATED_VULNERABILITY_SCRIPTS = (
    "ssl-heartbleed",
    "ssl-poodle",
    "smb-vuln-ms17-010",
    "rdp-vuln-ms12-020",
)

PROFILE_LABELS = {
    "automotive_discovery": "Automotive gentle discovery",
    "automotive_services": "Focused automotive services",
    "host_discovery": "Host discovery",
    "quick_tcp": "Quick TCP inventory",
    "standard_tcp": "TCP services and versions",
    "full_tcp": "Full TCP 1–65535",
    "full_tcp_services": "Full TCP + service versions",
    "quick_udp": "Top 100 UDP",
    "full_udp": "Full UDP 1–65535",
    "service_detection": "Service/version detection",
    "os_detection": "OS detection",
    "safe_enumeration": "Curated safe enumeration",
    "vulnerability_checks": "Curated vulnerability checks",
}
RAW_INTERFACE_PROFILES = {
    "automotive_discovery",
    "automotive_services",
    "host_discovery",
    "quick_udp",
    "full_udp",
    "os_detection",
}

# A maximum rate is a ceiling rather than a guaranteed rate. These estimates
# therefore describe an optimistic probe floor plus a conservative allowance;
# they are planning guardrails, not promises about wall-clock completion.
FULL_RANGE_PORTS = 65_535
MAX_EFFECTIVE_HOST_TIMEOUT_SECONDS = 86_400
FULL_PROFILE_ALLOWANCE = {
    "full_tcp": (1.25, 60),
    "full_tcp_services": (1.50, 300),
    "full_udp": (2.00, 300),
}
PROFILE_PHASE = {
    "automotive_discovery": 0,
    "host_discovery": 0,
    "automotive_services": 1,
    "quick_tcp": 2,
    "quick_udp": 2,
    "service_detection": 2,
    "standard_tcp": 2,
    "os_detection": 3,
    "safe_enumeration": 3,
    "vulnerability_checks": 3,
    "full_tcp": 4,
    "full_tcp_services": 4,
    "full_udp": 5,
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _focused_automotive_ports(expected_ports: list[int] | None, include_port_zero: bool) -> tuple[list[int], list[int]]:
    supplied = {
        int(port)
        for port in (expected_ports or [])
        if isinstance(port, int) and (0 if include_port_zero else 1) <= int(port) <= 65_535
    }
    # ISO 13400 DoIP uses TCP/UDP 13400; AUTOSAR SOME/IP-SD uses UDP 30490.
    # Project-specific application/NM ports are never guessed and only enter
    # this profile through the operator's expected-port baseline.
    tcp_ports = sorted({13_400, *supplied})
    udp_ports = sorted({13_400, 30_490, *supplied})
    return tcp_ports, udp_ports


def _profile_arguments(
    profile: str,
    include_port_zero: bool,
    expected_ports: list[int] | None = None,
) -> list[str]:
    full_range = "0-65535" if include_port_zero else "1-65535"
    if profile in ("automotive_discovery", "host_discovery"):
        return ["-sn"]
    if profile == "automotive_services":
        tcp_ports, udp_ports = _focused_automotive_ports(expected_ports, include_port_zero)
        port_spec = f"T:{','.join(map(str, tcp_ports))},U:{','.join(map(str, udp_ports))}"
        return ["-sT", "-sU", "-p", port_spec, "-sV", "--version-light"]
    if profile == "quick_tcp":
        return ["-sT", "--top-ports", "1000"]
    if profile == "standard_tcp":
        return ["-sT", "--top-ports", "1000", "-sV", "--version-light"]
    if profile == "full_tcp":
        return ["-sT", "-p", full_range]
    if profile == "full_tcp_services":
        return ["-sT", "-p", full_range, "-sV", "--version-light"]
    if profile == "quick_udp":
        return ["-sU", "--top-ports", "100"]
    if profile == "full_udp":
        return ["-sU", "-p", full_range]
    if profile == "service_detection":
        return ["-sT", "--top-ports", "100", "-sV", "--version-all"]
    if profile == "os_detection":
        return ["-O", "--osscan-limit"]
    if profile == "safe_enumeration":
        return ["-sT", "--top-ports", "1000", "-sV", "--version-light", "--script", ",".join(SAFE_ENUMERATION_SCRIPTS)]
    if profile == "vulnerability_checks":
        return ["-sT", "--top-ports", "1000", "-sV", "--version-light", "--script", ",".join(CURATED_VULNERABILITY_SCRIPTS)]
    raise ValueError(f"Unknown Nmap profile: {profile}")


def profile_feasibility(
    profile: str,
    configured_timeout_seconds: int,
    max_rate: int,
    max_retries: int,
    target_count: int = 1,
    include_port_zero: bool = False,
) -> dict[str, Any]:
    """Return stable, evidence-ready timeout planning metadata for a profile."""

    configured = max(1, int(configured_timeout_seconds))
    rate = max(1, int(max_rate))
    retries = max(0, int(max_retries))
    addresses = max(1, int(target_count))
    result: dict[str, Any] = {
        "configured_host_timeout_seconds": configured,
        "effective_host_timeout_seconds": configured,
        "timeout_auto_raised": False,
        "estimate_kind": "not-calculated",
        "estimated_probe_floor_seconds_per_host": None,
        "estimated_shared_rate_floor_seconds": None,
        "estimated_port_count_per_host": None,
        "recommended_host_timeout_seconds": configured,
        "estimate_capped": False,
        "status": "not-applicable",
        "target_address_count_before_exclusions": addresses,
        "note": "No full-range feasibility adjustment applies to this profile.",
    }
    allowance = FULL_PROFILE_ALLOWANCE.get(profile)
    if allowance is None:
        return result

    margin, overhead = allowance
    port_count = FULL_RANGE_PORTS + int(bool(include_port_zero))
    per_host_floor = (port_count * (retries + 1)) / rate
    shared_rate_floor = per_host_floor * addresses
    recommended = math.ceil((shared_rate_floor * margin) + overhead)
    effective = min(MAX_EFFECTIVE_HOST_TIMEOUT_SECONDS, max(configured, recommended))
    result.update(
        {
            "effective_host_timeout_seconds": effective,
            "timeout_auto_raised": effective > configured,
            "estimate_kind": "optimistic-max-rate-floor-with-conservative-allowance",
            "estimated_probe_floor_seconds_per_host": round(per_host_floor, 3),
            "estimated_shared_rate_floor_seconds": round(shared_rate_floor, 3),
            "estimated_port_count_per_host": port_count,
            "recommended_host_timeout_seconds": recommended,
            "estimate_capped": recommended > MAX_EFFECTIVE_HOST_TIMEOUT_SECONDS,
            "status": (
                "cap-limited"
                if recommended > MAX_EFFECTIVE_HOST_TIMEOUT_SECONDS
                else ("timeout-auto-raised" if effective > configured else "configured-sufficient")
            ),
            "note": (
                f"Estimate is based on {port_count:,} ports, retry allowance, the configured global maximum "
                "rate, selected-address count, and a profile-specific margin. Actual Nmap duration can "
                "be longer, especially for UDP, service probes, and rate-limited targets."
            ),
        }
    )
    return result


def estimate_scan_schedule_floor_seconds(
    jobs: list[dict[str, Any]],
    worker_count: int = 1,
) -> float:
    """Return an optimistic lower bound for indivisible jobs on a worker pool.

    Dividing total work by the worker count alone can produce a value shorter
    than the longest individual job. The maximum of both lower bounds remains
    safe while preserving the existing optimistic planning semantics.
    """

    floors: list[float] = []
    for job in jobs:
        value = job.get("estimated_minimum_seconds")
        if value is None:
            value = (job.get("timeout_feasibility") or {}).get(
                "estimated_shared_rate_floor_seconds"
            )
        try:
            floors.append(max(0.0, float(value or 0)))
        except (TypeError, ValueError):
            continue
    if not floors:
        return 0.0
    workers = max(1, int(worker_count))
    return max(max(floors), sum(floors) / workers)


def _target_family(target: str) -> int:
    return ipaddress.ip_network(target, strict=False).version


def _target_address_count(targets: list[str]) -> int:
    return sum(int(ipaddress.ip_network(target, strict=False).num_addresses) for target in targets)


def _proof_identity(proof: dict[str, Any]) -> tuple[str, str, str, str, str]:
    return (
        str(proof.get("target") or "").casefold(),
        str(proof.get("interface_id") or "").casefold(),
        str(proof.get("if_index") if proof.get("if_index") is not None else ""),
        str(proof.get("nmap_interface") or "").casefold(),
        str(proof.get("connected_prefix") or "").casefold(),
    )


def revalidate_pre_start_route(job: dict[str, Any]) -> dict[str, Any]:
    """Requery Windows route/interface state immediately before Nmap starts."""
    required = bool(job.get("automotive_mode") and job.get("bind_interface"))
    result: dict[str, Any] = {
        "required": required,
        "status": "not-required",
        "checked_at": utc_now(),
        "interface_id": job.get("interface_id"),
        "targets": list(job.get("targets", [])),
        "error": None,
    }
    if not required:
        return result
    if platform.system() != "Windows":
        result.update(
            {
                "status": "not-applicable",
                "note": "Immediate route requery is currently enforced on Windows automotive jobs.",
            }
        )
        return result

    persisted_proofs = list(job.get("route_verification", []))
    if not persisted_proofs:
        result.update(
            {
                "status": "failed",
                "error": "The persisted scan plan has no selected-interface route proof.",
            }
        )
        return result
    try:
        argv = job.get("argv", [])
        nmap_path = str(argv[0]) if argv else ""
        if not nmap_path:
            raise ValidationError("Nmap executable is missing from the scan plan")
        inventory = list_interfaces(None, nmap_path, None)
        if not inventory:
            raise ValidationError("Current Windows interface and route inventory is unavailable")
        expected_id = str(job.get("interface_id") or persisted_proofs[0].get("interface_id") or "")
        current_interface = next(
            (
                interface
                for interface in inventory
                if str(interface.get("id") or "").casefold() == expected_id.casefold()
            ),
            None,
        )
        if current_interface is None:
            raise ValidationError(f"Selected interface is no longer present: {expected_id}")
        if not current_interface.get("scan_ready"):
            raise ValidationError(
                f"Selected interface is no longer positively verified scan-ready: "
                f"{current_interface.get('name') or expected_id}"
            )

        observed_proofs = _verify_selected_interface_routes(
            list(job.get("targets", [])),
            current_interface,
            inventory,
        )
        persisted_identities = sorted(_proof_identity(proof) for proof in persisted_proofs)
        observed_identities = sorted(_proof_identity(proof) for proof in observed_proofs)
        if persisted_identities != observed_identities:
            raise ValidationError(
                "Selected-interface route proof changed after launch confirmation"
            )

        current_automatic, _ = _automatic_protected_exclusions(inventory)
        current_relevant = _relevant_exclusions(list(job.get("targets", [])), current_automatic)
        persisted_automatic = list(job.get("automatic_exclusions", []))
        if {value.casefold() for value in current_relevant} != {
            value.casefold() for value in persisted_automatic
        }:
            raise ValidationError(
                "Host/interface addresses or default gateways changed after launch confirmation"
            )

        result.update(
            {
                "status": "passed",
                "observed_route_verification": observed_proofs,
                "observed_automatic_exclusions": current_relevant,
                "observed_nmap_interface": current_interface.get("nmap_name"),
            }
        )
    except (OSError, ValueError, ValidationError) as exc:
        result.update(
            {
                "status": "failed",
                "error": f"Immediate route re-verification failed closed: {exc}",
            }
        )
    except Exception as exc:  # Defensive: inventory/parsing failures must never launch Nmap.
        result.update(
            {
                "status": "failed",
                "error": f"Immediate route re-verification was unavailable: {exc}",
            }
        )
    return result


def build_scan_jobs(nmap_path: str, config: dict[str, Any], session_dir: Path) -> list[dict[str, Any]]:
    scan = config["scan"]
    if not scan.get("enabled"):
        return []
    output_dir = session_dir / "nmap"
    jobs: list[dict[str, Any]] = []
    profile_order = {profile: position for position, profile in enumerate(scan.get("profiles", []))}
    for source_order, source in enumerate(config.get("sources", [])):
        interface = source.get("interface", {})
        for family in (4, 6):
            targets = [target for target in source.get("targets", []) if _target_family(target) == family]
            if not targets:
                continue
            scan_plan = source.get("scan_plan", {})
            manual_exclusions = [
                target
                for target in scan_plan.get("manual_exclusions", scan.get("exclusions", []))
                if _target_family(target) == family
            ]
            automatic_exclusions = [
                target
                for target in scan_plan.get("automatic_exclusions", scan.get("automatic_exclusions", []))
                if _target_family(target) == family
            ]
            exclusions = list(dict.fromkeys([*manual_exclusions, *automatic_exclusions]))
            route_verification = [
                proof
                for proof in scan_plan.get("route_verification", [])
                if _target_family(str(proof.get("target"))) == family
            ]
            for profile in scan.get("profiles", []):
                feasibility = profile_feasibility(
                    profile,
                    scan["host_timeout_seconds"],
                    scan["max_rate"],
                    scan["max_retries"],
                    max(1, _target_address_count(targets)),
                    include_port_zero=bool(scan.get("include_port_zero", False)),
                )
                base = f"{source['source_id']}-{profile}-ipv{family}"
                xml_path = output_dir / f"{base}.xml"
                normal_path = output_dir / f"{base}.nmap"
                stderr_path = output_dir / f"{base}.stderr.txt"
                argv = [
                    nmap_path,
                    "-n",
                    "--reason",
                    f"-T{scan['timing']}",
                    "--max-rate",
                    str(scan["max_rate"]),
                    "--max-retries",
                    str(scan["max_retries"]),
                    "--host-timeout",
                    f"{feasibility['effective_host_timeout_seconds']}s",
                    "--stats-every",
                    "10s",
                ]
                if family == 6:
                    argv.append("-6")
                if profile in ("safe_enumeration", "vulnerability_checks"):
                    argv.extend(["--script-timeout", f"{scan['script_timeout_seconds']}s"])
                argv.extend(
                    _profile_arguments(
                        profile,
                        scan.get("include_port_zero", False),
                        source.get("expected_ports", []),
                    )
                )
                binding_kind = (
                    "mixed"
                    if profile == "automotive_services"
                    else ("raw" if profile in RAW_INTERFACE_PROFILES else "os")
                )
                raw_interface_bound = bool(source.get("bind_interface") and binding_kind in {"raw", "mixed"})
                source_address = None
                if source.get("bind_interface"):
                    nmap_name = interface.get("nmap_name") or interface.get("name") or interface.get("capture_id")
                    if nmap_name and raw_interface_bound:
                        argv.extend(["-e", str(nmap_name)])
                        source_address = next(
                            (
                                row.get("address")
                                for row in interface.get("addresses", [])
                                if row.get("family") == f"IPv{family}" and row.get("address") and not str(row.get("address")).lower().startswith("fe80:")
                            ),
                            None,
                        )
                        if source_address:
                            argv.extend(["-S", str(source_address)])
                if exclusions:
                    argv.extend(["--exclude", ",".join(exclusions)])
                argv.extend(["-oX", str(xml_path), "-oN", str(normal_path)])
                argv.extend(targets)
                jobs.append(
                    {
                        "id": base,
                        "source_id": source["source_id"],
                        "source_alias": source.get("alias"),
                        "interface_id": source.get("interface_id"),
                        "interface_name": interface.get("name") or interface.get("capture_description"),
                        "if_index": interface.get("if_index"),
                        "nmap_interface": interface.get("nmap_name"),
                        "automotive_mode": bool(config.get("automotive_mode")),
                        "bind_interface": bool(source.get("bind_interface")),
                        "profile": profile,
                        "profile_label": PROFILE_LABELS.get(profile, profile),
                        "schedule_phase": PROFILE_PHASE.get(profile, 99),
                        "family": family,
                        "targets": targets,
                        "manual_exclusions": manual_exclusions,
                        "automatic_exclusions": automatic_exclusions,
                        "effective_exclusions": exclusions,
                        "route_verification": route_verification,
                        "pre_start_route_check": {
                            "required": bool(config.get("automotive_mode") and source.get("bind_interface")),
                            "status": "pending",
                            "checked_at": None,
                            "error": None,
                        },
                        "binding_mode": (
                            (
                                "mixed-raw-udp-and-validated-tcp-connect-route"
                                if binding_kind == "mixed"
                                else ("raw-interface-and-source" if source_address else "raw-interface")
                            )
                            if raw_interface_bound
                            else ("validated-direct-connected-os-route" if source.get("bind_interface") else "operating-system-route")
                        ),
                        "binding_note": (
                            (
                                (
                                    "The UDP component requested the selected Nmap interface and source address; "
                                    "the TCP-connect component follows the independently verified operating-system route."
                                )
                                if binding_kind == "mixed" and source_address
                                else (
                                    "The UDP component requested the selected Nmap interface; the TCP-connect component "
                                    "follows the independently verified operating-system route."
                                )
                                if binding_kind == "mixed"
                                else (
                                    "Raw-packet profile requested the selected Nmap interface and source address."
                                    if source_address
                                    else "Raw-packet profile requested the selected Nmap interface; Nmap selects the source address."
                                )
                            )
                            if raw_interface_bound
                            else (
                                "TCP connect/version/script sockets follow the operating-system route table; each target was verified against this interface's directly connected prefix without an equal-or-more-specific competing route."
                                if source.get("bind_interface")
                                else "No interface attribution is claimed; the operating system selected the route."
                            )
                        ),
                        "source_address": source_address,
                        "timeout_feasibility": feasibility,
                        "configured_host_timeout_seconds": feasibility["configured_host_timeout_seconds"],
                        "effective_host_timeout_seconds": feasibility["effective_host_timeout_seconds"],
                        "timeout_auto_raised": feasibility["timeout_auto_raised"],
                        "estimated_minimum_seconds": feasibility["estimated_shared_rate_floor_seconds"],
                        "target_count": source.get("target_count", 0),
                        "xml_path": str(xml_path),
                        "normal_path": str(normal_path),
                        "stderr_path": str(stderr_path),
                        "argv": argv,
                        "command_display": subprocess.list2cmdline(argv),
                        "status": "queued",
                        "started_at": None,
                        "process_started_at": None,
                        "ended_at": None,
                        "exit_code": None,
                        "error": None,
                        "_source_order": source_order,
                        "_profile_order": profile_order.get(profile, 99),
                    }
                )
    jobs.sort(
        key=lambda row: (
            int(row.get("schedule_phase", 99)),
            int(row.get("_profile_order", 99)),
            int(row.get("_source_order", 99)),
            int(row.get("family", 0)),
        )
    )
    for job in jobs:
        job.pop("_source_order", None)
        job.pop("_profile_order", None)
    return jobs


def run_scan_job(
    job: dict[str, Any],
    cancel_event: threading.Event,
    on_process: Callable[[str, subprocess.Popen[Any] | None], None],
    on_update: Callable[[dict[str, Any]], None],
) -> dict[str, Any]:
    result = {**job, "status": "running", "started_at": utc_now()}
    if cancel_event.is_set():
        result.update({"status": "cancelled", "ended_at": utc_now(), "error": "Cancelled before the job started"})
        on_update(result)
        return result
    on_update(result)
    stderr_path = Path(job["stderr_path"])
    stderr_path.parent.mkdir(parents=True, exist_ok=True)
    with stderr_path.open("w", encoding="utf-8", errors="replace") as stderr_handle:
        try:
            route_check = revalidate_pre_start_route(job)
            result["pre_start_route_check"] = route_check
            if route_check.get("status") == "failed":
                result.update(
                    {
                        "status": "failed",
                        "ended_at": utc_now(),
                        "error": str(route_check.get("error") or "Immediate route re-verification failed closed"),
                    }
                )
                stderr_handle.write(result["error"] + "\n")
                stderr_handle.flush()
                on_update(result)
                return result
            process_started_at = utc_now()
            process = subprocess.Popen(
                job["argv"],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=stderr_handle,
                creationflags=CREATE_NO_WINDOW,
            )
            # Keep lifecycle start and actual Nmap-process start separate. A
            # failed route check or a cancelled queued job has a lifecycle
            # start but sent no scan packets and must not create a provenance
            # correlation window.
            result["process_started_at"] = process_started_at
            on_process(job["id"], process)
            on_update(result)
            while True:
                code = process.poll()
                if code is not None:
                    result["exit_code"] = code
                    result["status"] = "completed" if code == 0 else "failed"
                    if code != 0:
                        result["error"] = f"Nmap exited with code {code}; see stderr artifact"
                    break
                if cancel_event.is_set():
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait(timeout=5)
                    result["exit_code"] = process.returncode
                    result["status"] = "cancelled"
                    result["error"] = "Cancelled by operator"
                    break
                time.sleep(0.25)
        except OSError as exc:
            result["status"] = "failed"
            result["error"] = str(exc)
        finally:
            on_process(job["id"], None)
    result["ended_at"] = utc_now()
    on_update(result)
    return result
