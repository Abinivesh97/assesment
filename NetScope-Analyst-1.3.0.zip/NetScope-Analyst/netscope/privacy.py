"""Privacy helpers for identifiers exposed by derived analysis artifacts."""

from __future__ import annotations

import hashlib
import hmac
import re
import secrets
from typing import Any


# ISO 3779 VINs are 17 characters and omit I, O, and Q.  Treat matching values
# as sensitive even when a malformed/test VIN might otherwise be harmless.
VIN_PATTERN = re.compile(r"(?<![A-Z0-9])[A-HJ-NPR-Z0-9]{17}(?![A-Z0-9])", re.IGNORECASE)
VIN_ALIAS_PATTERN = re.compile(r"^VIN-[A-F0-9]{12}$", re.IGNORECASE)
_PSEUDONYM_KEY = secrets.token_bytes(32)


def _token(kind: str, value: str, session_context: str, length: int = 12) -> str:
    normalized = value.strip().upper()
    message = f"{session_context}\0{kind}\0{normalized}".encode("utf-8", errors="replace")
    return hmac.new(_PSEUDONYM_KEY, message, hashlib.sha256).hexdigest()[:length].upper()


def stable_alias(kind: str, value: str, session_context: str, *, length: int = 10) -> str:
    """Return a non-reversible, process-local alias stable within one session."""

    prefix = re.sub(r"[^A-Z0-9]+", "", kind.upper()) or "NODE"
    return f"{prefix}-{_token(prefix, value, session_context, length)}"


def is_valid_vin_value(value: str) -> bool:
    """Return whether an explicit value has the reportable ISO-style VIN form."""

    return bool(VIN_PATTERN.fullmatch(str(value)))


def protect_vin_value(value: str, session_context: str, *, include_plaintext: bool = False) -> str:
    """Protect a value known to come from an explicit VIN semantic field.

    TShark can expose a non-text or invalid vehicle-announcement identifier as
    replacement characters.  The semantic field is still sensitive even when
    its representation does not match ISO 3779, so explicit VIN fields are
    pseudonymized as a whole instead of relying on pattern recognition.
    """

    text = str(value)
    if not text or VIN_ALIAS_PATTERN.fullmatch(text):
        return text
    if include_plaintext and is_valid_vin_value(text):
        return text
    return stable_alias("VIN", text, session_context, length=12)


def protect_vin_text(text: str, session_context: str, *, include_plaintext: bool = False) -> str:
    """Pseudonymize every VIN-like token unless the session explicitly opted in."""

    value = str(text)
    if include_plaintext:
        return value
    return VIN_PATTERN.sub(
        lambda match: protect_vin_value(
            match.group(0), session_context, include_plaintext=include_plaintext
        ),
        value,
    )


def sanitize_vin_data(
    value: Any,
    session_context: str,
    *,
    include_plaintext: bool = False,
    _explicit_vin: bool = False,
) -> Any:
    """Recursively copy JSON-shaped data while applying VIN protection."""

    if isinstance(value, str):
        if _explicit_vin:
            return protect_vin_value(
                value, session_context, include_plaintext=include_plaintext
            )
        return protect_vin_text(value, session_context, include_plaintext=include_plaintext)
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            rendered_key = protect_vin_text(
                str(key), session_context, include_plaintext=include_plaintext
            )
            normalized_key = re.sub(r"[^a-z0-9]+", "_", str(key).lower()).strip("_")
            explicit_vin = _explicit_vin or normalized_key in {
                "vin",
                "doip_vin",
                "doip_vins",
                "observed_vins",
            }
            result[rendered_key] = sanitize_vin_data(
                item,
                session_context,
                include_plaintext=include_plaintext,
                _explicit_vin=explicit_vin,
            )
        return result
    if isinstance(value, list):
        return [
            sanitize_vin_data(
                item,
                session_context,
                include_plaintext=include_plaintext,
                _explicit_vin=_explicit_vin,
            )
            for item in value
        ]
    if isinstance(value, tuple):
        return tuple(
            sanitize_vin_data(
                item,
                session_context,
                include_plaintext=include_plaintext,
                _explicit_vin=_explicit_vin,
            )
            for item in value
        )
    return value
