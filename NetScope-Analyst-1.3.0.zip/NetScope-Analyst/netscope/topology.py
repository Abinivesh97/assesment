"""Build a local topology model from derived network evidence.

IP, MAC, VLAN, protocol, and flow information is intentionally retained for
the analyst's local report. VIN-like vehicle identifiers remain protected by
the session's explicit privacy choice.
"""

from __future__ import annotations

import hashlib
import ipaddress
from typing import Any

from .privacy import protect_vin_value, stable_alias


AUTOMOTIVE_PROTOCOL_MARKERS = ("SOMEIP", "SOME/IP", "DOIP", "UDS")
ROLE_PRIORITY = {"unknown": 0, "switch": 1, "ecu": 2, "host": 3}
VLAN_BASES = {"configured-source", "configured-and-observed", "observed-8021q", "unattributable"}
LOGICAL_VLAN_BASES = {"configured-source", "configured-and-observed"}
TAGGED_VLAN_BASES = {"observed-8021q", "configured-and-observed"}
VLAN_ATTRIBUTION_SCOPES = {"full-source", "retained-membership", "unattributable"}
HOST_ORIGIN_TRAFFIC_CLASSES = {
    "scan-probe",
    "inferred-probe",
    "local-background",
    "local-stimulus",
    "local-origin-payload",
}


def _address_kind(value: str) -> str:
    candidate = str(value or "").split("%", 1)[0]
    try:
        return f"IPv{ipaddress.ip_address(candidate).version}"
    except ValueError:
        compact = candidate.replace("-", ":")
        if len(compact.split(":")) == 6:
            return "MAC"
    return "other"


def _normalize_endpoint(value: Any) -> str:
    candidate = str(value or "").strip()
    if not candidate:
        return ""
    unscoped, separator, scope = candidate.partition("%")
    try:
        normalized = ipaddress.ip_address(unscoped).compressed
        return f"{normalized}%{scope}" if separator else normalized
    except ValueError:
        compact = candidate.replace("-", ":")
        if len(compact.split(":")) == 6:
            return compact.upper()
    return candidate


def _split_observed_endpoint(value: Any) -> tuple[str, int | None]:
    """Return an address and optional port from legacy or structured display text."""

    candidate = str(value or "").strip()
    if not candidate:
        return "", None
    if candidate.startswith("[") and "]:" in candidate:
        address_text, port_text = candidate[1:].rsplit("]:", 1)
        try:
            return _normalize_endpoint(address_text), int(port_text)
        except ValueError:
            return _normalize_endpoint(candidate), None
    if ":" in candidate:
        address_text, port_text = candidate.rsplit(":", 1)
        if port_text.isdigit():
            try:
                ipaddress.ip_address(address_text)
                port = int(port_text)
                if 0 <= port <= 65535:
                    return _normalize_endpoint(address_text), port
            except ValueError:
                pass
    return _normalize_endpoint(candidate), None


def _conversation_endpoint(conversation: dict[str, Any], side: str) -> tuple[str, int | None]:
    address = _normalize_endpoint(conversation.get(f"endpoint_{side}_address"))
    raw_port = conversation.get(f"endpoint_{side}_port")
    if address:
        try:
            port = int(raw_port) if raw_port not in (None, "") else None
        except (TypeError, ValueError):
            port = None
        return address, port if port is not None and 0 <= port <= 65535 else None
    return _split_observed_endpoint(conversation.get(f"endpoint_{side}"))


def _valid_unicast_mac(value: Any) -> str:
    normalized = _normalize_endpoint(value)
    if _address_kind(normalized) != "MAC":
        return ""
    normalized = normalized.replace("-", ":").upper()
    if normalized in {"00:00:00:00:00:00", "FF:FF:FF:FF:FF:FF"}:
        return ""
    try:
        if int(normalized.split(":", 1)[0], 16) & 1:
            return ""
    except ValueError:
        return ""
    return normalized


def _node_id(identity: str, session_id: str) -> str:
    return stable_alias("NODE", identity, session_id, length=16).lower()


def _edge_id(left: str, right: str, relation: str) -> str:
    digest = hashlib.sha256(f"{left}\0{right}\0{relation}".encode()).hexdigest()[:16]
    return f"edge-{digest}"


def _automotive_protocol(protocol: Any) -> bool:
    normalized = str(protocol or "").upper().replace("-", "")
    return any(marker.replace("/", "") in normalized.replace("/", "") for marker in AUTOMOTIVE_PROTOCOL_MARKERS)


def build_topology(
    session_id: str,
    config: dict[str, Any],
    analyses: list[dict[str, Any]],
    assets: list[dict[str, Any]],
    services: list[dict[str, Any]],
) -> dict[str, Any]:
    """Create a map with stable aliases and local network identifiers."""

    include_vin = config.get("include_vin_in_reports") is True
    nodes: dict[str, dict[str, Any]] = {}
    endpoint_index: dict[tuple[str, str], str] = {}
    source_hosts: dict[str, str] = {}
    configured_vlans: dict[str, list[int]] = {}
    vlan_catalog: dict[int, dict[str, Any]] = {}
    edges: dict[tuple[str, str, str], dict[str, Any]] = {}

    def valid_vlan_id(value: Any) -> int | None:
        try:
            vlan_id = int(value)
        except (TypeError, ValueError):
            return None
        return vlan_id if 0 <= vlan_id <= 4095 else None

    def record_vlan(
        vlan_id: int,
        source_id: str,
        basis: str,
        *,
        confidence: str | None = None,
        tag_observed: bool = False,
    ) -> None:
        row = vlan_catalog.setdefault(
            vlan_id,
            {
                "source_ids": set(),
                "evidence_bases": set(),
                "confidence_levels": set(),
                "tag_observed": False,
            },
        )
        row["source_ids"].add(source_id)
        row["evidence_bases"].add(basis if basis in VLAN_BASES else "unattributable")
        if confidence in {"high", "medium", "low", "none"}:
            row["confidence_levels"].add(confidence)
        row["tag_observed"] = row["tag_observed"] or bool(tag_observed)

    def assign_node_vlan(node: dict[str, Any], vlan_id: int, basis: str) -> None:
        node["vlan_ids"].add(vlan_id)
        node["vlan_evidence"].setdefault(vlan_id, set()).add(basis)

    def ensure_node(identity: str, role: str, source_id: str | None, evidence: str) -> dict[str, Any]:
        node_id = _node_id(identity, session_id)
        node = nodes.setdefault(
            node_id,
            {
                "id": node_id,
                "_identity": identity,
                "role": role,
                "source_ids": set(),
                "vlan_ids": set(),
                "vlan_evidence": {},
                "address_kinds": set(),
                "addresses": set(),
                "mac_addresses": set(),
                "names": set(),
                "asset_ids": set(),
                "evidence": set(),
                "vehicle_identifiers": set(),
                "vehicle_identity_scope": None,
                "identity_bases": set(),
                "identity_confidence": "none",
            },
        )
        if ROLE_PRIORITY.get(role, 0) > ROLE_PRIORITY.get(node["role"], 0):
            node["role"] = role
        if source_id:
            node["source_ids"].add(str(source_id))
        node["evidence"].add(evidence)
        return node

    def index_endpoint(source_id: str, endpoint: Any, node: dict[str, Any]) -> None:
        value = _normalize_endpoint(endpoint)
        if not value:
            return
        endpoint_index[(source_id, value.casefold())] = node["id"]
        kind = _address_kind(value)
        node["address_kinds"].add(kind)
        if kind in {"IPv4", "IPv6"}:
            node["addresses"].add(value)
        elif kind == "MAC":
            node["mac_addresses"].add(value.replace("-", ":").upper())

    def endpoint_node(source_id: str, endpoint: Any, role: str = "unknown") -> dict[str, Any]:
        value = _normalize_endpoint(endpoint)
        if not value:
            raise ValueError("A topology endpoint is required")
        existing_id = endpoint_index.get((source_id, value.casefold()))
        if existing_id:
            node = nodes[existing_id]
            if ROLE_PRIORITY.get(role, 0) > ROLE_PRIORITY.get(node["role"], 0):
                node["role"] = role
            return node
        node = ensure_node(f"endpoint:{source_id}:{value.casefold()}", role, source_id, "traffic")
        index_endpoint(source_id, value, node)
        return node

    def add_edge(
        left_node: dict[str, Any],
        right_node: dict[str, Any],
        relation: str,
        source_id: str,
        *,
        protocol: Any = None,
        packets: int = 0,
        byte_count: int = 0,
        vlan_ids: list[Any] | None = None,
        vlan_basis: str = "observed-8021q",
        vlan_confidence: str | None = None,
        port: Any = None,
        ports: list[Any] | None = None,
        sampled: bool = False,
        payload_packets: int = 0,
        payload_bytes: int = 0,
        traffic_classes: list[Any] | None = None,
        tcp_syn_without_ack_packets: int = 0,
    ) -> dict[str, Any]:
        left, right = sorted((left_node["id"], right_node["id"]))
        key = (left, right, relation)
        edge = edges.setdefault(
            key,
            {
                "id": _edge_id(left, right, relation),
                "source": left,
                "target": right,
                "relation": relation,
                "source_ids": set(),
                "vlan_ids": set(),
                "vlan_evidence": {},
                "protocols": set(),
                "destination_ports": set(),
                "packets": 0,
                "bytes": 0,
                "sample_packets": 0,
                "payload_packets": 0,
                "payload_bytes": 0,
                "passive_remote_data_candidate_packets": 0,
                "passive_remote_data_candidate_bytes": 0,
                "host_origin_payload_packets": 0,
                "host_origin_payload_bytes": 0,
                "scan_response_payload_packets": 0,
                "scan_response_payload_bytes": 0,
                "traffic_classes": set(),
                "tcp_syn_without_ack_packets": 0,
            },
        )
        edge["source_ids"].add(source_id)
        if protocol:
            edge["protocols"].add(str(protocol))
        for raw_vlan_id in vlan_ids or []:
            vlan_id = valid_vlan_id(raw_vlan_id)
            if vlan_id is None:
                continue
            basis = vlan_basis if vlan_basis in VLAN_BASES else "unattributable"
            if basis == "unattributable":
                continue
            edge["vlan_ids"].add(vlan_id)
            edge["vlan_evidence"].setdefault(vlan_id, set()).add(basis)
            assign_node_vlan(left_node, vlan_id, basis)
            assign_node_vlan(right_node, vlan_id, basis)
            record_vlan(
                vlan_id,
                source_id,
                basis,
                confidence=vlan_confidence,
                tag_observed=basis == "observed-8021q",
            )
        for raw_port in [port, *(ports or [])]:
            if isinstance(raw_port, dict):
                raw_port = raw_port.get("port")
            if raw_port in (None, "", 0, "0"):
                continue
            try:
                edge["destination_ports"].add(int(raw_port))
            except (TypeError, ValueError):
                pass
        traffic_class_rows = traffic_classes or []
        class_names: set[str] = set()
        has_explicit_payload_split = False
        for item in traffic_class_rows:
            value = item.get("class") if isinstance(item, dict) else item
            if value:
                class_name = str(value)
                class_names.add(class_name)
                edge["traffic_classes"].add(class_name)
                if isinstance(item, dict) and (
                    "payload_packets" in item or "payload_bytes" in item
                ):
                    has_explicit_payload_split = True
                    class_payload_packets = max(0, int(item.get("payload_packets") or 0))
                    class_payload_bytes = max(0, int(item.get("payload_bytes") or 0))
                    if class_name == "remote-payload":
                        edge["passive_remote_data_candidate_packets"] += class_payload_packets
                        edge["passive_remote_data_candidate_bytes"] += class_payload_bytes
                    elif class_name in HOST_ORIGIN_TRAFFIC_CLASSES:
                        edge["host_origin_payload_packets"] += class_payload_packets
                        edge["host_origin_payload_bytes"] += class_payload_bytes
                    elif class_name == "scan-response":
                        edge["scan_response_payload_packets"] += class_payload_packets
                        edge["scan_response_payload_bytes"] += class_payload_bytes
        if not has_explicit_payload_split:
            if class_names == {"remote-payload"}:
                edge["passive_remote_data_candidate_packets"] += max(0, int(payload_packets or 0))
                edge["passive_remote_data_candidate_bytes"] += max(0, int(payload_bytes or 0))
            elif class_names and class_names.issubset(HOST_ORIGIN_TRAFFIC_CLASSES):
                edge["host_origin_payload_packets"] += max(0, int(payload_packets or 0))
                edge["host_origin_payload_bytes"] += max(0, int(payload_bytes or 0))
            elif class_names == {"scan-response"}:
                edge["scan_response_payload_packets"] += max(0, int(payload_packets or 0))
                edge["scan_response_payload_bytes"] += max(0, int(payload_bytes or 0))
        edge["payload_packets"] += max(0, int(payload_packets or 0))
        edge["payload_bytes"] += max(0, int(payload_bytes or 0))
        edge["tcp_syn_without_ack_packets"] += max(0, int(tcp_syn_without_ack_packets or 0))
        if sampled:
            edge["sample_packets"] += 1
        else:
            edge["packets"] += max(0, int(packets or 0))
            edge["bytes"] += max(0, int(byte_count or 0))
        return edge

    for source in config.get("sources", []):
        source_id = str(source.get("source_id") or "unknown-source")
        interface = source.get("interface") or {}
        configured_vlans[source_id] = list(
            dict.fromkeys(
                vlan_id
                for value in source.get("vlan_ids", [])
                if (vlan_id := valid_vlan_id(value)) is not None
            )
        )
        node = ensure_node(f"host:{source_id}", "host", source_id, "selected-interface")
        source_hosts[source_id] = node["id"]
        node["identity_bases"].add("selected-interface")
        node["identity_confidence"] = "high"
        node["names"].add(str(source.get("alias") or interface.get("name") or source_id))
        for address in interface.get("addresses", []):
            index_endpoint(source_id, address.get("address"), node)
        index_endpoint(source_id, interface.get("mac"), node)

    source_config_by_id = {
        str(source.get("source_id") or "unknown-source"): source
        for source in config.get("sources", [])
    }
    host_macs = {
        mac
        for source in config.get("sources", [])
        if (mac := _valid_unicast_mac((source.get("interface") or {}).get("mac")))
    }
    known_target_addresses: dict[str, set[str]] = {}
    for source_id, source in source_config_by_id.items():
        values = set()
        for row in source.get("known_targets", []):
            address = _normalize_endpoint(row.get("address") if isinstance(row, dict) else row)
            if _address_kind(address) in {"IPv4", "IPv6"}:
                values.add(address.casefold())
        known_target_addresses[source_id] = values

    binding_rows: list[tuple[str, dict[str, Any], str, str]] = []
    binding_macs_by_address: dict[tuple[str, str], set[str]] = {}
    for analysis_row in analyses:
        source_id = str(analysis_row.get("source_id") or "unknown-source")
        for binding in (analysis_row.get("analysis") or {}).get("l2_l3_bindings", []):
            if not isinstance(binding, dict):
                continue
            mac = _valid_unicast_mac(binding.get("mac_address"))
            address = _normalize_endpoint(binding.get("address"))
            if not mac or _address_kind(address) not in {"IPv4", "IPv6"}:
                continue
            binding_rows.append((source_id, binding, mac, address))
            binding_macs_by_address.setdefault((source_id, address.casefold()), set()).add(mac)

    identity_warnings: list[str] = []
    conflicting_bindings = {
        key for key, macs in binding_macs_by_address.items() if len(macs) > 1
    }
    for source_id, binding, mac, address in binding_rows:
        if (source_id, address.casefold()) in conflicting_bindings:
            warning = f"{source_id} address {address} was observed from multiple source MAC addresses; automatic identity correlation was skipped."
            if warning not in identity_warnings:
                identity_warnings.append(warning)
            continue
        existing_id = endpoint_index.get((source_id, address.casefold()))
        if mac in host_macs or existing_id == source_hosts.get(source_id):
            host_node = nodes.get(source_hosts.get(source_id, ""))
            if host_node:
                host_node["identity_bases"].add("selected-interface-address-or-mac")
                host_node["identity_confidence"] = "high"
                index_endpoint(source_id, address, host_node)
            continue
        protocols = [
            item.get("protocol") if isinstance(item, dict) else item
            for item in binding.get("protocols", [])
        ]
        role = (
            "ecu"
            if address.casefold() in known_target_addresses.get(source_id, set())
            or any(_automotive_protocol(value) for value in protocols)
            else "unknown"
        )
        node = ensure_node(f"observed-source-mac:{mac.casefold()}", role, source_id, "observed-source-mac-binding")
        node["mac_addresses"].add(mac)
        node["identity_bases"].add("observed-source-mac-to-source-ip")
        node["identity_confidence"] = "medium"
        if not existing_id:
            index_endpoint(source_id, address, node)
        elif existing_id == node["id"]:
            index_endpoint(source_id, address, node)
        for raw_vlan_id in binding.get("vlan_ids", []):
            vlan_id = valid_vlan_id(raw_vlan_id)
            if vlan_id is not None:
                assign_node_vlan(node, vlan_id, "observed-8021q")
                record_vlan(vlan_id, source_id, "observed-8021q", confidence="high", tag_observed=True)

    def service_is_doip(service: dict[str, Any]) -> bool:
        try:
            doip_port = int(service.get("port") or 0) == 13400
        except (TypeError, ValueError):
            doip_port = False
        return doip_port or "doip" in str(service.get("service") or "").lower()

    ecu_service_assets = {
        str(service.get("asset_id"))
        for service in services
        if service.get("asset_id") and service_is_doip(service)
    }
    for asset in assets:
        asset_sources = [str(item) for item in asset.get("sources", []) if item]
        if not asset_sources:
            asset_sources = ["unknown-source"]
        for source_id in asset_sources:
            if asset.get("eligible_for_ecu_findings") is False:
                role = "host"
            else:
                role = "ecu" if str(asset.get("id")) in ecu_service_assets else "unknown"
            candidate_values = [
                asset.get("primary_address"),
                *(address.get("addr") for address in asset.get("addresses", [])),
            ]
            existing_id = next(
                (
                    endpoint_index.get((source_id, _normalize_endpoint(value).casefold()))
                    for value in candidate_values
                    if value and endpoint_index.get((source_id, _normalize_endpoint(value).casefold()))
                ),
                None,
            )
            if existing_id:
                node = nodes[existing_id]
                if node["role"] != "host" and ROLE_PRIORITY.get(role, 0) > ROLE_PRIORITY.get(node["role"], 0):
                    node["role"] = role
                node["evidence"].add("active-scan")
            else:
                identity = f"asset:{source_id}:{asset.get('id') or asset.get('primary_address') or 'unknown'}"
                node = ensure_node(identity, role, source_id, "active-scan")
            if asset.get("id"):
                node["asset_ids"].add(str(asset["id"]))
            for hostname in asset.get("hostnames", []):
                if hostname:
                    node["names"].add(str(hostname))
            index_endpoint(source_id, asset.get("primary_address"), node)
            for address in asset.get("addresses", []):
                index_endpoint(source_id, address.get("addr"), node)

    for analysis_row in analyses:
        source_id = str(analysis_row.get("source_id") or "unknown-source")
        analysis = analysis_row.get("analysis") or {}
        attribution_rows = []
        for raw in analysis_row.get("vlan_attribution", []):
            if not isinstance(raw, dict):
                continue
            vlan_id = valid_vlan_id(raw.get("vlan_id"))
            if vlan_id is None:
                continue
            basis = str(raw.get("basis") or "unattributable")
            if basis not in VLAN_BASES:
                basis = "unattributable"
            confidence = str(raw.get("confidence") or "none").lower()
            attribution_scope = str(raw.get("attribution_scope") or "").lower()
            if attribution_scope not in VLAN_ATTRIBUTION_SCOPES:
                if basis == "configured-source":
                    attribution_scope = "full-source"
                elif basis == "configured-and-observed" and confidence == "medium":
                    attribution_scope = "full-source"
                elif basis in TAGGED_VLAN_BASES:
                    attribution_scope = "retained-membership"
                else:
                    attribution_scope = "unattributable"
            attribution = {
                "vlan_id": vlan_id,
                "basis": basis,
                "confidence": confidence,
                "tag_observed": raw.get("tag_observed") is True,
                "attribution_scope": attribution_scope,
            }
            attribution_rows.append(attribution)
            record_vlan(
                vlan_id,
                source_id,
                basis,
                confidence=attribution["confidence"],
                tag_observed=attribution["tag_observed"],
            )

        source_configured = configured_vlans.get(source_id, [])
        logical_attribution = None
        if len(source_configured) == 1:
            configured_vlan = source_configured[0]
            qualified = [
                row
                for row in attribution_rows
                if row["vlan_id"] == configured_vlan
                and row["basis"] in LOGICAL_VLAN_BASES
                and row["attribution_scope"] == "full-source"
            ]
            blocked = any(
                row["vlan_id"] == configured_vlan and row["basis"] == "unattributable"
                for row in attribution_rows
            )
            if len(qualified) == 1 and not blocked:
                logical_attribution = qualified[0]
                host_node = nodes.get(source_hosts.get(source_id, ""))
                if host_node:
                    assign_node_vlan(host_node, configured_vlan, logical_attribution["basis"])
                for node in nodes.values():
                    if source_id in node["source_ids"] and node["id"] != source_hosts.get(source_id):
                        assign_node_vlan(node, configured_vlan, logical_attribution["basis"])

        logical_vlan_ids = [logical_attribution["vlan_id"]] if logical_attribution else []
        logical_basis = logical_attribution["basis"] if logical_attribution else "unattributable"
        logical_confidence = logical_attribution["confidence"] if logical_attribution else None
        for conversation in analysis.get("conversations", []):
            protocol = conversation.get("protocol")
            endpoint_a_address, endpoint_a_port = _conversation_endpoint(conversation, "a")
            endpoint_b_address, endpoint_b_port = _conversation_endpoint(conversation, "b")
            if not endpoint_a_address or not endpoint_b_address:
                continue
            left_node = endpoint_node(source_id, endpoint_a_address)
            right_node = endpoint_node(source_id, endpoint_b_address)
            add_edge(
                left_node,
                right_node,
                "communicates-with",
                source_id,
                protocol=protocol,
                packets=int(conversation.get("packets") or 0),
                byte_count=int(conversation.get("bytes") or 0),
                vlan_ids=logical_vlan_ids,
                vlan_basis=logical_basis,
                vlan_confidence=logical_confidence,
                ports=conversation.get("destination_ports") or [endpoint_a_port, endpoint_b_port],
                payload_packets=int(conversation.get("payload_packets") or 0),
                payload_bytes=int(conversation.get("payload_bytes") or 0),
                traffic_classes=conversation.get("traffic_classes") or [],
                tcp_syn_without_ack_packets=int(conversation.get("tcp_syn_without_ack_packets") or 0),
            )
        observed_vins: set[str] = set()
        for sample in analysis.get("packet_sample", []):
            protocol = sample.get("protocol")
            if not sample.get("source") or not sample.get("destination"):
                continue
            source_node = endpoint_node(source_id, sample.get("source"))
            destination_node = endpoint_node(source_id, sample.get("destination"))
            retained_vlan_ids = []
            for raw_vlan_id in sample.get("vlan_stack") or []:
                sample_vlan_id = valid_vlan_id(raw_vlan_id)
                if sample_vlan_id is None:
                    continue
                if any(
                    row["vlan_id"] == sample_vlan_id
                    and row["basis"] in TAGGED_VLAN_BASES
                    and row["tag_observed"]
                    for row in attribution_rows
                ):
                    retained_vlan_ids.append(sample_vlan_id)
            sample_vlan_ids = retained_vlan_ids or logical_vlan_ids
            sample_vlan_basis = "observed-8021q" if retained_vlan_ids else logical_basis
            edge = add_edge(
                source_node,
                destination_node,
                "communicates-with",
                source_id,
                protocol=protocol,
                vlan_ids=sample_vlan_ids,
                vlan_basis=sample_vlan_basis,
                vlan_confidence="high" if retained_vlan_ids else logical_confidence,
                port=sample.get("destination_port"),
                sampled=True,
                traffic_classes=[sample.get("traffic_class")] if sample.get("traffic_class") else [],
            )
            vin = str((sample.get("info") or {}).get("doip_vin") or "").strip()
            if vin:
                observed_vins.add(vin)
                vehicle_node = source_node
                host_id = source_hosts.get(source_id)
                if vehicle_node["id"] == host_id and destination_node["id"] != host_id:
                    vehicle_node = destination_node
                if vehicle_node["role"] != "host":
                    vehicle_node["role"] = "ecu"
                protected = protect_vin_value(vin, session_id, include_plaintext=include_vin)
                vehicle_node["vehicle_identifiers"].add(protected)
                vehicle_node["vehicle_identity_scope"] = "endpoint"
                vehicle_node["evidence"].add("doip-vehicle-identification")
                edge["protocols"].add("DoIP vehicle identification")

        attribution_by_vlan = {row["vlan_id"]: row for row in attribution_rows}
        for vlan_view in analysis_row.get("vlan_views", []):
            if not isinstance(vlan_view, dict):
                continue
            view_vlan_id = valid_vlan_id(vlan_view.get("vlan_id"))
            attribution = attribution_by_vlan.get(view_vlan_id) if view_vlan_id is not None else None
            if not attribution or not attribution["tag_observed"]:
                continue
            if attribution["basis"] == "configured-and-observed" and attribution["confidence"] != "high":
                continue
            if attribution["basis"] not in TAGGED_VLAN_BASES:
                continue
            view_analysis = vlan_view.get("analysis") or {}
            for conversation in view_analysis.get("conversations", []):
                endpoint_a_address, _ = _conversation_endpoint(conversation, "a")
                endpoint_b_address, _ = _conversation_endpoint(conversation, "b")
                if not endpoint_a_address or not endpoint_b_address:
                    continue
                left_node = endpoint_node(source_id, endpoint_a_address)
                right_node = endpoint_node(source_id, endpoint_b_address)
                add_edge(
                    left_node,
                    right_node,
                    "communicates-with",
                    source_id,
                    protocol=conversation.get("protocol"),
                    vlan_ids=[view_vlan_id],
                    vlan_basis="observed-8021q",
                    vlan_confidence=attribution["confidence"],
                    traffic_classes=conversation.get("traffic_classes") or [],
                )
        aggregate_vins = [
            str(item.get("value") or "").strip()
            for item in (analysis.get("automotive") or {}).get("doip_vins", [])
            if str(item.get("value") or "").strip()
        ]
        for vin in aggregate_vins:
            if vin in observed_vins:
                continue
            protected = protect_vin_value(vin, session_id, include_plaintext=include_vin)
            vehicle_node = ensure_node(
                f"doip-vehicle-unresolved:{source_id}:{protected}",
                "ecu",
                source_id,
                "doip-vehicle-identification-source-only",
            )
            vehicle_node["vehicle_identifiers"].add(protected)
            vehicle_node["vehicle_identity_scope"] = "source-only"
            vehicle_node["evidence"].add("doip-vehicle-identification-source-only")
        for neighbor in analysis.get("lldp_neighbors", []):
            raw_neighbor = str(neighbor.get("neighbor") or "").strip()
            if not raw_neighbor:
                continue
            switch_node = ensure_node(f"lldp:{source_id}:{raw_neighbor}", "switch", source_id, "lldp")
            host_node = nodes.get(source_hosts.get(source_id, ""))
            if host_node:
                add_edge(
                    host_node,
                    switch_node,
                    "observed-lldp-neighbor",
                    source_id,
                    protocol="LLDP",
                    packets=int(neighbor.get("count") or 0),
                )

    rendered_nodes: list[dict[str, Any]] = []
    for node in nodes.values():
        role = node["role"]
        prefix = {"host": "HOST", "ecu": "ECU", "switch": "SWITCH", "unknown": "NODE"}.get(role, "NODE")
        rendered = {
            "id": node["id"],
            "alias": stable_alias(prefix, node["_identity"], session_id),
            "role": role,
            "source_ids": sorted(node["source_ids"]),
            "vlan_ids": sorted(node["vlan_ids"]),
            "vlan_evidence": [
                {"vlan_id": vlan_id, "bases": sorted(bases)}
                for vlan_id, bases in sorted(node["vlan_evidence"].items())
            ],
            "address_kinds": sorted(kind for kind in node["address_kinds"] if kind != "other"),
            "addresses": sorted(node["addresses"]),
            "mac_addresses": sorted(node["mac_addresses"]),
            "names": sorted(node["names"]),
            "asset_ids": sorted(node["asset_ids"]),
            "evidence": sorted(node["evidence"]),
            "vehicle_identity_scope": node["vehicle_identity_scope"],
            "identity_bases": sorted(node["identity_bases"]),
            "identity_confidence": node["identity_confidence"],
        }
        identifiers = sorted(node["vehicle_identifiers"])
        if identifiers:
            rendered["observed_vins" if include_vin else "vehicle_aliases"] = identifiers
        rendered_nodes.append(rendered)
    rendered_nodes.sort(key=lambda item: (item["role"], item["alias"]))

    rendered_edges = []
    for edge in edges.values():
        traffic_classes = sorted(edge["traffic_classes"])
        automotive_edge = any(_automotive_protocol(value) for value in edge["protocols"])
        noise_classes = {
            "scan-probe",
            "scan-response",
            "inferred-probe",
            "local-background",
            "local-stimulus",
            "local-origin-payload",
        }
        only_noise = bool(traffic_classes) and set(traffic_classes).issubset(noise_classes)
        low_signal_control = (
            edge["relation"] == "communicates-with"
            and edge["payload_packets"] == 0
            and edge["packets"] <= 2
            and not automotive_edge
        )
        default_visible = not only_noise and not low_signal_control
        suppression_reason = None
        if only_noise:
            suppression_reason = "scan-or-local-host-noise"
        elif low_signal_control:
            suppression_reason = "low-signal-zero-payload-control"
        rendered_edges.append(
            {
                "id": edge["id"],
                "source": edge["source"],
                "target": edge["target"],
                "relation": edge["relation"],
                "source_ids": sorted(edge["source_ids"]),
                "vlan_ids": sorted(edge["vlan_ids"]),
                "vlan_evidence": [
                    {"vlan_id": vlan_id, "bases": sorted(bases)}
                    for vlan_id, bases in sorted(edge["vlan_evidence"].items())
                ],
                "protocols": sorted(edge["protocols"]),
                "destination_ports": sorted(edge["destination_ports"]),
                "packets": edge["packets"],
                "bytes": edge["bytes"],
                "sample_packets": edge["sample_packets"],
                "payload_packets": edge["payload_packets"],
                "payload_bytes": edge["payload_bytes"],
                "passive_remote_data_candidate_packets": edge["passive_remote_data_candidate_packets"],
                "passive_remote_data_candidate_bytes": edge["passive_remote_data_candidate_bytes"],
                "host_origin_payload_packets": edge["host_origin_payload_packets"],
                "host_origin_payload_bytes": edge["host_origin_payload_bytes"],
                "scan_response_payload_packets": edge["scan_response_payload_packets"],
                "scan_response_payload_bytes": edge["scan_response_payload_bytes"],
                "traffic_classes": traffic_classes,
                "tcp_syn_without_ack_packets": edge["tcp_syn_without_ack_packets"],
                "default_visible": default_visible,
                "suppression_reason": suppression_reason,
            }
        )
    rendered_edges.sort(key=lambda item: item["id"])

    visible_edge_ids = {row["id"] for row in rendered_edges if row["default_visible"]}
    visible_node_ids = {
        endpoint
        for row in rendered_edges
        if row["default_visible"]
        for endpoint in (row["source"], row["target"])
    }
    for node in rendered_nodes:
        # A role inferred from packets is not independent evidence. In
        # particular, an ECU-role endpoint whose only incident relations were
        # suppressed scan/local-noise edges must not remain as an orphan in the
        # default view. Selected host/switch context, active inventory assets,
        # and vehicle-identity evidence can stand alone.
        keep_by_independent_context = (
            node["role"] in {"host", "switch"}
            or bool(node["asset_ids"])
            or bool(node.get("observed_vins") or node.get("vehicle_aliases"))
        )
        node["default_visible"] = keep_by_independent_context or node["id"] in visible_node_ids
        node["suppression_reason"] = None if node["default_visible"] else "only-suppressed-traffic"
    suppression_counts: dict[str, int] = {}
    for row in rendered_edges:
        reason = row.get("suppression_reason")
        if reason:
            suppression_counts[reason] = suppression_counts.get(reason, 0) + 1

    vlans = [
        {
            "vlan_id": vlan_id,
            "alias": f"VLAN {vlan_id}",
            "source_ids": sorted(row["source_ids"]),
            "evidence_bases": sorted(row["evidence_bases"]),
            "confidence_levels": sorted(row["confidence_levels"]),
            "tag_observed": row["tag_observed"],
        }
        for vlan_id, row in vlan_catalog.items()
    ]
    vlans.sort(key=lambda item: item["vlan_id"])
    return {
        "schema_version": "1.3",
        "privacy_mode": "explicit-local-vin" if include_vin else "session-pseudonymous",
        "nodes": rendered_nodes,
        "edges": rendered_edges,
        "vlans": vlans,
        "default_view": {
            "node_ids": [row["id"] for row in rendered_nodes if row["default_visible"]],
            "edge_ids": sorted(visible_edge_ids),
            "suppressed_node_count": len([row for row in rendered_nodes if not row["default_visible"]]),
            "suppressed_edge_count": len([row for row in rendered_edges if not row["default_visible"]]),
            "suppression_reasons": suppression_counts,
            "note": "The default security view suppresses scan-correlated, inferred-probe, local-host payload/background/stimulus, low-signal zero-payload edges, and endpoint nodes supported only by those hidden relations. Full nodes and edges remain in this topology object and evidence exports.",
        },
        "identity_warnings": identity_warnings,
        "limitations": [
            "Node aliases are stable within this session. IP and MAC identifiers are retained because this is a local analyst report.",
            "Roles are inferred from selected host interfaces, DoIP/SOME-IP/UDS evidence, LLDP, and service observations and require analyst confirmation.",
            "Every topology VLAN assignment carries an evidence basis. configured-source is logical source attribution, not proof that an 802.1Q tag was retained.",
            "Retained 802.1Q membership views can overlap for QinQ frames; multi-configured or unattributable untagged traffic is never assigned by guesswork.",
            "A DoIP VIN without retained endpoint-level packet evidence remains a source-level unresolved identity and is never attached to an exact asset finding.",
            "A repeated unicast source MAC across VLANs is grouped as one L2 identity cluster with medium confidence; bridges, proxies, or duplicated MACs can invalidate device-level identity and require analyst confirmation.",
            "Default-view suppression changes presentation only. Full packet evidence, analysis rows, topology nodes, and topology edges remain retained.",
        ],
    }


def link_findings_to_topology(findings: list[dict[str, Any]], topology: dict[str, Any]) -> list[dict[str, Any]]:
    """Attach findings to aliased topology nodes without changing risk meaning."""

    nodes = topology.get("nodes", [])
    result = []
    for finding in findings:
        linked = []
        exact_linked = []
        asset_ids = {str(value) for value in finding.get("asset_ids", [])}
        node_ids = {str(value) for value in finding.get("topology_node_ids", [])}
        source_ids = {str(value) for value in finding.get("source_ids", [])}
        if asset_ids or node_ids:
            exact_linked = [
                node
                for node in nodes
                if (
                    node.get("id") in node_ids
                    or asset_ids & set(node.get("asset_ids", []))
                )
                and (not source_ids or source_ids & set(node.get("source_ids", [])))
            ]
            linked = exact_linked
        if not linked and source_ids:
            candidates = [node for node in nodes if source_ids & set(node.get("source_ids", []))]
            linked = [node for node in candidates if node.get("role") in {"ecu", "unknown"}] or candidates
        copied = dict(finding)
        copied["topology_node_ids"] = sorted({node["id"] for node in linked})
        copied["topology_aliases"] = sorted({node["alias"] for node in linked})
        copied["vehicle_context"] = sorted(
            {
                identifier
                for node in exact_linked
                if node.get("vehicle_identity_scope") == "endpoint"
                for identifier in (node.get("observed_vins") or node.get("vehicle_aliases") or [])
            }
        )
        result.append(copied)
    return result
