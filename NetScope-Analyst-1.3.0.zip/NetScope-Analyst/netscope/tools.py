"""External-tool discovery and network-interface inventory."""

from __future__ import annotations

import ipaddress
import json
import os
import platform
import re
import shutil
import socket
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


@dataclass(frozen=True)
class ToolInfo:
    name: str
    path: str | None
    version: str | None
    available: bool

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


WINDOWS_CANDIDATES = {
    "tshark": [r"C:\Program Files\Wireshark\tshark.exe"],
    "dumpcap": [r"C:\Program Files\Wireshark\dumpcap.exe"],
    "capinfos": [r"C:\Program Files\Wireshark\capinfos.exe"],
    "editcap": [r"C:\Program Files\Wireshark\editcap.exe"],
    "mergecap": [r"C:\Program Files\Wireshark\mergecap.exe"],
    "nmap": [r"C:\Program Files (x86)\Nmap\nmap.exe", r"C:\Program Files\Nmap\nmap.exe"],
}


def _run_text(argv: list[str], timeout: int = 10) -> tuple[int, str, str]:
    try:
        completed = subprocess.run(
            argv,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            check=False,
            creationflags=CREATE_NO_WINDOW,
        )
        return completed.returncode, completed.stdout, completed.stderr
    except (OSError, subprocess.TimeoutExpired) as exc:
        return 127, "", str(exc)


def find_tool(name: str) -> str | None:
    env_name = f"NETSCOPE_{name.upper()}"
    configured = os.environ.get(env_name)
    if configured and Path(configured).is_file():
        return str(Path(configured).resolve())
    discovered = shutil.which(name)
    if discovered:
        return str(Path(discovered).resolve())
    if platform.system() == "Windows":
        for candidate in WINDOWS_CANDIDATES.get(name, []):
            if Path(candidate).is_file():
                return candidate
    return None


def tool_version(name: str, path: str | None) -> str | None:
    if not path:
        return None
    code, stdout, stderr = _run_text([path, "--version"], timeout=6)
    if code not in (0, 1):
        return None
    first = (stdout or stderr).strip().splitlines()
    return first[0][:240] if first else None


def detect_tools() -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for name in ("tshark", "dumpcap", "capinfos", "editcap", "mergecap", "nmap"):
        path = find_tool(name)
        result[name] = ToolInfo(name, path, tool_version(name, path), bool(path)).to_dict()
    return result


_CAPTURE_LINE = re.compile(r"^\s*(\d+)\.\s+(.+?)\s*$")
_GUID = re.compile(r"\{([0-9a-fA-F-]{36})\}")


def parse_capture_interfaces(output: str) -> list[dict[str, Any]]:
    interfaces: list[dict[str, Any]] = []
    for line in output.splitlines():
        match = _CAPTURE_LINE.match(line)
        if not match:
            continue
        raw = match.group(2).strip()
        capture_id = raw
        description = raw
        if raw.endswith(")") and " (" in raw:
            capture_id, description = raw.rsplit(" (", 1)
            description = description[:-1].strip()
        guid_match = _GUID.search(capture_id)
        interfaces.append(
            {
                "capture_index": int(match.group(1)),
                "capture_id": capture_id.strip(),
                "capture_description": description or capture_id.strip(),
                "guid": guid_match.group(1).lower() if guid_match else None,
                "capture_ready": True,
                "provider": "tshark",
            }
        )
    return interfaces


def parse_nmap_interface_map(output: str) -> dict[str, str]:
    result: dict[str, str] = {}
    in_windows_devices = False
    for line in output.splitlines():
        stripped = line.strip()
        if stripped == "DEV    WINDEVICE":
            in_windows_devices = True
            continue
        if in_windows_devices and (not stripped or stripped.startswith("*")):
            if result:
                break
            continue
        if not in_windows_devices:
            continue
        match = re.match(r"^(\S+)\s+(\\Device\\NPF_\S+)\s*$", stripped, re.IGNORECASE)
        if match and match.group(1) != "<none>":
            result[match.group(2).lower()] = match.group(1)
    return result


def _windows_adapters() -> list[dict[str, Any]]:
    powershell = shutil.which("powershell") or shutil.which("pwsh")
    if not powershell:
        return []
    script = r"""
$items = @(Get-NetAdapter -IncludeHidden -ErrorAction SilentlyContinue | ForEach-Object {
  $adapter = $_
  $addresses = @(Get-NetIPAddress -InterfaceIndex $adapter.ifIndex -ErrorAction SilentlyContinue | Where-Object {
    $_.AddressState -ne 'Invalid'
  } | ForEach-Object {
    [PSCustomObject]@{
      address = $_.IPAddress
      family = if ($_.AddressFamily -eq 2 -or $_.AddressFamily -eq 'IPv4') { 'IPv4' } else { 'IPv6' }
      prefix_length = [int]$_.PrefixLength
      state = [string]$_.AddressState
    }
  })
  $ipConfig = Get-NetIPConfiguration -InterfaceIndex $adapter.ifIndex -ErrorAction SilentlyContinue
  $routes = @(Get-NetRoute -InterfaceIndex $adapter.ifIndex -ErrorAction SilentlyContinue | Where-Object {
    ([string]$_.State) -notin @('Invalid', 'Unreachable')
  } | ForEach-Object {
    [PSCustomObject]@{
      destination_prefix = [string]$_.DestinationPrefix
      next_hop = [string]$_.NextHop
      route_metric = [int]$_.RouteMetric
    }
  })
  [PSCustomObject]@{
    name = [string]$adapter.Name
    description = [string]$adapter.InterfaceDescription
    guid = ([string]$adapter.InterfaceGuid).Trim('{}').ToLowerInvariant()
    if_index = [int]$adapter.ifIndex
    status = [string]$adapter.Status
    mac = [string]$adapter.MacAddress
    mtu = [int]$adapter.MtuSize
    link_speed = [string]$adapter.LinkSpeed
    media_type = [string]$adapter.MediaType
    physical_media_type = [string]$adapter.PhysicalMediaType
    virtual = [bool]$adapter.Virtual
    addresses = $addresses
    routes = $routes
    gateways = @(
      @($ipConfig.IPv4DefaultGateway | ForEach-Object { [string]$_.NextHop }) +
      @($ipConfig.IPv6DefaultGateway | ForEach-Object { [string]$_.NextHop })
    ) | Where-Object { $_ }
  }
})
$items | ConvertTo-Json -Depth 6 -Compress
"""
    code, stdout, _ = _run_text([powershell, "-NoProfile", "-NonInteractive", "-Command", script], 15)
    if code != 0 or not stdout.strip():
        return []
    try:
        value = json.loads(stdout)
        if isinstance(value, dict):
            return [value]
        return value if isinstance(value, list) else []
    except json.JSONDecodeError:
        return []


def _unix_adapters() -> list[dict[str, Any]]:
    ip_cmd = shutil.which("ip")
    if ip_cmd:
        code, stdout, _ = _run_text([ip_cmd, "-j", "address", "show"], 10)
        if code == 0:
            try:
                rows = json.loads(stdout)
                result = []
                for row in rows:
                    addresses = []
                    for info in row.get("addr_info", []):
                        addresses.append(
                            {
                                "address": info.get("local"),
                                "family": "IPv6" if info.get("family") == "inet6" else "IPv4",
                                "prefix_length": int(info.get("prefixlen", 0)),
                                "state": info.get("scope", ""),
                            }
                        )
                    result.append(
                        {
                            "name": row.get("ifname", ""),
                            "description": row.get("ifname", ""),
                            "guid": None,
                            "if_index": row.get("ifindex"),
                            "status": "Up" if "UP" in row.get("flags", []) else "Down",
                            "mac": row.get("address"),
                            "mtu": row.get("mtu"),
                            "link_speed": None,
                            "media_type": row.get("link_type"),
                            "physical_media_type": row.get("link_type"),
                            "virtual": row.get("link_type") not in ("ether", "loopback"),
                            "addresses": addresses,
                            "routes": [],
                            "gateways": [],
                        }
                    )
                return result
            except (ValueError, TypeError):
                pass
    return [
        {
            "name": name,
            "description": name,
            "guid": None,
            "if_index": index,
            "status": "Unknown",
            "mac": None,
            "mtu": None,
            "link_speed": None,
            "media_type": None,
            "physical_media_type": None,
            "virtual": False,
            "addresses": [],
            "routes": [],
            "gateways": [],
        }
        for index, name in socket.if_nameindex()
    ]


def _interface_kind(item: dict[str, Any]) -> str:
    text = " ".join(
        str(item.get(key) or "")
        for key in ("name", "description", "capture_description", "media_type", "physical_media_type")
    ).lower()
    if "vector" in text or "vn5620" in text:
        return "Automotive / Vector"
    if "wi-fi" in text or "wifi" in text or "wireless" in text or "wlan" in text:
        return "Wi-Fi"
    if "loopback" in text or item.get("name") == "lo":
        return "Loopback"
    if any(word in text for word in ("tunnel", "vpn", "tap", "tun")):
        return "Tunnel"
    if item.get("virtual") or any(word in text for word in ("virtual", "hyper-v", "vmware", "vbox")):
        return "Virtual"
    return "Ethernet"


def _scan_link_active(status: Any) -> bool:
    value = str(status or "").strip().lower()
    # Scanning is an active operation. Fail closed when the platform cannot
    # positively confirm that the selected link is usable.
    return value in {"up", "connected"}


def _vlan_id(item: dict[str, Any]) -> int | None:
    text = " ".join(str(item.get(key) or "") for key in ("name", "description", "capture_description"))
    patterns = (r"(?i)\bvlan[\s_.-]*(\d{1,4})\b", r"\.(\d{1,4})(?:\s|$)")
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            value = int(match.group(1))
            if 0 <= value <= 4095:
                return value
    return None


def _networks(addresses: list[dict[str, Any]]) -> list[str]:
    result: list[str] = []
    for entry in addresses:
        address = entry.get("address")
        prefix = entry.get("prefix_length")
        if not address or prefix is None:
            continue
        try:
            ip = ipaddress.ip_address(str(address).split("%", 1)[0])
            if ip.is_loopback or ip.is_unspecified:
                continue
            network = ipaddress.ip_network(f"{ip}/{int(prefix)}", strict=False)
            text = str(network)
            if text not in result:
                result.append(text)
        except ValueError:
            continue
    return result


def _recommended_targets(networks: list[str]) -> list[str]:
    local_ranges = tuple(
        ipaddress.ip_network(value)
        for value in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "fc00::/7")
    )
    result = []
    for value in networks:
        try:
            network = ipaddress.ip_network(value, strict=False)
        except ValueError:
            continue
        if any(network.version == pool.version and network.subnet_of(pool) for pool in local_ranges):
            result.append(value)
    return result


def _match_os_adapter(capture: dict[str, Any], adapters: list[dict[str, Any]]) -> dict[str, Any] | None:
    guid = (capture.get("guid") or "").lower()
    if guid:
        for adapter in adapters:
            if str(adapter.get("guid") or "").lower() == guid:
                return adapter
    capture_id = str(capture.get("capture_id") or "").lower()
    description = str(capture.get("capture_description") or "").lower()
    for adapter in adapters:
        candidates = (str(adapter.get("name") or "").lower(), str(adapter.get("description") or "").lower())
        if capture_id in candidates or description in candidates:
            return adapter
    return None


def _nmap_name(item: dict[str, Any], nmap_map: dict[str, str]) -> str | None:
    capture_id = str(item.get("capture_id") or "").lower()
    if capture_id in nmap_map:
        return nmap_map[capture_id]
    guid = str(item.get("guid") or "").strip("{}").lower()
    if guid:
        return nmap_map.get(f"\\device\\npf_{{{guid}}}".lower())
    return None


def list_interfaces(
    tshark_path: str | None,
    nmap_path: str | None = None,
    dumpcap_path: str | None = None,
) -> list[dict[str, Any]]:
    adapters = _windows_adapters() if platform.system() == "Windows" else _unix_adapters()
    nmap_map: dict[str, str] = {}
    if nmap_path and platform.system() == "Windows":
        code, stdout, _ = _run_text([nmap_path, "--iflist"], timeout=15)
        if code == 0:
            nmap_map = parse_nmap_interface_map(stdout)
    captures_by_id: dict[str, dict[str, Any]] = {}
    for helper_name, helper_path in (("dumpcap", dumpcap_path), ("tshark", tshark_path)):
        if not helper_path:
            continue
        code, stdout, _ = _run_text([helper_path, "-D"], timeout=15)
        if code == 0:
            for capture in parse_capture_interfaces(stdout):
                key = str(capture.get("capture_id") or "").lower()
                if key not in captures_by_id:
                    capture["capture_helper"] = helper_name
                    captures_by_id[key] = capture
    captures = list(captures_by_id.values())

    merged: list[dict[str, Any]] = []
    used: set[int] = set()
    for capture in captures:
        adapter = _match_os_adapter(capture, adapters)
        if adapter is not None:
            used.add(id(adapter))
        item = {**(adapter or {}), **capture}
        item.setdefault("name", capture.get("capture_description") or capture.get("capture_id"))
        item.setdefault("description", capture.get("capture_description") or capture.get("capture_id"))
        item.setdefault("status", "Unknown")
        item.setdefault("addresses", [])
        item.setdefault("routes", [])
        item.setdefault("gateways", [])
        item["networks"] = _networks(item["addresses"])
        item["recommended_targets"] = _recommended_targets(item["networks"])
        item["kind"] = _interface_kind(item)
        item["vlan_id"] = _vlan_id(item)
        item["scan_ready"] = bool(item["networks"]) and _scan_link_active(item.get("status"))
        item["nmap_name"] = _nmap_name(item, nmap_map)
        if nmap_path and platform.system() == "Windows" and not item["nmap_name"]:
            item["scan_ready"] = False
        item["is_vector"] = item["kind"] == "Automotive / Vector"
        merged.append(item)

    for adapter in adapters:
        if id(adapter) in used:
            continue
        item = {
            **adapter,
            "capture_index": None,
            "capture_id": adapter.get("name"),
            "capture_description": adapter.get("description") or adapter.get("name"),
            "capture_ready": False,
            "provider": "operating-system",
        }
        item["networks"] = _networks(item.get("addresses", []))
        item["recommended_targets"] = _recommended_targets(item["networks"])
        item["kind"] = _interface_kind(item)
        item["vlan_id"] = _vlan_id(item)
        item["scan_ready"] = bool(item["networks"]) and _scan_link_active(item.get("status"))
        item["nmap_name"] = _nmap_name(item, nmap_map)
        if nmap_path and platform.system() == "Windows" and not item["nmap_name"]:
            item["scan_ready"] = False
        item["is_vector"] = item["kind"] == "Automotive / Vector"
        merged.append(item)

    merged.sort(key=lambda row: (not row.get("capture_ready", False), row.get("capture_index") or 9999, row.get("name") or ""))
    for index, item in enumerate(merged):
        stable = item.get("guid") or item.get("capture_id") or item.get("name") or str(index)
        item["id"] = re.sub(r"[^a-zA-Z0-9_.:-]+", "_", str(stable)).strip("_")[:180]
    return merged


def system_snapshot() -> dict[str, Any]:
    tools = detect_tools()
    return {
        "platform": platform.platform(),
        "python": platform.python_version(),
        "hostname": socket.gethostname(),
        "tools": tools,
        "capture_available": tools["dumpcap"]["available"] or tools["tshark"]["available"],
        "analysis_available": tools["tshark"]["available"],
        "scan_available": tools["nmap"]["available"],
    }
