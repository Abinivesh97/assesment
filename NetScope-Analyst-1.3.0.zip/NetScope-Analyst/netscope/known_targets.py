"""Pure-text preview of exact ECU targets from pasted ifconfig-style output.

The raw text is deliberately never returned or persisted.  Only address,
interface, and VLAN metadata needed for an explicit operator-reviewed mapping
is emitted.
"""

from __future__ import annotations

import ipaddress
import re
from collections import Counter
from typing import Any

from .validation import ValidationError, clean_text, parse_vlan_ids


MAX_IFCONFIG_TEXT = 256 * 1024
MAX_CANDIDATES = 512
_LOCAL_V4 = tuple(
    ipaddress.ip_network(value)
    for value in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "169.254.0.0/16")
)
_LOCAL_V6 = (ipaddress.ip_network("fc00::/7"),)

_HEADER_PATTERNS = (
    re.compile(r"^\s*(?:\d+:\s+)?([A-Za-z0-9_.@-]{1,64}):\s+(?:flags[=<]|<)", re.IGNORECASE),
    re.compile(r"^\s*([A-Za-z0-9_.@-]{1,64})\s+Link\s+encap:", re.IGNORECASE),
)
_IPV4_LINE = re.compile(
    r"\binet(?!6)\b(?:\s+addr:|\s+)([0-9.]+)(?:/(\d{1,3}))?",
    re.IGNORECASE,
)
_IPV6_LINE = re.compile(
    r"\binet6\b(?:\s+addr:|\s+)([0-9A-Fa-f:]+(?:%[A-Za-z0-9_.-]+)?)(?:/(\d{1,3}))?",
    re.IGNORECASE,
)
_NETMASK = re.compile(r"\bnetmask\s+(0x[0-9A-Fa-f]+|[0-9.]+)", re.IGNORECASE)
_PREFIXLEN = re.compile(r"\bprefixlen\s+(\d{1,3})\b", re.IGNORECASE)
_BROADCAST = re.compile(r"\bbroadcast\s+([0-9.]+)\b", re.IGNORECASE)
_VLAN_LINE = re.compile(r"\bvlan\s*:\s*(\d{1,4})\b", re.IGNORECASE)
_VLAN_NAME_PATTERNS = (
    re.compile(r"^vlan[_-]?(\d{1,4})$", re.IGNORECASE),
    re.compile(r"[._-]vlan[_-]?(\d{1,4})$", re.IGNORECASE),
    re.compile(r"[._-](\d{1,4})$", re.IGNORECASE),
)


def _interface_header(line: str) -> str | None:
    for pattern in _HEADER_PATTERNS:
        match = pattern.search(line)
        if match:
            return match.group(1)
    return None


def _vlan_from_block(interface_name: str, lines: list[str]) -> int | None:
    for line in lines:
        match = _VLAN_LINE.search(line)
        if match:
            value = int(match.group(1))
            return value if 0 <= value <= 4095 else None
    for pattern in _VLAN_NAME_PATTERNS:
        match = pattern.search(interface_name)
        if match:
            value = int(match.group(1))
            return value if 0 <= value <= 4095 else None
    return None


def _local_automotive_address(address: ipaddress._BaseAddress) -> bool:
    pools = _LOCAL_V4 if address.version == 4 else _LOCAL_V6
    return any(address in pool for pool in pools)


def _ipv4_mask_prefix(raw_mask: str) -> int:
    if raw_mask.lower().startswith("0x"):
        try:
            number = int(raw_mask, 16)
        except ValueError as exc:
            raise ValidationError("Invalid hexadecimal IPv4 netmask") from exc
        if not 0 <= number <= 0xFFFFFFFF:
            raise ValidationError("IPv4 netmask is outside 32 bits")
        bits = f"{number:032b}"
        if "01" in bits:
            raise ValidationError("IPv4 netmask is not contiguous")
        return bits.count("1")
    try:
        return ipaddress.IPv4Network(f"0.0.0.0/{raw_mask}").prefixlen
    except (ipaddress.NetmaskValueError, ipaddress.AddressValueError) as exc:
        raise ValidationError("IPv4 netmask is invalid or non-contiguous") from exc


def _address_metadata(
    line: str,
    address: ipaddress._BaseAddress,
    explicit_prefix: str | None,
) -> tuple[int | None, str | None, str | None, str | None]:
    prefix_length: int | None = None
    mask_error: str | None = None
    if explicit_prefix is not None:
        prefix_length = int(explicit_prefix)
    elif address.version == 4:
        match = _NETMASK.search(line)
        if match:
            try:
                prefix_length = _ipv4_mask_prefix(match.group(1))
            except ValidationError as exc:
                mask_error = str(exc)
    else:
        match = _PREFIXLEN.search(line)
        if match:
            prefix_length = int(match.group(1))
    maximum = 32 if address.version == 4 else 128
    if prefix_length is not None and not 0 <= prefix_length <= maximum:
        mask_error = f"IPv{address.version} prefix length is outside 0-{maximum}"
        prefix_length = None
    if prefix_length is None:
        return None, None, None, mask_error
    network = ipaddress.ip_network(f"{address.compressed}/{prefix_length}", strict=False)
    broadcast = network.broadcast_address.compressed if address.version == 4 else None
    return prefix_length, network.network_address.compressed, broadcast, mask_error


def _source_rows(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list) or not value:
        raise ValidationError("Select at least one source before previewing known ECU targets")
    if len(value) > 32:
        raise ValidationError("At most 32 source mappings are allowed")
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for row in value:
        if not isinstance(row, dict):
            raise ValidationError("Each known-target source mapping must be an object")
        interface_id = clean_text(row.get("interface_id"), 200)
        if not interface_id or interface_id in seen:
            raise ValidationError("Known-target sources must have unique interface identifiers")
        seen.add(interface_id)
        result.append(
            {
                "interface_id": interface_id,
                "alias": clean_text(row.get("alias") or interface_id, 120),
                "vlan_ids": parse_vlan_ids(row.get("vlan_ids")),
            }
        )
    return result


def _safe_text(value: Any) -> str:
    if not isinstance(value, str):
        raise ValidationError("Pasted interface output must be text")
    if not value.strip():
        raise ValidationError("Paste ECU ifconfig output before previewing targets")
    if len(value) > MAX_IFCONFIG_TEXT:
        raise ValidationError(f"Pasted interface output exceeds {MAX_IFCONFIG_TEXT // 1024} KiB")
    if "\x00" in value or any(ord(char) < 32 and char not in "\t\r\n" for char in value):
        raise ValidationError("Pasted interface output contains unsupported control characters")
    return value


def preview_known_targets(payload: dict[str, Any]) -> dict[str, Any]:
    """Return operator-review candidates without executing or storing anything."""

    if not isinstance(payload, dict):
        raise ValidationError("Request body must be an object")
    text = _safe_text(payload.get("text"))
    sources = _source_rows(payload.get("sources"))

    blocks: list[tuple[str, list[str]]] = []
    current_name: str | None = None
    current_lines: list[str] = []
    for raw_line in text.splitlines():
        line = raw_line[:4096]
        header = _interface_header(line)
        if header:
            if current_name is not None:
                blocks.append((current_name, current_lines))
            current_name = header
            current_lines = [line]
        elif current_name is not None:
            current_lines.append(line)
    if current_name is not None:
        blocks.append((current_name, current_lines))

    candidates: list[dict[str, Any]] = []
    skipped: Counter[str] = Counter()
    seen: set[tuple[str, str, int | None]] = set()
    scope_observations: dict[tuple[int, str], set[tuple[int, str]]] = {}
    for interface_name, lines in blocks:
        vlan_id = _vlan_from_block(interface_name, lines)
        matching_sources = [row for row in sources if vlan_id is not None and vlan_id in row["vlan_ids"]]
        source_interface_id = matching_sources[0]["interface_id"] if len(matching_sources) == 1 else None
        mapping_status = (
            "mapped-by-vlan"
            if len(matching_sources) == 1
            else "ambiguous-vlan"
            if len(matching_sources) > 1
            else "unmapped"
        )
        for line in lines:
            address_tokens: list[tuple[str, str | None]] = []
            ipv4_match = _IPV4_LINE.search(line)
            ipv6_match = _IPV6_LINE.search(line)
            if ipv4_match:
                address_tokens.append((ipv4_match.group(1), ipv4_match.group(2)))
            if ipv6_match:
                address_tokens.append((ipv6_match.group(1), ipv6_match.group(2)))
            for token, explicit_prefix in address_tokens:
                bare = token.split("%", 1)[0]
                try:
                    address = ipaddress.ip_address(bare)
                except ValueError:
                    skipped["invalid-address"] += 1
                    continue
                if address.is_loopback:
                    skipped["loopback"] += 1
                    continue
                if address.is_unspecified or address.is_multicast:
                    skipped["non-unicast"] += 1
                    continue
                if address.version == 6 and address.is_link_local:
                    skipped["ecu-scoped-ipv6-link-local"] += 1
                    continue
                prefix_length, network, broadcast, mask_error = _address_metadata(
                    line,
                    address,
                    explicit_prefix,
                )
                if mask_error:
                    skipped["invalid-or-noncontiguous-mask"] += 1
                if (
                    address.version == 4
                    and prefix_length is not None
                    and prefix_length <= 30
                    and address.compressed in {network, broadcast}
                ):
                    skipped["network-or-broadcast-address"] += 1
                    continue
                if vlan_id is not None and prefix_length is not None and network is not None:
                    scope_observations.setdefault(
                        (vlan_id, f"IPv{address.version}"),
                        set(),
                    ).add((prefix_length, network))
                normalized = address.compressed
                identity = (normalized.casefold(), interface_name.casefold(), vlan_id)
                if identity in seen:
                    skipped["duplicate"] += 1
                    continue
                seen.add(identity)
                if len(candidates) >= MAX_CANDIDATES:
                    raise ValidationError(f"Pasted interface output contains more than {MAX_CANDIDATES} target candidates")
                candidates.append(
                    {
                        "id": f"candidate-{len(candidates) + 1}",
                        "address": normalized,
                        "family": f"IPv{address.version}",
                        "ecu_interface": interface_name,
                        "vlan_id": vlan_id,
                        "prefix_length": prefix_length,
                        "network": network,
                        "broadcast": broadcast,
                        "reported_broadcast": (
                            _BROADCAST.search(line).group(1)
                            if address.version == 4 and _BROADCAST.search(line)
                            else None
                        ),
                        "mask_warning": mask_error,
                        "source_interface_id": source_interface_id,
                        "mapping_status": mapping_status,
                        "requires_non_local_opt_in": not _local_automotive_address(address),
                    }
                )

    conflicting_keys = {key for key, scopes in scope_observations.items() if len(scopes) > 1}
    for row in candidates:
        key = (int(row["vlan_id"]), str(row["family"])) if row["vlan_id"] is not None else None
        row["prefix_conflict"] = bool(key in conflicting_keys)
        row["scope_safety_note"] = (
            "prefix-conflict; exact-host only; subnet expansion prohibited"
            if row["prefix_conflict"]
            else "exact-host only"
        )

    warnings: list[str] = []
    non_local_count = sum(1 for row in candidates if row["requires_non_local_opt_in"])
    if non_local_count:
        warnings.append(
            f"{non_local_count} non-RFC1918/ULA exact host target(s) require the separate Allow non-local scope option"
        )
    link_local_count = skipped.get("ecu-scoped-ipv6-link-local", 0)
    if link_local_count:
        warnings.append(
            f"Skipped {link_local_count} ECU-scoped IPv6 link-local address(es); their ECU zone names are not valid PC egress zones"
        )
    ambiguous_count = sum(1 for row in candidates if row["mapping_status"] != "mapped-by-vlan")
    if ambiguous_count:
        warnings.append(
            f"{ambiguous_count} candidate(s) need an explicit source selection before they can be applied"
        )
    if conflicting_keys:
        warnings.append(
            f"Detected {len(conflicting_keys)} VLAN/family prefix conflict(s); exact-host only; subnet expansion prohibited"
        )

    return {
        "candidates": candidates,
        "summary": {
            "candidate_count": len(candidates),
            "auto_mapped_count": len(candidates) - ambiguous_count,
            "manual_mapping_count": ambiguous_count,
            "non_local_count": non_local_count,
            "skipped_counts": dict(sorted(skipped.items())),
            "prefix_conflict_count": len(conflicting_keys),
        },
        "warnings": warnings,
        "raw_text_retained": False,
    }
