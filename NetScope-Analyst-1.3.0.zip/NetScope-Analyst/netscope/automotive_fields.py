"""Version-tolerant TShark field selection for automotive Ethernet.

This module contains no capture processing.  It provides a small compatibility
layer that maps stable semantic names to the field abbreviations exposed by an
installed TShark version.

MACsec and MKA handling deliberately uses an exact metadata allowlist.  Prefix
selection is unsafe because the registries also expose wrapped/unwrapped key
material, decrypted data, and configured verification secrets.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping


SINGLE_FIELD_ALIASES: dict[str, tuple[str, ...]] = {
    # frame.protocols is registered by TShark.  _ws.col.Protocol is a useful
    # pseudo-field on older builds but is commonly absent from -G fields.
    "protocol_stack": ("frame.protocols", "_ws.col.Protocol"),
    "someip_service_id": ("someip.serviceid",),
    "someip_method_id": ("someip.methodid",),
    "someip_client_id": ("someip.clientid",),
    "someip_session_id": ("someip.sessionid",),
    "someip_protocol_version": ("someip.protoversion", "someip.protover"),
    "someip_interface_version": ("someip.interfaceversion",),
    "someip_message_type": ("someip.messagetype",),
    "someip_return_code": ("someip.returncode",),
    "someipsd_entry_type": ("someipsd.entry.type",),
    "someipsd_service_id": ("someipsd.entry.serviceid",),
    "someipsd_instance_id": ("someipsd.entry.instanceid",),
    "someipsd_major_version": ("someipsd.entry.majorver",),
    "someipsd_ttl": ("someipsd.entry.ttl",),
    "someipsd_eventgroup_id": ("someipsd.entry.eventgroupid",),
    "someipsd_ipv4_address": (
        "someipsd.option.ipv4address",
        "someipsd.option.ipv4_address",
    ),
    "someipsd_ipv6_address": (
        "someipsd.option.ipv6address",
        "someipsd.option.ipv6_address",
    ),
    "someipsd_endpoint_port": ("someipsd.option.port",),
    "someipsd_endpoint_protocol": ("someipsd.option.proto",),
    "doip_payload_type": ("doip.type", "doip.payload_type"),
    "doip_logical_address": ("doip.logical_address",),
    "doip_source_address": ("doip.source_address",),
    "doip_target_address": ("doip.target_address",),
    "doip_vin": ("doip.vin",),
    "doip_eid": ("doip.eid",),
    "doip_gid": ("doip.gid",),
    "doip_routing_activation_response": (
        "doip.response_code",
        "doip.routing_activation_response",
    ),
    "doip_header_nack": ("doip.nack_code",),
    "doip_diagnostic_nack": ("doip.diag_nack_code",),
    "uds_service_id": ("uds.sid",),
    "uds_reply": ("uds.reply",),
    "uds_negative_service_id": ("uds.err.sid",),
    "uds_negative_response_code": ("uds.err.code",),
    "ptp_message_type": ("ptp.v2.messagetype",),
    "ptp_domain": ("ptp.v2.domainnumber",),
    "ptp_sequence_id": ("ptp.v2.sequenceid",),
    # These are intentionally separate semantics.  A source clock is not a
    # grandmaster and must never be used as a fallback for an Announce GM.
    "ptp_source_clock_identity": ("ptp.v2.clockidentity",),
    "ptp_announce_grandmaster_identity": (
        "ptp.v2.an.grandmasterclockidentity",
        "ptp.v2.grandmasteridentity",
    ),
    "ptp_two_step": ("ptp.v2.flags.twostep", "ptp.v2.flags.twoStep"),
    "ptp_correction_nanoseconds": ("ptp.v2.correction.ns",),
    "avtp_subtype": ("ieee1722.subtype", "avtp.subtype"),
    "avtp_encapsulation_sequence_number": (
        "ieee1722.encapsulation_sequence_num",
        "avtp.sequence_num",
    ),
    "msrp_vlan_id": ("mrp-msrp.vlan_id",),
    "msrp_priority": ("mrp-msrp.priority",),
    "macsec_encrypted": ("macsec.TCI.E",),
    "macsec_changed_text": ("macsec.TCI.C",),
    "macsec_association_number": ("macsec.AN",),
    "macsec_packet_number": ("macsec.PN",),
    "macsec_sci_system": ("macsec.SCI.system_identifier",),
    "macsec_sci_port": ("macsec.SCI.port_identifier",),
    "macsec_verification_succeeded": ("macsec.verify_info.verified",),
    "mka_version": ("mka.version_id",),
    "mka_sci": ("mka.sci",),
    "mka_key_server_priority": ("mka.ks_prio",),
    "mka_is_key_server": ("mka.key_server",),
    "mka_macsec_desired": ("mka.macsec_desired",),
    "mka_macsec_capability": ("mka.macsec_capability",),
    "mka_latest_association_number": ("mka.latest_key_an",),
    "mka_latest_tx": ("mka.latest_key_tx",),
    "mka_latest_rx": ("mka.latest_key_rx",),
    "mka_old_association_number": ("mka.old_key_an",),
    "mka_old_tx": ("mka.old_key_tx",),
    "mka_old_rx": ("mka.old_key_rx",),
    "mka_plain_tx": ("mka.plain_tx",),
    "mka_plain_rx": ("mka.plain_rx",),
    "mka_delay_protect": ("mka.delay_protect",),
    "mka_confidentiality_offset": ("mka.confidentiality_offset",),
    "mka_cipher_suite": ("mka.macsec_cipher_suite",),
}


# Each available subtype field is useful at the same time.  These are therefore
# collected as a set of compatible sources rather than first-match aliases.
MULTI_FIELD_ALIASES: dict[str, tuple[str, ...]] = {
    "avtp_stream_id": (
        "aaf.stream_id",
        "crf.stream_id",
        "cvf.stream_id",
        "ntscf.stream_id",
        "tscf.stream_id",
        "iec61883.stream_id",
        "mrp-msrp.stream_id",
        "ieee17221.stream_id",
        "ieee1722.stream_id",
        "avtp.stream_id",
    ),
    "avtp_sequence_number": (
        "aaf.seqnum",
        "crf.seqnum",
        "cvf.seqnum",
        "ntscf.seqnum",
        "tscf.seqnum",
        "iec61883.seqnum",
        "ieee1722.encapsulation_sequence_num",
        "ieee1722.sequence_num",
        "ieee1722.seqnum",
        "avtp.sequence_num",
    ),
    "frer_sequence_number": (
        "ieee8021cb.seq",
        "rtag.seqno",
        "rtag.sequence_number",
    ),
}


SAFE_MACSEC_MKA_FIELDS = frozenset(
    field
    for aliases in SINGLE_FIELD_ALIASES.values()
    for field in aliases
    if field.startswith(("macsec.", "mka."))
)


SOMEIP_HEURISTIC_SHORT_NAMES = ("someip_udp_heur", "someip_tcp_heur")
PROTOCOL_COLUMN_PSEUDO_FIELD = "_ws.col.Protocol"


PROTOCOL_LABELS = {
    "eth": "Ethernet",
    "vlan": "802.1Q VLAN",
    "ip": "IPv4",
    "ipv6": "IPv6",
    "tcp": "TCP",
    "udp": "UDP",
    "someip": "SOME/IP",
    "someipsd": "SOME/IP-SD",
    "doip": "DoIP",
    "uds": "UDS",
    "ptp": "PTP/gPTP",
    "ieee1722": "AVTP / IEEE 1722",
    "iec61883": "AVTP / IEC 61883",
    "aaf": "AVTP / AAF",
    "crf": "AVTP / CRF",
    "cvf": "AVTP / CVF",
    "ntscf": "AVTP / NTSCF",
    "tscf": "AVTP / TSCF",
    "mrp-msrp": "MSRP",
    "ieee8021cb": "FRER / IEEE 802.1CB",
    "rtag": "FRER / R-TAG",
    "macsec": "MACsec",
    "mka": "MKA",
    "arp": "ARP",
    "dns": "DNS",
    "mdns": "mDNS",
    "dhcp": "DHCP",
    "icmp": "ICMP",
    "icmpv6": "ICMPv6",
    "data": "Data",
}


def resolve_semantic_fields(
    available_fields: Iterable[str],
    *,
    allow_protocol_column_pseudo_field: bool = True,
) -> dict[str, tuple[str, ...]]:
    """Resolve installed field abbreviations under stable semantic names.

    Single-field semantics use the first installed alias.  Multi-field
    semantics retain every installed subtype field.  The protocol-column
    pseudo-field may be selected only as a final fallback because it is absent
    from many TShark registries despite being accepted by field output.
    """

    available = {str(field).strip() for field in available_fields if str(field).strip()}
    resolved: dict[str, tuple[str, ...]] = {}
    for semantic, aliases in SINGLE_FIELD_ALIASES.items():
        selected = next((field for field in aliases if field in available), None)
        if (
            selected is None
            and semantic == "protocol_stack"
            and allow_protocol_column_pseudo_field
        ):
            selected = PROTOCOL_COLUMN_PSEUDO_FIELD
        if selected is not None:
            resolved[semantic] = (selected,)
    for semantic, aliases in MULTI_FIELD_ALIASES.items():
        selected = tuple(field for field in aliases if field in available)
        if selected:
            resolved[semantic] = selected
    validate_macsec_mka_selection(flatten_resolved_fields(resolved))
    return resolved


def flatten_resolved_fields(resolved: Mapping[str, Iterable[str]]) -> tuple[str, ...]:
    """Flatten resolved fields in semantic order without duplicates."""

    result: list[str] = []
    seen: set[str] = set()
    for fields in resolved.values():
        for field in fields:
            if field not in seen:
                seen.add(field)
                result.append(field)
    return tuple(result)


def semantic_values(
    row: Mapping[str, str],
    resolved: Mapping[str, Iterable[str]],
    semantic: str,
) -> tuple[str, ...]:
    """Return non-empty values for every resolved source of a semantic field."""

    return tuple(
        value
        for field in resolved.get(semantic, ())
        if (value := str(row.get(field, "")).strip())
    )


def deepest_protocol_label(protocol_stack: str, column_fallback: str = "") -> str:
    """Return a stable display label for the deepest decoded protocol."""

    protocols = [
        token.strip().lower()
        for token in str(protocol_stack or "").split(":")
        if token.strip()
    ]
    if not protocols:
        return str(column_fallback or "").strip() or "Unknown"
    deepest = protocols[-1]
    return PROTOCOL_LABELS.get(deepest, deepest.upper())


def parse_heuristic_registry(registry_text: str) -> frozenset[str]:
    """Parse short names from TShark -G heuristic-decodes output."""

    names: set[str] = set()
    for raw_line in str(registry_text or "").splitlines():
        parts = raw_line.split("\t")
        if len(parts) < 5:
            continue
        short_name = parts[4].strip()
        if short_name:
            names.add(short_name)
    return frozenset(names)


def available_someip_heuristics(registry_text: str) -> tuple[str, ...]:
    """Return the exact supported SOME/IP UDP/TCP heuristic short names."""

    available = parse_heuristic_registry(registry_text)
    return tuple(
        name for name in SOMEIP_HEURISTIC_SHORT_NAMES if name in available
    )


def someip_heuristic_cli_args(heuristics: Iterable[str]) -> tuple[str, ...]:
    """Build allowlisted TShark CLI arguments for supported SOME/IP heuristics."""

    requested = tuple(dict.fromkeys(str(name).strip() for name in heuristics))
    unknown = sorted(set(requested) - set(SOMEIP_HEURISTIC_SHORT_NAMES))
    if unknown:
        raise ValueError(f"Unsupported heuristic short name: {', '.join(unknown)}")
    result: list[str] = []
    for name in requested:
        result.extend(("--enable-heuristic", name))
    return tuple(result)


def safe_macsec_mka_fields(available_fields: Iterable[str]) -> tuple[str, ...]:
    """Return only explicitly approved, non-secret MACsec/MKA metadata fields."""

    available = set(available_fields)
    return tuple(
        field for field in sorted(SAFE_MACSEC_MKA_FIELDS) if field in available
    )


def validate_macsec_mka_selection(fields: Iterable[str]) -> None:
    """Reject non-allowlisted MACsec/MKA fields, including key material."""

    unsafe = sorted(
        {
            field
            for field in fields
            if str(field).startswith(("macsec.", "mka."))
            and field not in SAFE_MACSEC_MKA_FIELDS
        }
    )
    if unsafe:
        raise ValueError(
            "Unsafe MACsec/MKA field selection is not allowed: "
            + ", ".join(unsafe)
        )

