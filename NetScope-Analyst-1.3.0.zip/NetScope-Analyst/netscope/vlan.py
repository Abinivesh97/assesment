"""Evidence-aware VLAN attribution for tagged and OS logical interfaces."""

from __future__ import annotations

from typing import Any


def _valid_vlan_ids(values: Any) -> list[int]:
    result: list[int] = []
    for value in values or []:
        try:
            vlan_id = int(value)
        except (TypeError, ValueError):
            continue
        if 0 <= vlan_id <= 4095 and vlan_id not in result:
            result.append(vlan_id)
    return result


def _packet_count(value: Any) -> int:
    try:
        return max(0, int(value or 0))
    except (TypeError, ValueError):
        return 0


def tag_preservation_summary(analysis: dict[str, Any]) -> dict[str, Any]:
    """Describe retained 802.1Q evidence without assuming wire behavior."""

    total_packets = _packet_count(analysis.get("packets"))
    tagged_frames = sum(
        _packet_count(row.get("count"))
        for row in analysis.get("vlan_stacks", [])
        if isinstance(row, dict)
    )
    tagged_frames = min(tagged_frames, total_packets) if total_packets else tagged_frames
    fraction = (tagged_frames / total_packets) if total_packets else 0.0
    if tagged_frames == 0:
        assessment = "not-observed"
    elif fraction < 0.01:
        assessment = "sparse"
    elif fraction < 0.95:
        assessment = "partial"
    else:
        assessment = "mostly-retained"
    return {
        "total_packets": total_packets,
        "tagged_frames": tagged_frames,
        "tagged_fraction": fraction,
        "assessment": assessment,
        "note": (
            "This describes tags retained at the capture API. VLAN offload, a VLAN "
            "subinterface, or the measurement provider can remove tags before capture."
        ),
    }


def build_vlan_views(
    source_analysis: dict[str, Any],
    configured_vlan_ids: Any,
    observed_views: dict[int, dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    """Build reportable VLAN views and explicit attribution evidence.

    Observed views contain per-tag analyses produced from display-filtered
    capture exports. A full source may be attributed to one configured logical
    VLAN only when no conflicting tag was retained. Multiple configured VLANs
    with no tags are never guessed.
    """

    configured = _valid_vlan_ids(configured_vlan_ids)
    partitions = source_analysis.get("vlan_partitions", {})
    observed = sorted(
        vlan_id
        for vlan_id in _valid_vlan_ids(partitions.keys())
        if isinstance(partitions.get(str(vlan_id)), dict)
    )
    untagged_packets = _packet_count((partitions.get("untagged") or {}).get("packets"))
    summary = tag_preservation_summary(source_analysis)
    views: list[dict[str, Any]] = []
    attribution: list[dict[str, Any]] = []
    configured_single = configured[0] if len(configured) == 1 else None
    conflicting_observed = bool(
        configured_single is not None
        and any(vlan_id != configured_single for vlan_id in observed)
    )

    for vlan_id in sorted(set(configured + observed)):
        tagged_packets = _packet_count((partitions.get(str(vlan_id)) or {}).get("packets"))
        tag_observed = tagged_packets > 0
        configured_here = vlan_id in configured
        observed_view = observed_views.get(vlan_id)
        logical_full_source = (
            vlan_id == configured_single
            and untagged_packets > 0
            and not conflicting_observed
        )

        if logical_full_source:
            basis = "configured-and-observed" if tag_observed else "configured-source"
            confidence = "medium"
            note = (
                "The complete source is attributed to this single configured logical "
                "VLAN. Retained packet tags provide supporting evidence."
                if tag_observed
                else
                "No 802.1Q tag was retained. The complete source is attributed only "
                "from the single configured logical VLAN; this is not wire-tag proof."
            )
            row = {
                "vlan_id": vlan_id,
                "analysis": source_analysis,
                "attribution": {
                    "basis": basis,
                    "attribution_scope": "full-source",
                    "tag_observed": tag_observed,
                    "tagged_packets": tagged_packets,
                    "total_packets": summary["total_packets"],
                    "confidence": confidence,
                    "note": note,
                },
                "export_path": (observed_view or {}).get("export_path"),
                "tag_analysis_path": (observed_view or {}).get("analysis_path"),
            }
            views.append(row)
            attribution.append({"vlan_id": vlan_id, **row["attribution"]})
            continue

        if tag_observed and observed_view and observed_view.get("analysis"):
            basis = "configured-and-observed" if configured_here else "observed-8021q"
            note = (
                "Traffic membership is supported by a retained 802.1Q tag. QinQ "
                "frames can appear in more than one VLAN membership view."
            )
            row = {
                "vlan_id": vlan_id,
                "analysis": observed_view["analysis"],
                "attribution": {
                    "basis": basis,
                    "attribution_scope": "retained-membership",
                    "tag_observed": True,
                    "tagged_packets": tagged_packets,
                    "total_packets": summary["total_packets"],
                    "confidence": "high",
                    "note": note,
                },
                "export_path": observed_view.get("export_path"),
                "tag_analysis_path": observed_view.get("analysis_path"),
            }
            views.append(row)
            attribution.append({"vlan_id": vlan_id, **row["attribution"]})
            continue

        if configured_here:
            attribution.append(
                {
                    "vlan_id": vlan_id,
                    "basis": "unattributable",
                    "attribution_scope": "unattributable",
                    "tag_observed": tag_observed,
                    "tagged_packets": tagged_packets,
                    "total_packets": summary["total_packets"],
                    "confidence": "none",
                    "note": (
                        "This source has multiple configured VLANs or conflicting tag "
                        "evidence, so untagged traffic cannot be assigned to this VLAN."
                    ),
                }
            )
        elif tag_observed:
            attribution.append(
                {
                    "vlan_id": vlan_id,
                    "basis": "observed-8021q",
                    "attribution_scope": "retained-membership",
                    "tag_observed": True,
                    "tagged_packets": tagged_packets,
                    "total_packets": summary["total_packets"],
                    "confidence": "high" if observed_view else "medium",
                    "note": (
                        "A retained 802.1Q tag was counted, but a separate analyzable "
                        "membership export was not available."
                    ),
                }
            )

    return views, attribution, summary
