#!/usr/bin/env python3
"""Verify a NetScope session manifest and chained audit log without modifying evidence."""

from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import re
from pathlib import Path
from typing import Any


SHA256_RE = re.compile(r"[0-9a-fA-F]{64}")


def sha256_file(path: Path, block_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(block_size):
            digest.update(block)
    return digest.hexdigest()


def verify_session(session_path: str | Path) -> dict[str, Any]:
    root = Path(session_path).resolve()
    errors: list[str] = []
    manifest_entries = 0
    audit_entries = 0
    if not root.is_dir():
        return {"ok": False, "manifest_entries": 0, "audit_entries": 0, "errors": [f"Session directory does not exist: {root}"]}

    manifest_path = root / "reports" / "sha256-manifest.txt"
    if not manifest_path.is_file():
        errors.append(f"Manifest is missing: {manifest_path}")
    else:
        seen: set[str] = set()
        for line_number, raw_line in enumerate(manifest_path.read_text(encoding="utf-8").splitlines(), 1):
            if not raw_line.strip():
                continue
            digest, separator, relative = raw_line.partition("  ")
            if not separator or not SHA256_RE.fullmatch(digest) or not relative:
                errors.append(f"Manifest line {line_number} is malformed")
                continue
            if relative in seen:
                errors.append(f"Manifest line {line_number} repeats path: {relative}")
                continue
            seen.add(relative)
            candidate = (root / Path(relative)).resolve()
            if candidate == root or root not in candidate.parents:
                errors.append(f"Manifest line {line_number} escapes the session directory: {relative}")
                continue
            if not candidate.is_file():
                errors.append(f"Manifest evidence is missing: {relative}")
                continue
            manifest_entries += 1
            actual = sha256_file(candidate)
            if not hmac.compare_digest(digest.lower(), actual.lower()):
                errors.append(f"SHA-256 mismatch: {relative}")

    audit_path = root / "audit.jsonl"
    if not audit_path.is_file():
        errors.append(f"Audit log is missing: {audit_path}")
    else:
        previous_hash = ""
        for line_number, raw_line in enumerate(audit_path.read_text(encoding="utf-8").splitlines(), 1):
            if not raw_line.strip():
                continue
            try:
                entry = json.loads(raw_line)
            except json.JSONDecodeError as exc:
                errors.append(f"Audit line {line_number} is invalid JSON: {exc.msg}")
                continue
            if not isinstance(entry, dict):
                errors.append(f"Audit line {line_number} is not an object")
                continue
            stored_hash = entry.get("entry_hash")
            if not isinstance(stored_hash, str) or not SHA256_RE.fullmatch(stored_hash):
                errors.append(f"Audit line {line_number} has no valid entry_hash")
                continue
            if entry.get("previous_hash") != previous_hash:
                errors.append(f"Audit chain mismatch at line {line_number}")
            canonical_entry = {key: value for key, value in entry.items() if key != "entry_hash"}
            canonical = json.dumps(
                canonical_entry,
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
                default=str,
            )
            actual_hash = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
            if not hmac.compare_digest(stored_hash.lower(), actual_hash.lower()):
                errors.append(f"Audit entry hash mismatch at line {line_number}")
            previous_hash = stored_hash
            audit_entries += 1

    return {
        "ok": not errors,
        "manifest_entries": manifest_entries,
        "audit_entries": audit_entries,
        "errors": errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify a NetScope Analyst session's hashes and audit chain.")
    parser.add_argument("session_dir", type=Path, help="Path to data/sessions/<session-uuid>")
    args = parser.parse_args()
    result = verify_session(args.session_dir)
    if result["ok"]:
        print(
            f"Evidence verified: {result['manifest_entries']} manifested files and "
            f"{result['audit_entries']} chained audit entries."
        )
        return 0
    print("Evidence verification FAILED:")
    for error in result["errors"]:
        print(f"- {error}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
