from __future__ import annotations

import io
import json
import tempfile
import unittest
from pathlib import Path

from netscope.analysis import _consume_tshark_output
from netscope.privacy import protect_vin_value, sanitize_vin_data


SYNTHETIC_NON_TEXT_VIN = "\ufffd" * 17


class _CompletedTshark:
    def __init__(self, output: str):
        self.stdout = io.StringIO(output)

    def wait(self, timeout: float | None = None) -> int:
        return 0


class DoipPrivacyTests(unittest.TestCase):
    def test_explicit_doip_vin_field_is_protected_even_when_not_iso_text(self) -> None:
        alias = protect_vin_value(SYNTHETIC_NON_TEXT_VIN, "session-a")
        self.assertRegex(alias, r"^VIN-[A-F0-9]{12}$")
        opted_in = protect_vin_value(
            SYNTHETIC_NON_TEXT_VIN,
            "session-a",
            include_plaintext=True,
        )
        self.assertEqual(opted_in, alias)
        self.assertRegex(opted_in, r"^VIN-[A-F0-9]{12}$")

        selected = [
            "frame.number",
            "frame.time_epoch",
            "frame.len",
            "_ws.col.Protocol",
            "doip.vin",
        ]
        output = "\t".join(
            ["1", "1.0", "64", "DOIP", SYNTHETIC_NON_TEXT_VIN]
        ) + "\n"
        with tempfile.TemporaryDirectory() as temporary:
            capture_path = Path(temporary) / "synthetic.pcapng"
            capture_path.write_bytes(b"synthetic capture placeholder")
            result = _consume_tshark_output(
                _CompletedTshark(output),
                io.StringIO(""),
                capture_path,
                selected,
                [],
                10,
                False,
                "session-a",
                None,
            )
        self.assertRegex(
            result["automotive"]["doip_vins"][0]["value"],
            r"^VIN-[A-F0-9]{12}$",
        )

    def test_structured_doip_vin_values_are_protected_before_reporting(self) -> None:
        legacy = {
            "packet_sample": [{"info": {"doip_vin": SYNTHETIC_NON_TEXT_VIN}}],
            "automotive": {
                "doip_vins": [{"value": SYNTHETIC_NON_TEXT_VIN, "count": 1}]
            },
        }
        sanitized = sanitize_vin_data(legacy, "session-a")
        rendered = json.dumps(sanitized, ensure_ascii=False)
        self.assertNotIn(SYNTHETIC_NON_TEXT_VIN, rendered)
        self.assertEqual(
            sanitized["packet_sample"][0]["info"]["doip_vin"],
            sanitized["automotive"]["doip_vins"][0]["value"],
        )
        self.assertRegex(
            sanitized["packet_sample"][0]["info"]["doip_vin"],
            r"^VIN-[A-F0-9]{12}$",
        )


if __name__ == "__main__":
    unittest.main()
