from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from netscope import __version__
from netscope.findings import annotate_inventory_scope, build_findings
from netscope.reporting import _capture_overlap, _render_html, build_report
from netscope.session import SessionManager
from tests.test_core import sample_config, sample_interface


SESSION_ID = "00000000-0000-0000-0000-000000001300"
APPLICATION = {"name": "NetScope Analyst", "version": __version__}


def _system() -> dict:
    return {
        "tools": {
            "dumpcap": {"available": True, "path": "dumpcap"},
            "tshark": {"available": True, "path": "tshark"},
            "nmap": {"available": True, "path": "nmap"},
        }
    }


def _config() -> dict:
    return {
        "name": "Synthetic release contract",
        "operator": "Test analyst",
        "authorization_note": "Synthetic offline fixture",
        "topology_notes": "Synthetic topology",
        "automotive_mode": True,
        "include_vin_in_reports": False,
        "capture": {"enabled": True},
        "scan": {
            "enabled": True,
            "automatic_exclusions": ["192.0.2.10/32", "192.0.2.1/32"],
        },
        "sources": [
            {
                "source_id": "source-1",
                "interface_id": "synthetic-interface",
                "alias": "Synthetic VLAN",
                "role": "Test source",
                "switch_port": "Synthetic mirror",
                "vlan_ids": [42],
                "targets": ["192.0.2.20/32"],
                "expected_ports": [13_400],
                "interface": {
                    "id": "synthetic-interface",
                    "name": "Synthetic VLAN 42",
                    "mac": "02:00:00:00:00:10",
                    "addresses": [
                        {
                            "family": "IPv4",
                            "address": "192.0.2.10",
                            "prefix_length": 24,
                        }
                    ],
                },
            }
        ],
    }


def _state(config: dict | None = None) -> dict:
    return {
        "id": SESSION_ID,
        "name": "Synthetic release contract",
        "status": "completed",
        "created_at": "2026-01-01T00:00:00+00:00",
        "started_at": "2026-01-01T00:00:00+00:00",
        "ended_at": "2026-01-01T00:10:00+00:00",
        "application": dict(APPLICATION),
        "config": config or _config(),
        "system": {},
        "captures": [],
        "scans": [],
        "warnings": [],
        "errors": [],
    }


class ReleaseProvenanceTests(unittest.TestCase):
    def test_live_session_metadata_and_reports_record_collector_version(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            with mock.patch("netscope.session.system_snapshot", return_value=_system()):
                manager = SessionManager(Path(temporary))
            with (
                mock.patch.object(manager, "interfaces", return_value=[sample_interface()]),
                mock.patch("netscope.session.threading.Thread.start"),
            ):
                state = manager.start_session(sample_config())

            expected = {"name": "NetScope Analyst", "version": __version__}
            self.assertEqual(state["application"], expected)
            metadata_path = manager.sessions_dir / state["id"] / "session-metadata.json"
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            self.assertEqual(metadata["application"], expected)

            report = build_report(state, [], [], [], [], [])
            self.assertEqual(report["schema_version"], "1.3")
            self.assertEqual(report["topology"]["schema_version"], "1.3")
            self.assertEqual(report["generated_by"], expected)
            self.assertEqual(report["session"]["collector_application"], expected)

    def test_import_session_also_records_collector_version(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            upload = root / "synthetic.pcap"
            upload.write_bytes(b"synthetic offline capture")
            with mock.patch("netscope.session.system_snapshot", return_value=_system()):
                manager = SessionManager(root / "data")
            with mock.patch("netscope.session.threading.Thread.start"):
                state = manager.import_capture(
                    upload,
                    "synthetic.pcap",
                    {"name": "Synthetic import", "automotive_mode": True},
                )

            self.assertEqual(state["application"], APPLICATION)
            metadata_path = manager.sessions_dir / state["id"] / "session-metadata.json"
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            self.assertEqual(metadata["application"], APPLICATION)


class CaptureOverlapContractTests(unittest.TestCase):
    def test_full_partial_and_no_capture_overlap_are_distinct(self) -> None:
        scan = {
            "source_id": "source-1",
            "started_at": "2026-01-01T00:01:00+00:00",
            "ended_at": "2026-01-01T00:02:00+00:00",
        }
        cases = {
            "full": (
                {
                    "source_id": "source-1",
                    "started_at": "2026-01-01T00:00:00+00:00",
                    "ended_at": "2026-01-01T00:03:00+00:00",
                },
                60.0,
                1.0,
            ),
            "partial": (
                {
                    "source_id": "source-1",
                    "started_at": "2026-01-01T00:01:30+00:00",
                    "ended_at": "2026-01-01T00:02:30+00:00",
                },
                30.0,
                0.5,
            ),
            "none": (
                {
                    "source_id": "source-1",
                    "started_at": "2026-01-01T00:03:00+00:00",
                    "ended_at": "2026-01-01T00:04:00+00:00",
                },
                0.0,
                0.0,
            ),
        }
        for status, (capture, seconds, ratio) in cases.items():
            with self.subTest(status=status):
                result = _capture_overlap(scan, [capture])
                self.assertEqual(result["status"], status)
                self.assertEqual(result["seconds"], seconds)
                self.assertEqual(result["scan_seconds"], 60.0)
                self.assertEqual(result["ratio"], ratio)


class ReportEvidenceBoundaryTests(unittest.TestCase):
    def test_passive_scan_probe_observation_never_becomes_a_confirmed_service(self) -> None:
        port_observation = {
            "transport": "tcp",
            "port": 42_042,
            "registry_name_hint": "synthetic-registry-hint",
            "service_guess": None,
            "service_evidence": "not-established-by-passive-destination-port-count",
            "observation": "probe-or-handshake-only",
            "packets": 2,
            "frame_bytes": 120,
            "payload_packets": 0,
            "payload_bytes": 0,
            "syn_without_ack_packets": 2,
            "scan_probe_packets": 2,
            "scan_response_packets": 0,
            "traffic_classes": [{"class": "scan-probe", "packets": 2}],
        }
        analysis = {
            "packets": 2,
            "bytes": 120,
            "duration_seconds": 1.0,
            "protocols": [{"protocol": "TCP", "count": 2}],
            "conversations": [],
            "top_endpoints": [],
            "destination_ports": [port_observation],
            "port_observations": [port_observation],
            "traffic_classes": [
                {
                    "class": "scan-probe",
                    "packets": 2,
                    "frame_bytes": 120,
                    "payload_packets": 0,
                    "payload_bytes": 0,
                    "classification_bases": [
                        {"basis": "local-to-target TCP SYN without ACK", "count": 2}
                    ],
                    "scan_ids": [],
                }
            ],
            "payload_summary": {
                "payload_packets": 0,
                "payload_bytes": 0,
                "zero_payload_packets": 2,
                "remote_origin_payload_packets": 0,
                "remote_origin_payload_bytes": 0,
            },
            "vlan_partitions": {},
        }
        analyses = [
            {
                "source_id": "source-1",
                "source_alias": "Synthetic VLAN",
                "analysis": analysis,
                "vlan_views": [],
                "vlan_attribution": [],
            }
        ]

        report = build_report(_state(), analyses, [], [], [], [])

        self.assertEqual(report["executive_summary"]["open_services"], 0)
        self.assertEqual(report["services"], [])
        observed = report["traffic_analysis"][0]["analysis"]["port_observations"][0]
        self.assertIsNone(observed["service_guess"])
        self.assertEqual(
            observed["service_evidence"],
            "not-established-by-passive-destination-port-count",
        )
        rendered = _render_html(report)
        self.assertIn("Observed destination-port activity — not listening services", rendered)
        self.assertIn("42042", rendered)
        self.assertIn("No explicit Nmap port records", rendered)

    def test_protected_services_are_retained_but_excluded_from_target_counts_and_findings(self) -> None:
        config = _config()
        assets = [
            {
                "id": "asset-local",
                "primary_address": "192.0.2.10",
                "status": "up",
                "sources": ["source-1"],
            },
            {
                "id": "asset-gateway",
                "primary_address": "192.0.2.1",
                "status": "up",
                "sources": ["source-1"],
            },
            {
                "id": "asset-ecu",
                "primary_address": "192.0.2.20",
                "status": "up",
                "sources": ["source-1"],
            },
        ]
        services = [
            {
                "id": "service-local",
                "asset_id": "asset-local",
                "address": "192.0.2.10",
                "source_id": "source-1",
                "protocol": "tcp",
                "port": 445,
                "state": "open",
                "service": "microsoft-ds",
                "scripts": [
                    {
                        "id": "smb-vuln-synthetic",
                        "output": "VULNERABLE synthetic test result",
                    }
                ],
            },
            {
                "id": "service-gateway",
                "asset_id": "asset-gateway",
                "address": "192.0.2.1",
                "source_id": "source-1",
                "protocol": "tcp",
                "port": 22,
                "state": "open",
                "service": "ssh",
                "scripts": [],
            },
            {
                "id": "service-ecu",
                "asset_id": "asset-ecu",
                "address": "192.0.2.20",
                "source_id": "source-1",
                "protocol": "tcp",
                "port": 13_400,
                "state": "open",
                "service": "doip",
                "scripts": [],
            },
        ]
        assets, services = annotate_inventory_scope(config, assets, services)
        findings = build_findings(config, [], services)

        report = build_report(_state(config), [], [], assets, services, findings)

        summary = report["executive_summary"]
        self.assertEqual(summary["assets"], 1)
        self.assertEqual(summary["all_observed_assets"], 3)
        self.assertEqual(summary["protected_host_or_gateway_assets"], 2)
        self.assertEqual(summary["open_services"], 1)
        self.assertEqual(len(report["services"]), 3)
        self.assertEqual(
            len(
                [
                    row
                    for row in report["services"]
                    if row.get("eligible_for_ecu_findings") is False
                ]
            ),
            2,
        )
        rendered_findings = json.dumps(report["findings"], sort_keys=True)
        self.assertNotIn("192.0.2.10", rendered_findings)
        self.assertNotIn("192.0.2.1", rendered_findings)
        self.assertIn("192.0.2.20", rendered_findings)
        test_cases = {row["id"]: row for row in report["test_case_matrix"]}
        self.assertIn("Open service records: 1", test_cases["Eth_TC_002"]["evidence_summary"])
        self.assertEqual(
            test_cases["Eth_TC_003"]["evidence_summary"],
            "Identified open services: 1 of 1 open service records.",
        )


if __name__ == "__main__":
    unittest.main()
