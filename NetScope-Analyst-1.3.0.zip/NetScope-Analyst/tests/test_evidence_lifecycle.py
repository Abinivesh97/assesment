from __future__ import annotations

import csv
import hashlib
import http.client
import json
import os
import socket
import tempfile
import threading
import unittest
import uuid
import zipfile
from copy import deepcopy
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest import mock

from netscope.findings import build_inventory
from netscope.reporting import _render_html, _write_csv, build_report, refresh_evidence_bundle
from netscope.scanner import run_scan_job
from netscope.server import _is_loopback_host, make_handler
from netscope.session import SessionManager
from netscope.validation import ValidationError


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


class EvidenceIntegrityTests(unittest.TestCase):
    def test_interrupted_state_is_persisted_and_audit_chain_verifies(self) -> None:
        session_id = "00000000-0000-0000-0000-000000000123"
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            session_dir = root / "sessions" / session_id
            session_dir.mkdir(parents=True)
            (session_dir / "state.json").write_text(
                json.dumps(
                    {
                        "id": session_id,
                        "name": "Interrupted bench",
                        "status": "capturing",
                        "created_at": "2026-01-01T00:00:00+00:00",
                        "ended_at": None,
                        "config": {"sources": []},
                        "errors": [],
                    }
                ),
                encoding="utf-8",
            )

            with mock.patch("netscope.session.system_snapshot", return_value={"tools": {}}):
                manager = SessionManager(root)

            state = json.loads((session_dir / "state.json").read_text(encoding="utf-8"))
            self.assertEqual(state["status"], "interrupted")
            self.assertIsNotNone(state["ended_at"])
            self.assertTrue(any("preserved" in item.lower() for item in state["errors"]))

            manager._audit(session_id, "evidence_reviewed", {"reviewer": "test"})  # noqa: SLF001
            entries = [
                json.loads(line)
                for line in (session_dir / "audit.jsonl").read_text(encoding="utf-8").splitlines()
                if line.strip()
            ]
            self.assertEqual([entry["event"] for entry in entries], ["session_interrupted", "evidence_reviewed"])
            self.assertEqual(entries[0]["previous_hash"], "")
            self.assertEqual(entries[1]["previous_hash"], entries[0]["entry_hash"])
            for entry in entries:
                stored_hash = entry["entry_hash"]
                canonical_entry = {key: value for key, value in entry.items() if key != "entry_hash"}
                canonical = json.dumps(
                    canonical_entry,
                    sort_keys=True,
                    separators=(",", ":"),
                    ensure_ascii=False,
                    default=str,
                )
                self.assertEqual(stored_hash, hashlib.sha256(canonical.encode("utf-8")).hexdigest())

    def test_manifest_hashes_raw_capture_but_default_bundle_excludes_it(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            session_dir = Path(temporary)
            (session_dir / "captures").mkdir()
            (session_dir / "nmap").mkdir()
            (session_dir / "analysis").mkdir()
            (session_dir / "reports").mkdir()
            files = {
                "state.json": b'{"status":"completed"}',
                "session-metadata.json": b'{"schema_version":"1.0"}',
                "audit.jsonl": b'{"event":"session_created"}\n',
                "captures/source-1.pcapng": b"raw-packet-evidence",
                "nmap/source-1.xml": b"<nmaprun/>",
                "analysis/source-1.json": b'{"packets":1}',
                "reports/report.html": b"<!doctype html><title>Report</title>",
            }
            for relative, data in files.items():
                (session_dir / relative).write_bytes(data)

            manifest_path, bundle_path = refresh_evidence_bundle(session_dir)
            manifest = manifest_path.read_text(encoding="utf-8").splitlines()
            manifest_by_path = {
                line.split("  ", 1)[1]: line.split("  ", 1)[0]
                for line in manifest
                if "  " in line
            }
            for relative in files:
                self.assertEqual(manifest_by_path[relative], _sha256(session_dir / relative))

            with zipfile.ZipFile(bundle_path) as bundle:
                names = set(bundle.namelist())
            self.assertIn("README.txt", names)
            self.assertIn("reports/sha256-manifest.txt", names)
            self.assertIn("state.json", names)
            self.assertIn("audit.jsonl", names)
            self.assertIn("nmap/source-1.xml", names)
            self.assertNotIn("captures/source-1.pcapng", names)

    def test_csv_neutralizes_spreadsheet_formulas(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "evidence.csv"
            _write_csv(
                output,
                ["value"],
                [
                    {"value": "=HYPERLINK(\"https://example.invalid\")"},
                    {"value": "  @SUM(1,2)"},
                    {"value": "-2+3"},
                    {"value": "+cmd"},
                    {"value": "ordinary"},
                ],
            )
            with output.open(newline="", encoding="utf-8-sig") as handle:
                values = [row["value"] for row in csv.DictReader(handle)]

        self.assertEqual(values[0], "'=HYPERLINK(\"https://example.invalid\")")
        self.assertEqual(values[1], "'  @SUM(1,2)")
        self.assertEqual(values[2], "'-2+3")
        self.assertEqual(values[3], "'+cmd")
        self.assertEqual(values[4], "ordinary")


class IsolationTests(unittest.TestCase):
    HOST = {
        "status": {"state": "up"},
        "addresses": [{"addr": "192.168.10.20", "addrtype": "ipv4"}],
        "hostnames": ["ecu"],
        "ports": [
            {
                "protocol": "tcp",
                "port": 13400,
                "state": "open",
                "reason": "syn-ack",
                "service": {"name": "doip"},
                "scripts": [],
            }
        ],
        "os_matches": [],
    }

    def test_same_address_on_two_sources_remains_two_assets(self) -> None:
        records = [
            {"source_id": "source-a", "parsed": {"hosts": [deepcopy(self.HOST)]}},
            {"source_id": "source-b", "parsed": {"hosts": [deepcopy(self.HOST)]}},
        ]
        assets, services = build_inventory(records)
        self.assertEqual(len(assets), 2)
        self.assertEqual(len({asset["id"] for asset in assets}), 2)
        self.assertEqual({tuple(asset["sources"]) for asset in assets}, {("source-a",), ("source-b",)})
        self.assertEqual(len(services), 2)
        self.assertEqual(len({service["asset_id"] for service in services}), 2)
        self.assertEqual({service["source_id"] for service in services}, {"source-a", "source-b"})

    def test_multi_vlan_report_excludes_unattributable_scan_service(self) -> None:
        source = {
            "source_id": "source-1",
            "alias": "Marvell trunk",
            "role": "mirror",
            "switch_port": "P3",
            "vlan_ids": [42, 43],
            "expected_ports": [13400],
            "interface": {
                "description": "VN5620",
                "provider": "dumpcap",
                "addresses": [],
            },
        }
        state = {
            "id": "00000000-0000-0000-0000-000000000456",
            "name": "Isolation bench",
            "status": "completed",
            "created_at": "2026-01-01T00:00:00+00:00",
            "started_at": "2026-01-01T00:00:00+00:00",
            "ended_at": "2026-01-01T00:01:00+00:00",
            "system": {},
            "config": {
                "operator": "Analyst",
                "authorization_note": "Approved",
                "automotive_mode": True,
                "topology_notes": "ECU to switch to VN5620",
                "sources": [source],
                "capture": {},
                "scan": {},
            },
            "captures": [],
            "scans": [
                {
                    "id": "scan-1",
                    "source_id": "source-1",
                    "profile": "quick_tcp",
                    "family": 4,
                    "command_display": "UNATTRIBUTABLE-NMAP-COMMAND",
                    "status": "completed",
                }
            ],
            "warnings": [],
            "errors": [],
            "test_cases": [],
        }
        analyses = [
            {
                "source_id": "source-1",
                "source_alias": "Marvell trunk",
                "analysis": {"packets": 10, "bytes": 1000, "vlan_partitions": {"42": {"packets": 7}}},
                "vlan_views": [
                    {
                        "vlan_id": 42,
                        "analysis": {
                            "packets": 7,
                            "bytes": 700,
                            "duration_seconds": 1.0,
                            "reported_capture_drops": 0,
                            "vlan_partitions": {"42": {"packets": 7, "bytes": 700}},
                            "protocols": [{"protocol": "UNIQUE-VLAN-42-PROTOCOL", "count": 7}],
                        },
                    }
                ],
            }
        ]
        assets = [{"id": "asset-1", "sources": ["source-1"], "primary_address": "192.168.10.20"}]
        services = [
            {
                "id": "service-1",
                "asset_id": "asset-1",
                "source_id": "source-1",
                "address": "192.168.10.20",
                "protocol": "tcp",
                "port": 13400,
                "state": "open",
                "service": "SERVICE-MUST-NOT-LEAK-INTO-VLAN",
            }
        ]
        findings = [
            {
                "id": "finding-1",
                "severity": "medium",
                "confidence": "medium",
                "status": "potential",
                "title": "FINDING-MUST-NOT-LEAK-INTO-VLAN",
                "description": "source-only active result",
                "remediation": "validate",
                "source_ids": ["source-1"],
                "evidence": [],
            }
        ]
        report = build_report(state, analyses, [], assets, services, findings)
        rendered = _render_html(report, source_id="source-1", vlan_id=42)

        self.assertIn("UNIQUE-VLAN-42-PROTOCOL", rendered)
        self.assertIn("traffic-only retained 802.1Q membership view", rendered)
        self.assertNotIn("SERVICE-MUST-NOT-LEAK-INTO-VLAN", rendered)
        self.assertNotIn("FINDING-MUST-NOT-LEAK-INTO-VLAN", rendered)
        self.assertNotIn("UNATTRIBUTABLE-NMAP-COMMAND", rendered)


class ScannerLifecycleTests(unittest.TestCase):
    def test_cancelled_job_never_starts_nmap(self) -> None:
        cancel = threading.Event()
        cancel.set()
        updates: list[dict] = []
        process_updates: list[tuple[str, object]] = []
        job = {
            "id": "source-1-quick_tcp-ipv4",
            "stderr_path": "unused.stderr.txt",
            "argv": ["nmap", "-sT", "192.168.10.20"],
            "status": "queued",
        }
        with mock.patch("netscope.scanner.subprocess.Popen") as popen:
            result = run_scan_job(
                job,
                cancel,
                lambda job_id, process: process_updates.append((job_id, process)),
                lambda update: updates.append(deepcopy(update)),
            )

        popen.assert_not_called()
        self.assertEqual(result["status"], "cancelled")
        self.assertIn("before the job started", result["error"])
        self.assertEqual([update["status"] for update in updates], ["cancelled"])
        self.assertEqual(process_updates, [])


class SessionManagerLifecycleTests(unittest.TestCase):
    def test_copied_session_rebases_legacy_absolute_artifact_path(self) -> None:
        session_id = "00000000-0000-0000-0000-000000000455"
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            session_dir = root / "sessions" / session_id
            report = session_dir / "reports" / "report.html"
            report.parent.mkdir(parents=True)
            report.write_text("local evidence", encoding="utf-8")
            state = {
                "id": session_id,
                "status": "completed",
                "artifacts": {
                    "report_html": str(
                        Path("Z:/retired-case-copy")
                        / session_id
                        / "reports"
                        / "report.html"
                    )
                },
            }
            (session_dir / "state.json").write_text(json.dumps(state), encoding="utf-8")
            with mock.patch("netscope.session.system_snapshot", return_value={"tools": {}}):
                manager = SessionManager(root)

            self.assertEqual(manager.artifact_path(session_id, "report_html"), report.resolve())

    def test_live_uuid_collision_preserves_preexisting_evidence_directory(self) -> None:
        session_id = "00000000-0000-0000-0000-000000000456"
        system = {
            "tools": {
                "dumpcap": {"available": False, "path": None},
                "tshark": {"available": False, "path": None},
                "nmap": {"available": True, "path": "nmap"},
            }
        }
        config = {
            "name": "Collision",
            "capture": {"enabled": False},
            "scan": {"enabled": True},
            "sources": [],
            "warnings": [],
        }
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with mock.patch("netscope.session.system_snapshot", return_value=system):
                manager = SessionManager(root)
            existing = manager.sessions_dir / session_id
            existing.mkdir()
            sentinel = existing / "existing-evidence.bin"
            sentinel.write_bytes(b"preserve-me")

            with (
                mock.patch.object(manager, "interfaces", return_value=[]),
                mock.patch("netscope.session.validate_session_config", return_value=config),
                mock.patch("netscope.session.build_scan_jobs", return_value=[]),
                mock.patch("netscope.session.uuid.uuid4", return_value=uuid.UUID(session_id)),
            ):
                with self.assertRaises(FileExistsError):
                    manager.start_session({})

            self.assertEqual(sentinel.read_bytes(), b"preserve-me")
            self.assertEqual(manager.list_sessions(), [])

    def test_import_failure_restores_staged_capture_and_removes_owned_directory(self) -> None:
        session_id = "00000000-0000-0000-0000-000000000457"
        system = {"tools": {"tshark": {"available": True, "path": "tshark"}}}
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            upload = root / "staged.pcapng"
            upload.write_bytes(b"packet-evidence")
            with mock.patch("netscope.session.system_snapshot", return_value=system):
                manager = SessionManager(root / "data")

            with (
                mock.patch("netscope.session.uuid.uuid4", return_value=uuid.UUID(session_id)),
                mock.patch.object(manager, "_write_metadata", side_effect=OSError("metadata write failed")),
            ):
                with self.assertRaises(OSError):
                    manager.import_capture(upload, "bench.pcapng", {})

            self.assertEqual(upload.read_bytes(), b"packet-evidence")
            self.assertFalse((manager.sessions_dir / session_id).exists())
            self.assertEqual(manager.list_sessions(), [])

    def test_import_rollback_preserves_destination_when_restore_fails(self) -> None:
        session_id = "00000000-0000-0000-0000-000000000458"
        system = {"tools": {"tshark": {"available": True, "path": "tshark"}}}
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            upload = root / "staged.pcapng"
            upload.write_bytes(b"packet-evidence")
            with mock.patch("netscope.session.system_snapshot", return_value=system):
                manager = SessionManager(root / "data")
            real_replace = os.replace

            def fail_restore(source: str | Path, target: str | Path) -> None:
                if Path(source).resolve() == upload.resolve():
                    real_replace(source, target)
                    return
                raise OSError("restore failed")

            with (
                mock.patch("netscope.session.uuid.uuid4", return_value=uuid.UUID(session_id)),
                mock.patch.object(manager, "_write_metadata", side_effect=OSError("metadata write failed")),
                mock.patch("netscope.session.os.replace", side_effect=fail_restore),
                mock.patch("netscope.session.shutil.move", side_effect=OSError("fallback restore failed")),
            ):
                with self.assertRaises(OSError):
                    manager.import_capture(upload, "bench.pcapng", {})

            destination = manager.sessions_dir / session_id / "captures" / "source-1-imported.pcapng"
            self.assertFalse(upload.exists())
            self.assertEqual(destination.read_bytes(), b"packet-evidence")
            self.assertEqual(manager.list_sessions(), [])

    def test_shutdown_wins_race_before_start_registration(self) -> None:
        system = {
            "tools": {
                "dumpcap": {"available": False, "path": None},
                "tshark": {"available": False, "path": None},
                "nmap": {"available": True, "path": "nmap"},
            }
        }
        config = {
            "name": "Closing race",
            "capture": {"enabled": False},
            "scan": {"enabled": True},
            "sources": [],
            "warnings": [],
        }
        entered = threading.Event()
        release = threading.Event()
        errors: list[BaseException] = []

        def blocked_interfaces() -> list:
            entered.set()
            release.wait(timeout=3)
            return []

        with tempfile.TemporaryDirectory() as temporary:
            with mock.patch("netscope.session.system_snapshot", return_value=system):
                manager = SessionManager(Path(temporary))
            with (
                mock.patch.object(manager, "interfaces", side_effect=blocked_interfaces),
                mock.patch("netscope.session.validate_session_config", return_value=config),
                mock.patch("netscope.session.build_scan_jobs", return_value=[]),
            ):
                thread = threading.Thread(
                    target=lambda: self._capture_start_error(manager, errors),
                    daemon=True,
                )
                thread.start()
                self.assertTrue(entered.wait(timeout=3))
                manager.shutdown()
                release.set()
                thread.join(timeout=3)

            self.assertFalse(thread.is_alive())
            self.assertEqual(len(errors), 1)
            self.assertIsInstance(errors[0], ValidationError)
            self.assertEqual(manager.list_sessions(), [])
            self.assertEqual(list(manager.sessions_dir.iterdir()), [])

    @staticmethod
    def _capture_start_error(manager: SessionManager, errors: list[BaseException]) -> None:
        try:
            manager.start_session({})
        except BaseException as exc:
            errors.append(exc)

    def test_report_failure_quiesces_processes_before_rebuilding_evidence(self) -> None:
        class FakeProcess:
            def __init__(self) -> None:
                self.returncode = None
                self.terminated = False
                self.waited = False

            def poll(self) -> int | None:
                return self.returncode

            def terminate(self) -> None:
                self.terminated = True

            def wait(self, timeout: float | None = None) -> int:
                self.waited = True
                self.returncode = -15
                return self.returncode

            def kill(self) -> None:
                self.returncode = -9

        session_id = "00000000-0000-0000-0000-000000000789"
        fake_process = FakeProcess()
        observations: list[tuple[bool, str, bool]] = []
        system = {"tools": {"tshark": {"path": None}}}
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with mock.patch("netscope.session.system_snapshot", return_value=system):
                manager = SessionManager(root)
            session_dir = manager._session_dir(session_id)  # noqa: SLF001
            session_dir.mkdir()
            state = {
                "id": session_id,
                "mode": "import",
                "name": "Report failure",
                "status": "queued",
                "created_at": "2026-01-01T00:00:00+00:00",
                "started_at": None,
                "ended_at": None,
                "config": {
                    "sources": [],
                    "capture": {"enabled": False},
                    "scan": {"enabled": False},
                },
                "system": system,
                "captures": [],
                "scans": [],
                "analyses": [],
                "assets": [],
                "services": [],
                "findings": [],
                "summary": {},
                "artifacts": {},
                "warnings": [],
                "errors": [],
            }
            with manager._lock:  # noqa: SLF001
                manager._states[session_id] = state  # noqa: SLF001
                manager._capture_stop[session_id] = threading.Event()  # noqa: SLF001
                manager._scan_stop[session_id] = threading.Event()  # noqa: SLF001
                manager._capture_processes[session_id] = {}  # noqa: SLF001
                manager._scan_processes[session_id] = {}  # noqa: SLF001
                manager._analysis_processes[session_id] = {}  # noqa: SLF001
                manager._audit_hashes[session_id] = ""  # noqa: SLF001
                manager._write_metadata(session_id, state)  # noqa: SLF001
                manager._write_state_dict(state)  # noqa: SLF001

            def fail_reports(target: Path, *_args: object) -> None:
                reports_dir = target / "reports"
                reports_dir.mkdir()
                (reports_dir / "report.json").write_text('{"status":"completed"}', encoding="utf-8")
                (reports_dir / "report.html").write_text("completed", encoding="utf-8")
                manager._register_capture_process(session_id, "late-process", fake_process)  # type: ignore[arg-type]  # noqa: SLF001
                raise RuntimeError("report rendering failed")

            def observe_refresh(target: Path) -> tuple[Path, Path]:
                saved = json.loads((target / "state.json").read_text(encoding="utf-8"))
                observations.append(
                    (
                        fake_process.waited,
                        saved["status"],
                        (target / "reports" / "report.html").exists(),
                    )
                )
                return (
                    target / "reports" / "sha256-manifest.txt",
                    target / "reports" / "reports-and-evidence.zip",
                )

            with (
                mock.patch("netscope.session.generate_reports", side_effect=fail_reports),
                mock.patch("netscope.session.refresh_evidence_bundle", side_effect=observe_refresh),
            ):
                manager._run_session(session_id)  # noqa: SLF001

            self.assertTrue(fake_process.terminated)
            self.assertTrue(fake_process.waited)
            self.assertEqual(observations, [(True, "failed", False)])
            self.assertFalse((session_dir / "reports" / "report.json").exists())
            self.assertEqual(manager.get_session(session_id)["status"], "failed")


class _DummyManager:
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.system = {"tools": {}}

    def interfaces(self) -> list:
        return []

    def list_sessions(self) -> list:
        return []

    def refresh_system(self) -> dict:
        return self.system

    def import_capture(self, _upload_path: Path, _original_filename: str, _metadata: dict) -> dict:
        raise OSError("forced import setup failure")


class ServerSecurityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls._temporary = tempfile.TemporaryDirectory()
        root = Path(cls._temporary.name)
        static_dir = root / "static"
        static_dir.mkdir()
        (static_dir / "index.html").write_text(
            '<!doctype html><meta name="netscope-token" content="__NETSCOPE_TOKEN__">',
            encoding="utf-8",
        )
        cls.token = "unit-test-token"
        handler = make_handler(_DummyManager(root), static_dir, cls.token)
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=3)
        cls._temporary.cleanup()

    def _request(
        self,
        method: str,
        path: str,
        *,
        host: str,
        token: str | None = None,
        body: bytes | None = None,
        headers: dict[str, str] | None = None,
    ) -> tuple[int, dict[str, str], bytes]:
        connection = http.client.HTTPConnection("127.0.0.1", self.server.server_address[1], timeout=3)
        connection.putrequest(method, path, skip_host=True)
        connection.putheader("Host", host)
        if token is not None:
            connection.putheader("X-NetScope-Token", token)
        for key, value in (headers or {}).items():
            connection.putheader(key, value)
        if body is not None:
            connection.putheader("Content-Type", "application/json")
            connection.putheader("Content-Length", str(len(body)))
        connection.endheaders(body)
        response = connection.getresponse()
        result = (response.status, dict(response.getheaders()), response.read())
        connection.close()
        return result

    def test_bind_host_validator_is_local_only(self) -> None:
        self.assertTrue(_is_loopback_host("127.0.0.1"))
        self.assertTrue(_is_loopback_host("localhost"))
        self.assertFalse(_is_loopback_host("0.0.0.0"))
        self.assertFalse(_is_loopback_host("192.168.10.10"))
        self.assertFalse(_is_loopback_host("example.com"))

    def test_valid_get_has_strict_security_headers(self) -> None:
        status, headers, body = self._request("GET", "/api/health", host="127.0.0.1")
        self.assertEqual(status, 200)
        self.assertIn(b'"ok": true', body)
        self.assertEqual(headers["Cache-Control"], "no-store")
        self.assertEqual(headers["X-Content-Type-Options"], "nosniff")
        self.assertEqual(headers["X-Frame-Options"], "DENY")
        self.assertIn("default-src 'self'", headers["Content-Security-Policy"])
        self.assertIn("object-src 'none'", headers["Content-Security-Policy"])

    def test_untrusted_host_is_rejected(self) -> None:
        status, _, body = self._request("GET", "/api/health", host="netscope.example.invalid")
        self.assertEqual(status, 403)
        self.assertIn(b"Host header rejected", body)

    def test_post_requires_matching_session_token(self) -> None:
        status, _, _ = self._request("POST", "/api/system/refresh", host="localhost")
        self.assertEqual(status, 403)
        status, _, body = self._request(
            "POST",
            "/api/system/refresh",
            host="localhost",
            token=self.token,
            body=b"{}",
        )
        self.assertEqual(status, 200)
        self.assertIn(b'"ok": true', body)

    def test_short_json_body_is_rejected(self) -> None:
        request = (
            f"POST /api/system/refresh HTTP/1.1\r\n"
            f"Host: localhost\r\n"
            f"X-NetScope-Token: {self.token}\r\n"
            "Content-Type: application/json\r\n"
            "Content-Length: 5\r\n"
            "Connection: close\r\n\r\n"
            "{}"
        ).encode("ascii")
        with socket.create_connection(self.server.server_address, timeout=3) as connection:
            connection.sendall(request)
            connection.shutdown(socket.SHUT_WR)
            response = b""
            while block := connection.recv(4096):
                response += block
        self.assertIn(b" 400 ", response.split(b"\r\n", 1)[0])
        self.assertIn(b"Request body ended early", response)

    def test_unexpected_import_failure_preserves_uploaded_capture(self) -> None:
        payload = b"pcap-evidence"
        status, _, body = self._request(
            "POST",
            "/api/import",
            host="localhost",
            token=self.token,
            body=payload,
            headers={"X-NetScope-Filename": "bench.pcapng"},
        )
        self.assertEqual(status, 500)
        self.assertIn(b"uploaded capture preserved", body)
        incoming = Path(self._temporary.name) / "incoming"
        retained = list(incoming.glob("*.failed-upload"))
        self.assertEqual(len(retained), 1)
        self.assertEqual(retained[0].read_bytes(), payload)


if __name__ == "__main__":
    unittest.main()
