from __future__ import annotations

import io
import json
import tempfile
import unittest
from copy import deepcopy
from pathlib import Path

from netscope.analysis import _consume_tshark_output
from netscope.privacy import protect_vin_text, stable_alias
from netscope.reporting import _render_html, build_report, generate_reports
from netscope.validation import ValidationError, validate_session_config
from netscope.vlan import build_vlan_views
from tests.test_core import sample_config, sample_interface


SYNTHETIC_VIN = "ZZZZZZZ0000000001"


class _CompletedTshark:
    def __init__(self, output: str):
        self.stdout = io.StringIO(output)

    def wait(self, timeout: float | None = None) -> int:
        return 0


def _report_fixture(include_vin: object = False, session_id: str = "00000000-0000-0000-0000-000000000901"):
    source = {
        "source_id": "source-1",
        "alias": "Synthetic automotive bench",
        "role": "VN interface",
        "switch_port": "mirror-1",
        "vlan_ids": [42],
        "expected_ports": [13400],
        "interface": {
            "name": "Synthetic VLAN 42",
            "description": "Synthetic capture adapter",
            "provider": "dumpcap",
            "mac": "02-00-00-00-00-10",
            "addresses": [{"address": "192.0.2.10", "family": "IPv4", "prefix_length": 24}],
        },
    }
    state = {
        "id": session_id,
        "name": "Synthetic privacy report",
        "status": "completed",
        "created_at": "2026-01-01T00:00:00+00:00",
        "started_at": "2026-01-01T00:00:00+00:00",
        "ended_at": "2026-01-01T00:01:00+00:00",
        "system": {},
        "config": {
            "operator": "Synthetic operator",
            "authorization_note": "Synthetic authorized bench",
            "topology_notes": f"Vehicle identity {SYNTHETIC_VIN}",
            "automotive_mode": True,
            "include_vin_in_reports": include_vin,
            "capture": {"enabled": True},
            "scan": {"enabled": True},
            "sources": [source],
        },
        "captures": [{"source_id": "source-1", "status": "completed", "path": "synthetic.pcapng"}],
        "scans": [],
        "warnings": [],
        "errors": [],
    }
    analyses = [
        {
            "source_id": "source-1",
            "source_alias": source["alias"],
            "analysis": {
                "packets": 5,
                "bytes": 500,
                "duration_seconds": 1.0,
                "protocols": [{"protocol": "DOIP", "count": 4}, {"protocol": "TCP", "count": 1}],
                "top_endpoints": [],
                "conversations": [
                    {
                        "protocol": "DOIP",
                        "endpoint_a": "192.0.2.10",
                        "endpoint_b": "192.0.2.20",
                        "packets": 4,
                        "bytes": 400,
                    },
                    {
                        "protocol": "TCP",
                        "endpoint_a": "192.0.2.20",
                        "endpoint_b": "192.0.2.30",
                        "packets": 1,
                        "bytes": 100,
                    },
                ],
                "packet_sample": [
                    {
                        "protocol": "DOIP",
                        "source": "192.0.2.20",
                        "destination": "192.0.2.10",
                        "destination_port": 13400,
                        "vlan_stack": [42],
                        "info": {"doip_vin": SYNTHETIC_VIN},
                    }
                ],
                "vlan_partitions": {"42": {"packets": 5, "bytes": 500}},
                "lldp_neighbors": [{"neighbor": "Synthetic Marvell switch", "count": 2}],
                "automotive": {"doip_vins": [{"value": SYNTHETIC_VIN, "count": 1}]},
            },
            "vlan_views": [],
        }
    ]
    analyses[0]["analysis"]["vlan_stacks"] = [{"stack": "42", "count": 5}]
    vlan_views, vlan_attribution, tag_preservation = build_vlan_views(
        analyses[0]["analysis"],
        [42],
        {42: {"analysis": deepcopy(analyses[0]["analysis"])}},
    )
    analyses[0].update(
        {
            "vlan_views": vlan_views,
            "vlan_attribution": vlan_attribution,
            "tag_preservation": tag_preservation,
        }
    )
    assets = [
        {
            "id": "asset-ecu",
            "primary_address": "192.0.2.20",
            "addresses": [
                {"addr": "192.0.2.20", "addrtype": "ipv4"},
                {"addr": "02:00:00:00:00:20", "addrtype": "mac"},
            ],
            "hostnames": ["synthetic-ecu"],
            "sources": ["source-1"],
            "status": "up",
        }
    ]
    services = [
        {
            "id": "service-doip",
            "asset_id": "asset-ecu",
            "source_id": "source-1",
            "address": "192.0.2.20",
            "protocol": "tcp",
            "port": 13400,
            "state": "open",
            "service": "doip",
            "scripts": [],
        }
    ]
    findings = [
        {
            "id": "finding-service",
            "severity": "medium",
            "confidence": "high",
            "status": "needs-review",
            "category": "exposure",
            "title": "Synthetic DoIP exposure",
            "description": "Synthetic service evidence",
            "remediation": "Validate locally",
            "source_ids": ["source-1"],
            "asset_ids": ["asset-ecu"],
            "service_ids": ["service-doip"],
            "cve_ids": [],
            "evidence": [],
        }
    ]
    return state, analyses, assets, services, findings


class PrivacyTopologyTests(unittest.TestCase):
    def test_privacy_alias_is_stable_per_session(self) -> None:
        first = protect_vin_text(SYNTHETIC_VIN, "session-a")
        self.assertEqual(first, protect_vin_text(SYNTHETIC_VIN, "session-a"))
        self.assertNotEqual(first, protect_vin_text(SYNTHETIC_VIN, "session-b"))
        self.assertNotIn(SYNTHETIC_VIN, first)

    def test_analysis_consumer_protects_vin_before_returning_derived_data(self) -> None:
        selected = [
            "frame.number",
            "frame.time_epoch",
            "frame.len",
            "_ws.col.Protocol",
            "ip.src",
            "ip.dst",
            "doip.vin",
        ]
        output = "\t".join(["1", "1.0", "64", "DOIP", "192.0.2.20", "192.0.2.10", SYNTHETIC_VIN]) + "\n"
        with tempfile.TemporaryDirectory() as temporary:
            capture_path = Path(temporary) / "synthetic.pcapng"
            capture_path.write_bytes(b"synthetic capture placeholder")
            result = _consume_tshark_output(
                _CompletedTshark(output),
                io.StringIO(""),
                capture_path,
                selected,
                [],
                10,
                False,
                "session-a",
                None,
            )
        rendered = json.dumps(result)
        self.assertNotIn(SYNTHETIC_VIN, rendered)
        self.assertIn("VIN-", rendered)

    def test_default_report_redacts_vin_and_maps_real_network_identifiers(self) -> None:
        state, analyses, assets, services, findings = _report_fixture(False)
        report = build_report(state, analyses, [], assets, services, findings)
        rendered = json.dumps(report)
        self.assertNotIn(SYNTHETIC_VIN, rendered)
        self.assertEqual(report["privacy"]["vin_handling"], "session-pseudonymized")
        topology = report["topology"]
        self.assertIn("192.0.2.20", rendered)
        self.assertIn("02:00:00:00:00:20", rendered)
        self.assertEqual({node["role"] for node in topology["nodes"]}, {"host", "ecu", "switch", "unknown"})
        self.assertTrue(any(42 in edge["vlan_ids"] and "DOIP" in edge["protocols"] for edge in topology["edges"]))
        ecu = next(node for node in topology["nodes"] if node["role"] == "ecu")
        finding = report["findings"][0]
        self.assertIn(ecu["alias"], finding["topology_aliases"])
        self.assertEqual(finding["vehicle_context"], ecu["vehicle_aliases"])
        self.assertEqual(
            ecu["id"],
            stable_alias("NODE", "asset:source-1:asset-ecu", state["id"], length=16).lower(),
        )

    def test_explicit_opt_in_keeps_vin_as_identity_not_vulnerability(self) -> None:
        state, analyses, assets, services, findings = _report_fixture(True)
        report = build_report(state, analyses, [], assets, services, findings)
        self.assertIn(SYNTHETIC_VIN, json.dumps(report))
        self.assertEqual(report["privacy"]["vin_handling"], "explicit-local-inclusion")
        self.assertEqual(len(report["findings"]), 1)
        self.assertNotIn(SYNTHETIC_VIN, report["findings"][0]["title"])
        self.assertEqual(report["findings"][0]["vehicle_context"], [SYNTHETIC_VIN])

    def test_source_only_finding_never_inherits_vehicle_identity(self) -> None:
        state, analyses, assets, services, findings = _report_fixture(True)
        findings[0]["asset_ids"] = []
        report = build_report(state, analyses, [], assets, services, findings)
        self.assertTrue(report["findings"][0]["topology_aliases"])
        self.assertEqual(report["findings"][0]["vehicle_context"], [])

    def test_non_boolean_false_never_enables_plaintext_vin(self) -> None:
        state, analyses, assets, services, findings = _report_fixture("false")
        report = build_report(state, analyses, [], assets, services, findings)
        self.assertNotIn(SYNTHETIC_VIN, json.dumps(report))
        raw = sample_config()
        raw["include_vin_in_reports"] = "false"
        with self.assertRaises(ValidationError):
            validate_session_config(raw, [sample_interface()])

    def test_validation_defaults_vin_off_and_accepts_explicit_true(self) -> None:
        raw = sample_config()
        self.assertFalse(validate_session_config(raw, [sample_interface()])["include_vin_in_reports"])
        raw["include_vin_in_reports"] = True
        self.assertTrue(validate_session_config(raw, [sample_interface()])["include_vin_in_reports"])

    def test_generated_html_and_csv_use_sanitized_report_data(self) -> None:
        state, analyses, assets, services, findings = _report_fixture(False)
        services[0]["extra_info"] = f"identity={SYNTHETIC_VIN}"
        with tempfile.TemporaryDirectory() as temporary:
            report, artifacts = generate_reports(
                Path(temporary),
                state,
                analyses,
                [],
                assets,
                services,
                findings,
            )
            html_text = Path(artifacts["report_html"]).read_text(encoding="utf-8")
            services_csv = Path(artifacts["services_csv"]).read_text(encoding="utf-8-sig")
            findings_csv = Path(artifacts["findings_csv"]).read_text(encoding="utf-8-sig")
            topology_csv = Path(artifacts["topology_nodes_csv"]).read_text(encoding="utf-8-sig")
        self.assertNotIn(SYNTHETIC_VIN, json.dumps(report))
        self.assertNotIn(SYNTHETIC_VIN, html_text)
        self.assertNotIn(SYNTHETIC_VIN, services_csv)
        self.assertNotIn(SYNTHETIC_VIN, findings_csv)
        self.assertNotIn(SYNTHETIC_VIN, topology_csv)
        self.assertIn("192.0.2.20", topology_csv)
        self.assertIn("Local network map", html_text)
        self.assertIn("Vehicle / VIN context", html_text)
        self.assertIn("vehicle_context", findings_csv)

    def test_scoped_report_does_not_render_another_sources_topology(self) -> None:
        state, analyses, assets, services, findings = _report_fixture(False)
        other_source = deepcopy(state["config"]["sources"][0])
        other_source.update(
            {
                "source_id": "source-2",
                "alias": "Synthetic isolated source",
                "interface": {
                    **other_source["interface"],
                    "name": "Synthetic VLAN 43",
                    "addresses": [{"address": "198.51.100.10", "family": "IPv4", "prefix_length": 24}],
                },
                "vlan_ids": [43],
            }
        )
        state["config"]["sources"].append(other_source)
        analyses.append(
            {
                "source_id": "source-2",
                "source_alias": other_source["alias"],
                "analysis": {
                    "packets": 1,
                    "bytes": 64,
                    "conversations": [
                        {
                            "protocol": "TCP",
                            "endpoint_a": "198.51.100.10",
                            "endpoint_b": "198.51.100.20",
                            "packets": 1,
                            "bytes": 64,
                        }
                    ],
                    "packet_sample": [],
                    "vlan_partitions": {"43": {"packets": 1, "bytes": 64}},
                },
                "vlan_views": [],
            }
        )
        report = build_report(state, analyses, [], assets, services, findings)
        scoped = _render_html(report, source_id="source-1")
        self.assertNotIn("198.51.100.20", scoped)
        self.assertNotIn("Synthetic isolated source", scoped)

    def test_aliases_are_repeatable_for_same_session_and_change_between_sessions(self) -> None:
        first = _report_fixture(False)
        second = deepcopy(first)
        report_a = build_report(first[0], first[1], [], first[2], first[3], first[4])
        report_b = build_report(second[0], second[1], [], second[2], second[3], second[4])
        aliases_a = sorted(node["alias"] for node in report_a["topology"]["nodes"])
        aliases_b = sorted(node["alias"] for node in report_b["topology"]["nodes"])
        self.assertEqual(aliases_a, aliases_b)

        other = _report_fixture(False, "00000000-0000-0000-0000-000000000902")
        report_c = build_report(other[0], other[1], [], other[2], other[3], other[4])
        aliases_c = sorted(node["alias"] for node in report_c["topology"]["nodes"])
        self.assertNotEqual(aliases_a, aliases_c)


if __name__ == "__main__":
    unittest.main()
