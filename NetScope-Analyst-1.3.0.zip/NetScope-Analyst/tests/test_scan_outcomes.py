from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from netscope.nmap_parser import classify_nmap_outcome, classify_nmap_result, parse_nmap_xml
from netscope.scanner import (
    build_scan_jobs,
    estimate_scan_schedule_floor_seconds,
    profile_feasibility,
)
from netscope.testcases import evaluate_test_cases


def _xml(host: str, hosts: str = '<hosts up="1" down="0" total="1"/>') -> str:
    return (
        '<?xml version="1.0"?>'
        '<nmaprun scanner="nmap" version="7.95">'
        '<scaninfo type="syn" protocol="tcp" numservices="100" services="1-100"/>'
        f"{host}"
        '<runstats><finished elapsed="1.23" exit="success"/>'
        f"{hosts}</runstats></nmaprun>"
    )


def _source(source_id: str, address: str) -> dict:
    return {
        "source_id": source_id,
        "interface_id": f"if-{source_id}",
        "alias": source_id,
        "interface": {
            "name": source_id,
            "nmap_name": f"eth-{source_id}",
            "if_index": 7,
            "addresses": [{"family": "IPv4", "address": "192.0.2.10", "prefix_length": 24}],
        },
        "targets": [address],
        "target_count": 1,
        "bind_interface": True,
        "expected_ports": [443],
        "scan_plan": {
            "manual_exclusions": [],
            "automatic_exclusions": [],
            "route_verification": [],
        },
    }


class NmapOutcomeTests(unittest.TestCase):
    def _parse(self, text: str) -> dict:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "scan.xml"
            path.write_text(text, encoding="utf-8")
            return parse_nmap_xml(path)

    def test_success_exit_with_host_timeout_is_partial(self) -> None:
        parsed = self._parse(
            _xml(
                '<host timedout="true"><status state="up" reason="arp-response"/>'
                '<address addr="192.0.2.20" addrtype="ipv4"/></host>'
            )
        )
        self.assertTrue(parsed["hosts"][0]["timed_out"])
        outcome = classify_nmap_result(
            parsed,
            process_status="completed",
            exit_code=0,
            profile="full_tcp",
        )
        self.assertEqual(outcome["classification"], "partial-timeout")
        self.assertEqual(outcome["timed_out_hosts"], 1)
        report_outcome = classify_nmap_outcome(parsed, "completed")
        self.assertEqual(report_outcome["status"], "partial")
        self.assertFalse(report_outcome["complete"])
        self.assertIn("absence of an open port is not a negative result", report_outcome["summary"])

    def test_extraports_and_reasons_are_preserved_as_complete_coverage(self) -> None:
        parsed = self._parse(
            _xml(
                '<host><status state="up" reason="arp-response"/>'
                '<address addr="192.0.2.20" addrtype="ipv4"/>'
                '<ports><extraports state="open|filtered" count="100">'
                '<extrareasons reason="no-response" count="100" proto="udp" ports="1-100"/>'
                '</extraports></ports></host>'
            )
        )
        aggregate = parsed["hosts"][0]["extraports"][0]
        self.assertEqual(aggregate["state"], "open|filtered")
        self.assertEqual(aggregate["count"], 100)
        self.assertEqual(aggregate["reasons"][0]["reason"], "no-response")
        outcome = classify_nmap_result(
            parsed,
            process_status="completed",
            exit_code=0,
            profile="quick_udp",
        )
        self.assertEqual(outcome["classification"], "complete")
        self.assertEqual(outcome["extraport_count"], 100)
        self.assertEqual(outcome["extraport_state_counts"], {"open|filtered": 100})
        self.assertEqual(classify_nmap_outcome(parsed, "completed")["status"], "completed")

    def test_success_exit_with_incomplete_port_state_coverage_is_inconclusive(self) -> None:
        parsed = self._parse(
            _xml(
                '<host><status state="up" reason="arp-response"/>'
                '<address addr="192.0.2.20" addrtype="ipv4"/>'
                '<ports><port protocol="tcp" portid="1"><state state="closed" reason="reset"/>'
                '</port><extraports state="filtered" count="50"/></ports></host>'
            )
        )
        outcome = classify_nmap_result(
            parsed,
            process_status="completed",
            exit_code=0,
            profile="full_tcp",
        )
        self.assertEqual(outcome["classification"], "inconclusive")
        self.assertEqual(outcome["reason"], "port-state-coverage-does-not-match-scaninfo")
        self.assertEqual(outcome["attempted_port_states_per_up_host"], 100)
        self.assertEqual(outcome["port_state_coverage"][0]["observed"], 51)

    def test_unresponsive_target_is_inconclusive_for_port_profile(self) -> None:
        parsed = self._parse(_xml("", '<hosts up="0" down="1" total="1"/>'))
        outcome = classify_nmap_result(parsed, process_status="completed", exit_code=0, profile="quick_tcp")
        self.assertEqual(outcome["classification"], "inconclusive")
        self.assertEqual(outcome["reason"], "no-target-was-observed-up")
        self.assertEqual(classify_nmap_outcome(parsed, "completed")["status"], "inconclusive")

    def test_failed_process_is_failed_even_with_valid_xml(self) -> None:
        parsed = self._parse(_xml(""))
        outcome = classify_nmap_result(parsed, process_status="cancelled", exit_code=1, profile="quick_tcp")
        self.assertEqual(outcome["classification"], "failed")

    def test_timed_out_port_scan_is_only_partial_test_case_evidence(self) -> None:
        parsed = self._parse(
            _xml(
                '<host timedout="true"><status state="up" reason="arp-response"/>'
                '<address addr="192.0.2.20" addrtype="ipv4"/></host>'
            )
        )
        outcome = classify_nmap_outcome(parsed, "completed", profile="full_udp")
        rows = evaluate_test_cases(
            {"scan": {"enabled": True}, "capture": {"enabled": False}},
            [],
            [],
            [],
            captures=[],
            scans=[
                {
                    "source_id": "source-1",
                    "profile": "full_udp",
                    "status": "completed",
                    "analysis_available": True,
                    "outcome": outcome,
                }
            ],
        )
        statuses = {row["id"]: row["status"] for row in rows}
        self.assertEqual(statuses["Eth_TC_002"], "partial-evidence")
        self.assertEqual(statuses["Eth_TC_003"], "partial-evidence")


class ScanPlanningTests(unittest.TestCase):
    def test_full_udp_timeout_is_raised_above_the_probe_floor(self) -> None:
        row = profile_feasibility("full_udp", 900, 50, 1, 2)
        self.assertEqual(row["estimated_probe_floor_seconds_per_host"], 2621.4)
        self.assertEqual(row["estimated_shared_rate_floor_seconds"], 5242.8)
        self.assertEqual(row["recommended_host_timeout_seconds"], 10786)
        self.assertEqual(row["effective_host_timeout_seconds"], 10786)
        self.assertTrue(row["timeout_auto_raised"])

    def test_non_full_profile_keeps_configured_timeout(self) -> None:
        row = profile_feasibility("quick_udp", 900, 50, 1, 2)
        self.assertEqual(row["effective_host_timeout_seconds"], 900)
        self.assertFalse(row["timeout_auto_raised"])

    def test_full_range_estimate_counts_port_zero_when_enabled(self) -> None:
        without_zero = profile_feasibility("full_udp", 900, 50, 1)
        with_zero = profile_feasibility(
            "full_udp",
            900,
            50,
            1,
            include_port_zero=True,
        )
        self.assertEqual(without_zero["estimated_port_count_per_host"], 65_535)
        self.assertEqual(with_zero["estimated_port_count_per_host"], 65_536)
        self.assertEqual(without_zero["estimated_probe_floor_seconds_per_host"], 2621.4)
        self.assertEqual(with_zero["estimated_probe_floor_seconds_per_host"], 2621.44)

    def test_schedule_floor_is_not_shorter_than_longest_indivisible_job(self) -> None:
        uneven = [
            {"estimated_minimum_seconds": 100},
            {"estimated_minimum_seconds": 10},
        ]
        balanced = [
            {"estimated_minimum_seconds": 60},
            {"estimated_minimum_seconds": 60},
            {"estimated_minimum_seconds": 60},
        ]
        self.assertEqual(estimate_scan_schedule_floor_seconds(uneven, 2), 100)
        self.assertEqual(estimate_scan_schedule_floor_seconds(balanced, 2), 90)

    def test_jobs_are_breadth_first_and_focused_ports_are_not_guessed(self) -> None:
        config = {
            "automotive_mode": True,
            "scan": {
                "enabled": True,
                "profiles": ["full_udp", "automotive_services", "host_discovery"],
                "include_port_zero": False,
                "timing": 2,
                "max_rate": 50,
                "max_retries": 1,
                "host_timeout_seconds": 900,
                "script_timeout_seconds": 120,
                "exclusions": [],
                "automatic_exclusions": [],
            },
            "sources": [
                _source("source-1", "192.0.2.20"),
                _source("source-2", "198.51.100.20"),
            ],
        }
        with tempfile.TemporaryDirectory() as temporary:
            jobs = build_scan_jobs("nmap", config, Path(temporary))
        self.assertEqual(
            [row["profile"] for row in jobs],
            [
                "host_discovery",
                "host_discovery",
                "automotive_services",
                "automotive_services",
                "full_udp",
                "full_udp",
            ],
        )
        focused = next(row for row in jobs if row["profile"] == "automotive_services")
        port_spec = focused["argv"][focused["argv"].index("-p") + 1]
        self.assertEqual(port_spec, "T:443,13400,U:443,13400,30490")
        self.assertNotIn("42042", port_spec)
        self.assertEqual(focused["binding_mode"], "mixed-raw-udp-and-validated-tcp-connect-route")
        full_udp = next(row for row in jobs if row["profile"] == "full_udp")
        timeout = full_udp["argv"][full_udp["argv"].index("--host-timeout") + 1]
        self.assertEqual(timeout, "5543s")
        self.assertEqual(full_udp["configured_host_timeout_seconds"], 900)
        self.assertEqual(full_udp["effective_host_timeout_seconds"], 5543)

    def test_operator_expected_port_is_included_only_when_supplied(self) -> None:
        source = _source("source-1", "192.0.2.20")
        source["expected_ports"] = [42_042]
        config = {
            "automotive_mode": True,
            "scan": {
                "enabled": True,
                "profiles": ["automotive_services"],
                "include_port_zero": False,
                "timing": 2,
                "max_rate": 50,
                "max_retries": 1,
                "host_timeout_seconds": 900,
                "script_timeout_seconds": 120,
                "exclusions": [],
                "automatic_exclusions": [],
            },
            "sources": [source],
        }
        with tempfile.TemporaryDirectory() as temporary:
            job = build_scan_jobs("nmap", config, Path(temporary))[0]
        port_spec = job["argv"][job["argv"].index("-p") + 1]
        self.assertIn("42042", port_spec)

    def test_job_propagates_port_zero_into_arguments_and_feasibility(self) -> None:
        config = {
            "automotive_mode": True,
            "scan": {
                "enabled": True,
                "profiles": ["full_tcp"],
                "include_port_zero": True,
                "timing": 2,
                "max_rate": 50,
                "max_retries": 1,
                "host_timeout_seconds": 900,
                "script_timeout_seconds": 120,
                "exclusions": [],
                "automatic_exclusions": [],
            },
            "sources": [_source("source-1", "192.0.2.20")],
        }
        with tempfile.TemporaryDirectory() as temporary:
            job = build_scan_jobs("nmap", config, Path(temporary))[0]
        self.assertEqual(job["argv"][job["argv"].index("-p") + 1], "0-65535")
        self.assertEqual(job["timeout_feasibility"]["estimated_port_count_per_host"], 65_536)


if __name__ == "__main__":
    unittest.main()
