from __future__ import annotations

import io
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import netscope.analysis as analysis_module
from netscope.analysis import _consume_tshark_output
from netscope.automotive_fields import (
    PROTOCOL_COLUMN_PSEUDO_FIELD,
    SAFE_MACSEC_MKA_FIELDS,
    available_someip_heuristics,
    deepest_protocol_label,
    flatten_resolved_fields,
    parse_heuristic_registry,
    resolve_semantic_fields,
    safe_macsec_mka_fields,
    semantic_values,
    someip_heuristic_cli_args,
    validate_macsec_mka_selection,
)


class _CompletedTshark:
    def __init__(self, output: str):
        self.stdout = io.StringIO(output)

    def wait(self, timeout: float | None = None) -> int:
        return 0

    def poll(self) -> int:
        return 0


class _CompletedRegistryQuery:
    def __init__(self, output: str):
        self.output = output
        self.returncode = 0

    def communicate(self, timeout: float | None = None) -> tuple[str, str]:
        return self.output, ""

    def poll(self) -> int:
        return 0


def _consume_synthetic(
    selected: list[str],
    rows: list[list[str]],
    *,
    available_heuristics: tuple[str, ...] = (
        "someip_udp_heur",
        "someip_tcp_heur",
    ),
    enabled_heuristics: tuple[str, ...] = (
        "someip_udp_heur",
        "someip_tcp_heur",
    ),
) -> dict:
    output = "".join("\t".join(row) + "\n" for row in rows)
    with tempfile.TemporaryDirectory() as temporary:
        capture_path = Path(temporary) / "synthetic.pcapng"
        capture_path.write_bytes(b"synthetic capture placeholder")
        return _consume_tshark_output(
            _CompletedTshark(output),
            io.StringIO(""),
            capture_path,
            selected,
            [],
            10,
            False,
            "synthetic-session",
            None,
            semantic_fields=resolve_semantic_fields(selected),
            someip_heuristics_available=available_heuristics,
            someip_heuristics_enabled=enabled_heuristics,
        )


class AutomotiveFieldCompatibilityTests(unittest.TestCase):
    def test_resolves_current_tshark_names(self) -> None:
        available = {
            "frame.protocols",
            "someip.protoversion",
            "someipsd.option.ipv4address",
            "someipsd.option.ipv6address",
            "doip.type",
            "doip.response_code",
            "ptp.v2.clockidentity",
            "ptp.v2.an.grandmasterclockidentity",
            "ptp.v2.flags.twostep",
        }
        resolved = resolve_semantic_fields(available)
        self.assertEqual(resolved["protocol_stack"], ("frame.protocols",))
        self.assertEqual(
            resolved["someip_protocol_version"], ("someip.protoversion",)
        )
        self.assertEqual(
            resolved["someipsd_ipv4_address"],
            ("someipsd.option.ipv4address",),
        )
        self.assertEqual(resolved["doip_payload_type"], ("doip.type",))
        self.assertEqual(
            resolved["doip_routing_activation_response"],
            ("doip.response_code",),
        )
        self.assertEqual(
            resolved["ptp_source_clock_identity"], ("ptp.v2.clockidentity",)
        )
        self.assertEqual(
            resolved["ptp_announce_grandmaster_identity"],
            ("ptp.v2.an.grandmasterclockidentity",),
        )
        self.assertEqual(resolved["ptp_two_step"], ("ptp.v2.flags.twostep",))

    def test_resolves_legacy_aliases_without_mixing_ptp_roles(self) -> None:
        available = {
            "someip.protover",
            "someipsd.option.ipv4_address",
            "someipsd.option.ipv6_address",
            "doip.payload_type",
            "doip.routing_activation_response",
            "ptp.v2.clockidentity",
            "ptp.v2.grandmasteridentity",
            "ptp.v2.flags.twoStep",
        }
        resolved = resolve_semantic_fields(available)
        self.assertEqual(
            resolved["someip_protocol_version"], ("someip.protover",)
        )
        self.assertEqual(
            resolved["someipsd_ipv6_address"],
            ("someipsd.option.ipv6_address",),
        )
        self.assertEqual(
            resolved["doip_payload_type"], ("doip.payload_type",)
        )
        self.assertEqual(
            resolved["ptp_source_clock_identity"], ("ptp.v2.clockidentity",)
        )
        self.assertEqual(
            resolved["ptp_announce_grandmaster_identity"],
            ("ptp.v2.grandmasteridentity",),
        )
        self.assertNotEqual(
            resolved["ptp_source_clock_identity"],
            resolved["ptp_announce_grandmaster_identity"],
        )

    def test_protocol_column_is_only_a_registry_fallback(self) -> None:
        resolved = resolve_semantic_fields(set())
        self.assertEqual(
            resolved["protocol_stack"], (PROTOCOL_COLUMN_PSEUDO_FIELD,)
        )
        without_pseudo = resolve_semantic_fields(
            set(), allow_protocol_column_pseudo_field=False
        )
        self.assertNotIn("protocol_stack", without_pseudo)

    def test_collects_all_avtp_and_frer_variants(self) -> None:
        available = {
            "aaf.stream_id",
            "crf.stream_id",
            "iec61883.stream_id",
            "aaf.seqnum",
            "crf.seqnum",
            "iec61883.seqnum",
            "ieee1722.encapsulation_sequence_num",
            "ieee8021cb.seq",
            "rtag.seqno",
        }
        resolved = resolve_semantic_fields(available)
        self.assertEqual(
            resolved["avtp_stream_id"],
            ("aaf.stream_id", "crf.stream_id", "iec61883.stream_id"),
        )
        self.assertEqual(
            resolved["avtp_sequence_number"],
            (
                "aaf.seqnum",
                "crf.seqnum",
                "iec61883.seqnum",
                "ieee1722.encapsulation_sequence_num",
            ),
        )
        self.assertEqual(
            resolved["frer_sequence_number"],
            ("ieee8021cb.seq", "rtag.seqno"),
        )

    def test_flattens_fields_and_reads_multi_source_semantics(self) -> None:
        resolved = {
            "one": ("field.a",),
            "many": ("field.a", "field.b", "field.c"),
        }
        self.assertEqual(
            flatten_resolved_fields(resolved),
            ("field.a", "field.b", "field.c"),
        )
        row = {"field.a": "", "field.b": "STREAM_A", "field.c": "STREAM_B"}
        self.assertEqual(
            semantic_values(row, resolved, "many"), ("STREAM_A", "STREAM_B")
        )

    def test_deepest_protocol_label_uses_registered_stack(self) -> None:
        self.assertEqual(
            deepest_protocol_label("eth:ethertype:ip:udp:someip:someipsd"),
            "SOME/IP-SD",
        )
        self.assertEqual(
            deepest_protocol_label("eth:ethertype:doip:uds"), "UDS"
        )
        self.assertEqual(
            deepest_protocol_label("", column_fallback="DoIP"), "DoIP"
        )
        self.assertEqual(deepest_protocol_label(""), "Unknown")


class AutomotiveHeuristicRegistryTests(unittest.TestCase):
    REGISTRY = (
        "udp\tsomeip\tF\tF\tsomeip_udp_heur\tSOME/IP over UDP\n"
        "tcp\tsomeip\tF\tF\tsomeip_tcp_heur\tSOME/IP over TCP\n"
        "udp\tother\tT\tT\tother_udp_heur\tSynthetic protocol\n"
        "malformed\n"
    )

    def test_parses_exact_short_names(self) -> None:
        parsed = parse_heuristic_registry(self.REGISTRY)
        self.assertIn("someip_udp_heur", parsed)
        self.assertIn("someip_tcp_heur", parsed)
        self.assertNotIn("someip_udp", parsed)
        self.assertEqual(
            available_someip_heuristics(self.REGISTRY),
            ("someip_udp_heur", "someip_tcp_heur"),
        )

    def test_builds_allowlisted_cli_arguments(self) -> None:
        self.assertEqual(
            someip_heuristic_cli_args(
                ("someip_udp_heur", "someip_tcp_heur")
            ),
            (
                "--enable-heuristic",
                "someip_udp_heur",
                "--enable-heuristic",
                "someip_tcp_heur",
            ),
        )
        with self.assertRaises(ValueError):
            someip_heuristic_cli_args(("synthetic_unknown_heur",))

    def test_analysis_queries_the_exact_tshark_heuristic_registry(self) -> None:
        process = _CompletedRegistryQuery(self.REGISTRY)
        with patch.object(
            analysis_module.subprocess,
            "Popen",
            return_value=process,
        ) as popen:
            available = analysis_module.available_tshark_heuristics(
                "synthetic-tshark"
            )
        self.assertEqual(
            available,
            {"someip_udp_heur", "someip_tcp_heur", "other_udp_heur"},
        )
        self.assertEqual(
            popen.call_args.args[0],
            ["synthetic-tshark", "-G", "heuristic-decodes"],
        )


class MacsecMkaSafetyTests(unittest.TestCase):
    def test_safe_allowlist_contains_policy_metadata(self) -> None:
        available = {
            "macsec.TCI.E",
            "macsec.PN",
            "mka.key_server",
            "mka.macsec_cipher_suite",
            "mka.aes_key_wrap_unwrapped_sak",
        }
        selected = safe_macsec_mka_fields(available)
        self.assertIn("macsec.TCI.E", selected)
        self.assertIn("mka.key_server", selected)
        self.assertNotIn("mka.aes_key_wrap_unwrapped_sak", selected)
        self.assertTrue(set(selected).issubset(SAFE_MACSEC_MKA_FIELDS))

    def test_rejects_key_material_and_decrypted_data_fields(self) -> None:
        for unsafe in (
            "mka.aes_key_wrap_sak",
            "mka.aes_key_wrap_unwrapped_sak",
            "macsec.verify_info.sak",
            "macsec.verify_info.psk",
            "macsec.decrypted_data",
        ):
            with self.subTest(field=unsafe):
                with self.assertRaises(ValueError):
                    validate_macsec_mka_selection((unsafe,))

    def test_accepts_only_explicitly_safe_metadata(self) -> None:
        validate_macsec_mka_selection(
            ("macsec.TCI.E", "macsec.PN", "mka.macsec_capability")
        )


class AutomotiveAnalysisIntegrationTests(unittest.TestCase):
    def test_consumer_uses_registered_protocol_stack_and_semantic_fields(self) -> None:
        selected = [
            "frame.number",
            "frame.time_epoch",
            "frame.len",
            "frame.protocols",
            "someip.serviceid",
            "someip.methodid",
            "someipsd.option.ipv4address",
            "doip.type",
            "uds.sid",
            "aaf.stream_id",
            "aaf.seqnum",
            "ieee8021cb.seq",
            "macsec.TCI.E",
            "macsec.SCI.system_identifier",
            "macsec.SCI.port_identifier",
            "mka.sci",
            "mka.macsec_cipher_suite",
        ]
        row = [
            "1",
            "1.0",
            "128",
            "eth:ethertype:ip:udp:someip:someipsd",
            "SERVICE_A",
            "METHOD_A",
            "192.0.2.50",
            "TYPE_A",
            "SERVICE_DIAG_A",
            "STREAM_A",
            "7",
            "11",
            "1",
            "SYSTEM_A",
            "PORT_A",
            "PARTICIPANT_A",
            "CIPHER_A",
        ]
        result = _consume_synthetic(selected, [row])
        self.assertEqual(
            result["protocols"], [{"protocol": "SOME/IP-SD", "count": 1}]
        )
        automotive = result["automotive"]
        self.assertEqual(
            automotive["someip_sd_ipv4_endpoints"][0]["value"],
            "192.0.2.50",
        )
        self.assertEqual(automotive["avtp_streams"][0]["value"], "STREAM_A")
        self.assertEqual(automotive["frer_sequence_numbers"][0]["value"], "11")
        self.assertEqual(
            automotive["macsec_security_channels"][0]["value"],
            "system=SYSTEM_A port=PORT_A",
        )
        self.assertEqual(
            automotive["mka_cipher_suites"][0]["value"], "CIPHER_A"
        )
        self.assertEqual(result["packet_sample"][0]["info"]["doip_type"], "TYPE_A")

    def test_ptp_source_clocks_are_never_counted_as_grandmasters(self) -> None:
        selected = [
            "frame.number",
            "frame.time_epoch",
            "frame.len",
            "frame.protocols",
            "ptp.v2.clockidentity",
            "ptp.v2.an.grandmasterclockidentity",
        ]
        rows = [
            ["1", "1.0", "64", "eth:ethertype:ptp", "CLOCK_A", "GM_A"],
            ["2", "2.0", "64", "eth:ethertype:ptp", "CLOCK_B", "GM_A"],
            ["3", "3.0", "64", "eth:ethertype:ptp", "CLOCK_C", ""],
        ]
        automotive = _consume_synthetic(selected, rows)["automotive"]
        self.assertEqual(
            {row["value"] for row in automotive["ptp_source_clocks"]},
            {"CLOCK_A", "CLOCK_B", "CLOCK_C"},
        )
        self.assertEqual(
            automotive["ptp_grandmasters"],
            [{"value": "GM_A", "count": 2}],
        )

    def test_consumer_records_heuristic_coverage_and_missing_warning(self) -> None:
        selected = [
            "frame.number",
            "frame.time_epoch",
            "frame.len",
            "frame.protocols",
        ]
        result = _consume_synthetic(
            selected,
            [],
            available_heuristics=("someip_udp_heur",),
            enabled_heuristics=("someip_udp_heur",),
        )
        self.assertEqual(
            result["tshark_heuristics"],
            {
                "requested": ["someip_udp_heur", "someip_tcp_heur"],
                "available": ["someip_udp_heur"],
                "enabled": ["someip_udp_heur"],
            },
        )
        self.assertTrue(
            any(
                "someip_tcp_heur" in warning
                for warning in result["analysis_warnings"]
            )
        )

    def test_analyze_capture_enables_only_available_exact_heuristics_and_safe_metadata(
        self,
    ) -> None:
        fields = {
            "frame.number",
            "frame.time_epoch",
            "frame.len",
            "frame.protocols",
            "someip.serviceid",
            "macsec.TCI.E",
            "mka.key_server",
            "macsec.invalid_secret",
            "mka.invalid_key_material",
        }
        process = _CompletedTshark("")
        with tempfile.TemporaryDirectory() as temporary:
            capture_path = Path(temporary) / "synthetic.pcapng"
            capture_path.write_bytes(b"synthetic capture placeholder")
            with (
                patch.object(
                    analysis_module,
                    "available_tshark_fields",
                    return_value=fields,
                ),
                patch.object(
                    analysis_module,
                    "available_tshark_heuristics",
                    return_value={"someip_udp_heur"},
                ),
                patch.object(
                    analysis_module.subprocess,
                    "Popen",
                    return_value=process,
                ) as popen,
            ):
                result = analysis_module.analyze_capture(
                    "synthetic-tshark",
                    capture_path,
                )
        argv = popen.call_args.args[0]
        self.assertIn(
            ["--enable-heuristic", "someip_udp_heur"],
            [argv[index : index + 2] for index in range(len(argv) - 1)],
        )
        self.assertNotIn("someip_tcp_heur", argv)
        self.assertIn("macsec.TCI.E", argv)
        self.assertIn("mka.key_server", argv)
        self.assertNotIn("macsec.invalid_secret", argv)
        self.assertNotIn("mka.invalid_key_material", argv)
        self.assertEqual(
            result["tshark_heuristics"]["enabled"], ["someip_udp_heur"]
        )


if __name__ == "__main__":
    unittest.main()
