from __future__ import annotations

import unittest

from netscope.reporting import _render_html, build_report
from netscope.vlan import build_vlan_views


def _analysis(total: int, *, untagged: int, tagged: dict[int, int], packet_vlans: list[int]) -> dict:
    return {
        "packets": total,
        "bytes": total * 64,
        "duration_seconds": 1.0,
        "reported_capture_drops": 0,
        "protocols": [{"protocol": "DOIP", "count": total}],
        "vlan_partitions": {
            "untagged": {"packets": untagged, "bytes": untagged * 64},
            **{
                str(vlan_id): {"packets": count, "bytes": count * 64}
                for vlan_id, count in tagged.items()
            },
        },
        "vlan_stacks": (
            [{"stack": "/".join(map(str, tagged)), "count": max(tagged.values())}]
            if tagged
            else []
        ),
        "conversations": [
            {
                "protocol": "DOIP",
                "endpoint_a": "192.0.2.10",
                "endpoint_b": "192.0.2.20",
                "packets": total,
                "bytes": total * 64,
            }
        ],
        "packet_sample": [
            {
                "protocol": "DOIP",
                "source": "192.0.2.20",
                "destination": "192.0.2.10",
                "destination_port": 13400,
                "vlan_stack": packet_vlans,
                "info": {},
            }
        ],
        "top_endpoints": [],
        "destination_ports": [],
        "dns_names": [],
        "tls_server_names": [],
        "http_hosts": [],
        "lldp_neighbors": [],
        "tcp_events": {},
        "automotive": {},
        "automotive_expert_events": [],
    }


def _source(configured_vlans: list[int]) -> dict:
    return {
        "source_id": "source-1",
        "alias": "Synthetic VLAN source",
        "role": "VN channel",
        "switch_port": "mirror-test",
        "vlan_ids": configured_vlans,
        "expected_ports": [13400],
        "interface": {
            "name": "Synthetic adapter",
            "provider": "tshark",
            "addresses": [{"address": "192.0.2.10", "family": "IPv4", "prefix_length": 24}],
        },
    }


def _wrapper(
    analysis: dict,
    configured_vlans: list[int],
    observed_vlan_ids: list[int],
) -> dict:
    observed = {
        vlan_id: {
            "analysis": _analysis(
                int(analysis["vlan_partitions"][str(vlan_id)]["packets"]),
                untagged=0,
                tagged={vlan_id: int(analysis["vlan_partitions"][str(vlan_id)]["packets"])},
                packet_vlans=[vlan_id],
            )
        }
        for vlan_id in observed_vlan_ids
    }
    views, attribution, preservation = build_vlan_views(analysis, configured_vlans, observed)
    return {
        "source_id": "source-1",
        "source_alias": "Synthetic VLAN source",
        "analysis": analysis,
        "vlan_views": views,
        "vlan_attribution": attribution,
        "tag_preservation": preservation,
    }


def _report(source: dict, wrapper: dict) -> dict:
    state = {
        "id": "00000000-0000-4000-8000-000000000808",
        "name": "Synthetic VLAN report",
        "status": "completed",
        "created_at": "2026-01-01T00:00:00+00:00",
        "started_at": "2026-01-01T00:00:00+00:00",
        "ended_at": "2026-01-01T00:01:00+00:00",
        "system": {},
        "config": {
            "automotive_mode": True,
            "include_vin_in_reports": False,
            "capture": {"enabled": True},
            "scan": {"enabled": True},
            "sources": [source],
        },
        "captures": [
            {
                "source_id": "source-1",
                "status": "completed",
                "command_display": "synthetic capture command",
            }
        ],
        "scans": [
            {
                "id": "scan-1",
                "source_id": "source-1",
                "profile": "quick_tcp",
                "family": 4,
                "status": "completed",
                "command_display": "SCAN-COMMAND-CANARY",
            }
        ],
        "warnings": [],
        "errors": [],
    }
    assets = [
        {
            "id": "asset-1",
            "primary_address": "192.0.2.20",
            "addresses": [{"addr": "192.0.2.20", "addrtype": "ipv4"}],
            "hostnames": [],
            "sources": ["source-1"],
            "status": "up",
        }
    ]
    services = [
        {
            "id": "service-1",
            "asset_id": "asset-1",
            "source_id": "source-1",
            "address": "192.0.2.20",
            "protocol": "tcp",
            "port": 13400,
            "state": "open",
            "service": "doip",
            "product": "SCAN-ONLY-CANARY",
            "scripts": [],
        }
    ]
    return build_report(state, [wrapper], [], assets, services, [])


class VlanReportingTopologyTests(unittest.TestCase):
    def test_configured_source_projects_logical_vlan_and_renders_banner(self) -> None:
        analysis = _analysis(10, untagged=10, tagged={}, packet_vlans=[])
        wrapper = _wrapper(analysis, [68], [])
        report = _report(_source([68]), wrapper)

        self.assertEqual(wrapper["vlan_attribution"][0]["basis"], "configured-source")
        for node in report["topology"]["nodes"]:
            if node.get("addresses") and "192.0.2.20" in node["addresses"]:
                self.assertIn(68, node["vlan_ids"])
                self.assertIn("configured-source", node["vlan_evidence"][0]["bases"])
        flow = next(row for row in report["topology"]["edges"] if row["relation"] == "communicates-with")
        self.assertIn(68, flow["vlan_ids"])
        self.assertIn("configured-source", flow["vlan_evidence"][0]["bases"])

        combined = _render_html(report)
        source_html = _render_html(report, source_id="source-1")
        vlan_html = _render_html(report, source_id="source-1", vlan_id=68)
        for rendered in (combined, source_html):
            self.assertIn("Tag preservation + VLAN attribution", rendered)
            self.assertIn("configured-source", rendered)
            self.assertIn("Retained 802.1Q membership views", rendered)
            self.assertIn("QinQ frames can appear in more than one VLAN view", rendered)
        self.assertIn("VLAN attribution statement", vlan_html)
        self.assertIn("Basis:</strong> configured-source", vlan_html)
        self.assertIn("Confidence:</strong> medium", vlan_html)
        self.assertIn("Tagged / total:</strong> 0 / 10", vlan_html)
        self.assertIn("No 802.1Q tag was retained", vlan_html)
        self.assertIn("SCAN-ONLY-CANARY", vlan_html)
        self.assertIn("SCAN-COMMAND-CANARY", vlan_html)

    def test_multi_configured_untagged_traffic_is_never_guessed(self) -> None:
        analysis = _analysis(20, untagged=20, tagged={}, packet_vlans=[])
        wrapper = _wrapper(analysis, [68, 69], [])
        report = _report(_source([68, 69]), wrapper)

        self.assertEqual({row["basis"] for row in wrapper["vlan_attribution"]}, {"unattributable"})
        self.assertTrue(all(not node["vlan_ids"] for node in report["topology"]["nodes"]))
        self.assertTrue(all(not edge["vlan_ids"] for edge in report["topology"]["edges"]))
        catalog = {row["vlan_id"]: row for row in report["topology"]["vlans"]}
        self.assertEqual(set(catalog), {68, 69})
        self.assertEqual(catalog[68]["evidence_bases"], ["unattributable"])
        rendered = _render_html(report)
        self.assertIn("unattributable", rendered)
        self.assertIn("No nodes assigned; attribution is informational only", rendered)

    def test_multi_configured_observed_view_remains_traffic_only(self) -> None:
        analysis = _analysis(10, untagged=5, tagged={68: 5}, packet_vlans=[68])
        wrapper = _wrapper(analysis, [68, 69], [68])
        report = _report(_source([68, 69]), wrapper)
        vlan_html = _render_html(report, source_id="source-1", vlan_id=68)

        self.assertIn("Basis:</strong> configured-and-observed", vlan_html)
        self.assertIn("Confidence:</strong> high", vlan_html)
        self.assertIn("Tagged / total:</strong> 5 / 10", vlan_html)
        self.assertIn("no — traffic evidence only", vlan_html)
        self.assertNotIn("SCAN-ONLY-CANARY", vlan_html)
        self.assertNotIn("SCAN-COMMAND-CANARY", vlan_html)
        flow = next(row for row in report["topology"]["edges"] if 68 in row["vlan_ids"])
        evidence = next(item for item in flow["vlan_evidence"] if item["vlan_id"] == 68)
        self.assertEqual(evidence["bases"], ["observed-8021q"])

    def test_qinq_memberships_overlap_with_observed_basis(self) -> None:
        analysis = _analysis(5, untagged=0, tagged={68: 5, 144: 5}, packet_vlans=[68, 144])
        wrapper = _wrapper(analysis, [], [68, 144])
        report = _report(_source([]), wrapper)
        flow = next(row for row in report["topology"]["edges"] if row["relation"] == "communicates-with")

        self.assertEqual(flow["vlan_ids"], [68, 144])
        evidence = {row["vlan_id"]: row["bases"] for row in flow["vlan_evidence"]}
        self.assertEqual(evidence, {68: ["observed-8021q"], 144: ["observed-8021q"]})
        rendered = _render_html(report, source_id="source-1", vlan_id=144)
        self.assertIn("Basis:</strong> observed-8021q", rendered)
        self.assertIn("QinQ frames can appear in more than one VLAN view", rendered)
        self.assertNotIn("SCAN-ONLY-CANARY", rendered)


if __name__ == "__main__":
    unittest.main()
