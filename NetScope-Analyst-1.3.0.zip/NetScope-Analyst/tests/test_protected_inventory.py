from __future__ import annotations

import unittest

from netscope.findings import annotate_inventory_scope, build_findings


class ProtectedInventoryTests(unittest.TestCase):
    def test_local_and_gateway_results_cannot_become_ecu_findings(self) -> None:
        config = {
            "scan": {"automatic_exclusions": ["192.0.2.4/32", "192.0.2.1/32"]},
            "sources": [
                {
                    "source_id": "source-1",
                    "expected_ports": [13400],
                    "interface": {
                        "addresses": [
                            {"family": "IPv4", "address": "192.0.2.4"},
                        ]
                    },
                }
            ],
        }
        assets = [
            {"id": "host", "primary_address": "192.0.2.4"},
            {"id": "gateway", "primary_address": "192.0.2.1"},
            {"id": "ecu", "primary_address": "192.0.2.20"},
        ]
        services = [
            {
                "id": "host-smb",
                "asset_id": "host",
                "address": "192.0.2.4",
                "source_id": "source-1",
                "protocol": "tcp",
                "port": 445,
                "state": "open",
                "scripts": [],
            },
            {
                "id": "gateway-ssh",
                "asset_id": "gateway",
                "address": "192.0.2.1",
                "source_id": "source-1",
                "protocol": "tcp",
                "port": 22,
                "state": "open",
                "scripts": [],
            },
            {
                "id": "ecu-doip",
                "asset_id": "ecu",
                "address": "192.0.2.20",
                "source_id": "source-1",
                "protocol": "tcp",
                "port": 13400,
                "state": "open",
                "scripts": [],
            },
        ]

        annotated_assets, annotated_services = annotate_inventory_scope(
            config, assets, services
        )
        roles = {row["id"]: row["scope_role"] for row in annotated_assets}
        self.assertEqual(roles["host"], "local-test-host")
        self.assertEqual(roles["gateway"], "protected-host-or-gateway")
        self.assertEqual(roles["ecu"], "authorized-scan-target")
        self.assertFalse(annotated_services[0]["eligible_for_ecu_findings"])
        self.assertFalse(annotated_services[1]["eligible_for_ecu_findings"])
        self.assertTrue(annotated_services[2]["eligible_for_ecu_findings"])

        findings = build_findings(config, [], annotated_services)
        rendered = " ".join(row["title"] for row in findings)
        self.assertNotIn("192.0.2.4", rendered)
        self.assertNotIn("192.0.2.1", rendered)
        self.assertIn("192.0.2.20", rendered)


if __name__ == "__main__":
    unittest.main()
