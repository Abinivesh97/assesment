from __future__ import annotations

import unittest

from netscope.vlan import build_vlan_views, tag_preservation_summary


def _analysis(total: int, *, untagged: int, tagged: dict[int, int]) -> dict:
    partitions = {
        "untagged": {"packets": untagged, "bytes": untagged * 64},
        **{
            str(vlan_id): {"packets": packets, "bytes": packets * 64}
            for vlan_id, packets in tagged.items()
        },
    }
    return {
        "packets": total,
        "vlan_partitions": partitions,
        "vlan_stacks": (
            [{"stack": "/".join(map(str, tagged)), "count": max(tagged.values())}]
            if tagged
            else []
        ),
    }


class VlanAttributionTests(unittest.TestCase):
    def test_single_configured_vlan_uses_full_untagged_source(self) -> None:
        source = _analysis(1000, untagged=1000, tagged={})
        views, evidence, summary = build_vlan_views(source, [68], {})
        self.assertEqual(summary["assessment"], "not-observed")
        self.assertEqual(len(views), 1)
        self.assertIs(views[0]["analysis"], source)
        self.assertEqual(views[0]["attribution"]["basis"], "configured-source")
        self.assertFalse(views[0]["attribution"]["tag_observed"])
        self.assertEqual(evidence[0]["confidence"], "medium")

    def test_sparse_matching_tag_keeps_full_logical_source(self) -> None:
        source = _analysis(1000, untagged=999, tagged={68: 1})
        tag_analysis = _analysis(1, untagged=0, tagged={68: 1})
        views, _, summary = build_vlan_views(
            source,
            [68],
            {68: {"analysis": tag_analysis, "export_path": "tag.pcapng"}},
        )
        self.assertEqual(summary["assessment"], "sparse")
        self.assertIs(views[0]["analysis"], source)
        self.assertEqual(views[0]["attribution"]["basis"], "configured-and-observed")
        self.assertEqual(views[0]["attribution"]["tagged_packets"], 1)

    def test_multiple_configured_vlans_without_tags_are_not_guessed(self) -> None:
        source = _analysis(20, untagged=20, tagged={})
        views, evidence, _ = build_vlan_views(source, [68, 69], {})
        self.assertEqual(views, [])
        self.assertEqual({row["basis"] for row in evidence}, {"unattributable"})
        self.assertEqual({row["confidence"] for row in evidence}, {"none"})

    def test_qinq_creates_membership_views_for_both_retained_tags(self) -> None:
        source = _analysis(5, untagged=0, tagged={68: 5, 144: 5})
        observed = {
            68: {"analysis": {"packets": 5}},
            144: {"analysis": {"packets": 5}},
        }
        views, evidence, _ = build_vlan_views(source, [], observed)
        self.assertEqual({row["vlan_id"] for row in views}, {68, 144})
        self.assertEqual({row["basis"] for row in evidence}, {"observed-8021q"})

    def test_conflicting_retained_tag_prevents_logical_vlan_guess(self) -> None:
        source = _analysis(100, untagged=99, tagged={69: 1})
        views, evidence, _ = build_vlan_views(
            source,
            [68],
            {69: {"analysis": {"packets": 1}}},
        )
        self.assertEqual({row["vlan_id"] for row in views}, {69})
        configured = next(row for row in evidence if row["vlan_id"] == 68)
        self.assertEqual(configured["basis"], "unattributable")

    def test_tag_summary_counts_frames_not_vlan_memberships(self) -> None:
        source = _analysis(5, untagged=0, tagged={68: 5, 144: 5})
        summary = tag_preservation_summary(source)
        self.assertEqual(summary["tagged_frames"], 5)
        self.assertEqual(summary["tagged_fraction"], 1.0)


if __name__ == "__main__":
    unittest.main()
