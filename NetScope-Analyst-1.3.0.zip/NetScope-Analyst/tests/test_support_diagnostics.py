from __future__ import annotations

import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from typing import Any

from netscope.diagnostics import build_support_diagnostics
from netscope.reporting import generate_reports
from netscope.validation import validate_session_config
from tests.test_core import sample_config, sample_interface


class SupportDiagnosticsTests(unittest.TestCase):
    def test_canaries_cover_every_forbidden_data_category(self) -> None:
        canaries = {
            "vin": "ZZZZZZZ0000000001",
            "vehicle_alias": "VIN-VEHICLE-ALIAS-CANARY",
            "ipv4": "203.0.113.211",
            "ipv6": "2001:db8:dead:beef::211",
            "mac": "02:DE:AD:BE:EF:D1",
            "hostname": "ULTRA-SECRET-ECU.invalid",
            "service_id": "SERVICE-ID-SECRET-CANARY",
            "banner": "SECRET-BANNER-CANARY",
            "script": "SECRET-NSE-SCRIPT-CANARY",
            "target": "203.0.113.208/29",
            "exclusion": "203.0.113.209",
            "route": "SECRET-ROUTE-CANARY",
            "operator": "SECRET-OPERATOR-CANARY",
            "authorization": "SECRET-AUTHORIZATION-CANARY",
            "topology_notes": "SECRET-TOPOLOGY-NOTES-CANARY",
            "windows_path": r"C:\CANARY-SECRET\ecu.pcapng",
            "posix_path": "/canary/secret/ecu.pcapng",
            "command": "CANARY-NMAP-COMMAND",
            "filename": "SECRET-EVIDENCE-FILENAME.pcapng",
            "packet_sample": "CANARY-PACKET-PAYLOAD",
            "timestamp": "2042-12-31T23:59:59+00:00",
            "hash": "d34db33fd34db33fd34db33fd34db33fd34db33fd34db33fd34db33fd34db33f",
            "session_uuid": "11111111-2222-4333-8444-555555555555",
            "warning_message": "CANARY-RAW-WARNING",
            "error_message": "CANARY-RAW-ERROR",
        }
        vlan_id = 4093
        port = 65432
        source_id = canaries["session_uuid"]
        state = {
            "id": canaries["session_uuid"],
            "name": canaries["filename"],
            "status": "completed",
            "created_at": canaries["timestamp"],
            "started_at": canaries["timestamp"],
            "ended_at": canaries["timestamp"],
            "system": {
                "hostname": canaries["hostname"],
                "routes": [{"route": canaries["route"], "address": canaries["ipv4"]}],
                "tools": {
                    "tshark": {
                        "available": True,
                        "path": canaries["windows_path"],
                        "version": f"TShark 4.2.1 at {canaries['windows_path']} via {canaries['ipv4']}",
                    },
                    "nmap": {
                        "available": True,
                        "path": canaries["posix_path"],
                        "version": f"{canaries['ipv4']} Nmap 7.95",
                    },
                },
            },
            "config": {
                "operator": canaries["operator"],
                "authorization_note": canaries["authorization"],
                "topology_notes": canaries["topology_notes"],
                "capture": {"bpf_filter": canaries["packet_sample"]},
                "scan": {
                    "targets": [canaries["target"]],
                    "exclusions": [canaries["exclusion"]],
                    "routes": [canaries["route"]],
                },
                "sources": [
                    {
                        "source_id": source_id,
                        "alias": canaries["hostname"],
                        "targets": [canaries["target"]],
                        "exclusions": [canaries["exclusion"]],
                        "vlan_ids": [vlan_id],
                        "expected_ports": [port],
                        "interface": {
                            "name": canaries["hostname"],
                            "mac": canaries["mac"],
                            "addresses": [
                                {"address": canaries["ipv4"]},
                                {"address": canaries["ipv6"]},
                            ],
                        },
                    }
                ],
            },
            "captures": [
                {
                    "source_id": source_id,
                    "status": "completed",
                    "path": canaries["windows_path"],
                    "filename": canaries["filename"],
                    "command_display": canaries["command"],
                    "started_at": canaries["timestamp"],
                    "hash": canaries["hash"],
                    "error": canaries["error_message"],
                }
            ],
            "scans": [
                {
                    "source_id": source_id,
                    "status": "failed",
                    "targets": [canaries["target"]],
                    "exclusions": [canaries["exclusion"]],
                    "route": canaries["route"],
                    "xml_path": canaries["posix_path"],
                    "command_display": canaries["command"],
                    "error": canaries["error_message"],
                }
            ],
            "warnings": [canaries["warning_message"]],
            "errors": [canaries["error_message"]],
            "artifacts": {canaries["filename"]: canaries["windows_path"]},
        }
        analyses = [
            {
                "source_id": source_id,
                "error": canaries["error_message"],
                "analysis": {
                    "packets": 6,
                    "reported_capture_drops": 1,
                    "protocols": [
                        {"protocol": "DOIP", "count": 4},
                        {"protocol": "TCP", "count": 1},
                        {"protocol": canaries["hostname"], "count": 1},
                    ],
                    "vlan_stacks": [
                        {"stack": f"{vlan_id} pcp=7 dei=1", "count": 3},
                        {"stack": f"{vlan_id}/4092", "count": 1},
                    ],
                    "vlan_partitions": {
                        str(vlan_id): {"packets": 4},
                        "untagged": {"packets": 2},
                    },
                    "packet_sample": [
                        {
                            "source": canaries["ipv4"],
                            "destination": canaries["ipv6"],
                            "destination_port": port,
                            "vlan_stack": [vlan_id],
                            "payload": canaries["packet_sample"],
                            "info": {"doip_vin": canaries["vin"]},
                        }
                    ],
                    "automotive": {
                        "doip_vins": [{"value": canaries["vin"], "count": 1}],
                        "vehicle_alias": canaries["vehicle_alias"],
                    },
                    "hash": canaries["hash"],
                },
                "tag_preservation": {
                    "total_packets": 6,
                    "tagged_frames": 4,
                    "assessment": "partial",
                    "note": canaries["topology_notes"],
                },
                "vlan_attribution": [
                    {
                        "vlan_id": vlan_id,
                        "basis": "configured-and-observed",
                        "confidence": "medium",
                        "note": canaries["authorization"],
                    }
                ],
            }
        ]
        scan_records = [
            {
                "id": canaries["service_id"],
                "path": canaries["windows_path"],
                "parsed": {"banner": canaries["banner"], "script": canaries["script"]},
            }
        ]
        assets = [
            {
                "id": canaries["service_id"],
                "primary_address": canaries["ipv4"],
                "mac": canaries["mac"],
                "hostnames": [canaries["hostname"]],
            }
        ]
        services = [
            {
                "id": canaries["service_id"],
                "state": "open",
                "port": port,
                "banner": canaries["banner"],
                "scripts": [{"id": canaries["script"], "output": canaries["packet_sample"]}],
            }
        ]
        findings = [
            {
                "category": "exposure",
                "severity": "high",
                "service_ids": [canaries["service_id"]],
                "vehicle_context": [canaries["vehicle_alias"], canaries["vin"]],
                "evidence": [{"port": port, "vlan": vlan_id, "banner": canaries["banner"]}],
            },
            {
                "category": canaries["route"],
                "severity": canaries["warning_message"],
                "description": canaries["authorization"],
            },
        ]

        diagnostic = build_support_diagnostics(state, analyses, scan_records, assets, services, findings)
        rendered_strings = list(self._strings(diagnostic))
        rendered_integers = set(self._integers(diagnostic))
        for category, canary in canaries.items():
            with self.subTest(forbidden_category=category):
                self.assertFalse(any(canary in value for value in rendered_strings))
        self.assertNotIn(vlan_id, rendered_integers)
        self.assertNotIn(port, rendered_integers)

        self.assertEqual(
            set(diagnostic),
            {
                "schema_version",
                "redacted",
                "sharing_notice",
                "session_status",
                "tools",
                "totals",
                "message_counts",
                "finding_counts",
                "sources",
            },
        )
        self.assertTrue(diagnostic["redacted"])
        self.assertIn("Review before sharing", diagnostic["sharing_notice"])
        self.assertIn("evidence bundles may contain sensitive data", diagnostic["sharing_notice"])
        self.assertEqual(diagnostic["sources"][0]["alias"], "SOURCE_1")
        self.assertEqual(
            set(diagnostic["sources"][0]),
            {
                "alias",
                "analysis_record_count",
                "capture_status_counts",
                "scan_status_counts",
                "protocol_counts",
                "tag_preservation_aggregates",
            },
        )
        protocol_counts = {
            row["protocol"]: row["count"] for row in diagnostic["sources"][0]["protocol_counts"]
        }
        self.assertEqual(protocol_counts, {"DoIP": 4, "OTHER": 1, "TCP": 1})
        tags = diagnostic["sources"][0]["tag_preservation_aggregates"]
        self.assertEqual(
            set(tags),
            {
                "tag_observation_status",
                "packets_analyzed",
                "tagged_packet_observations",
                "untagged_packet_observations",
                "tag_stack_variant_count",
                "observed_tag_partition_count",
                "maximum_observed_tag_depth",
                "reported_capture_drop_count",
            },
        )
        self.assertEqual(tags["tag_observation_status"], "tags-observed")
        self.assertEqual(tags["tagged_packet_observations"], 4)
        self.assertEqual(tags["untagged_packet_observations"], 2)
        self.assertEqual(tags["maximum_observed_tag_depth"], 2)
        tool_versions = {row["name"]: row["version"] for row in diagnostic["tools"]}
        self.assertEqual(tool_versions["tshark"], "4.2.1")
        self.assertEqual(tool_versions["nmap"], "7.95")
        self.assertEqual(diagnostic["message_counts"]["warning_count"], 1)
        self.assertEqual(diagnostic["message_counts"]["error_count"], 1)
        self.assertEqual(
            {row["category"]: row["count"] for row in diagnostic["finding_counts"]["by_category"]},
            {"exposure": 1, "other": 1},
        )
        self.assertEqual(
            {row["severity"]: row["count"] for row in diagnostic["finding_counts"]["by_severity"]},
            {"high": 1, "other": 1},
        )

    def test_generate_reports_registers_standalone_diagnostic(self) -> None:
        config = validate_session_config(sample_config(), [sample_interface()])
        state = {
            "id": "00000000-0000-4000-8000-000000000777",
            "name": "Synthetic diagnostic integration",
            "status": "completed",
            "created_at": "2026-01-01T00:00:00+00:00",
            "started_at": "2026-01-01T00:00:00+00:00",
            "ended_at": "2026-01-01T00:01:00+00:00",
            "config": config,
            "system": {"tools": {"tshark": {"available": True, "path": "secret", "version": "4.2.1"}}},
            "captures": [],
            "scans": [],
            "warnings": [],
            "errors": [],
        }
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            _, artifacts = generate_reports(root, state, [], [], [], [], [])
            path = Path(artifacts["support_diagnostics_json"])
            diagnostic = json.loads(path.read_text(encoding="utf-8"))
            manifest = Path(artifacts["sha256_manifest"]).read_text(encoding="utf-8")
            with zipfile.ZipFile(artifacts["evidence_bundle"]) as bundle:
                members = set(bundle.namelist())
        self.assertEqual(path.name, "support-diagnostics.json")
        self.assertTrue(diagnostic["redacted"])
        self.assertIn("reports/support-diagnostics.json", manifest)
        self.assertIn("reports/support-diagnostics.json", members)

        app_js = (Path(__file__).resolve().parents[1] / "static" / "app.js").read_text(encoding="utf-8")
        self.assertLess(app_js.index('lower.includes("support_diagnostics")'), app_js.index('lower.includes("json")'))
        self.assertIn("review before sharing", app_js.lower())

    @classmethod
    def _strings(cls, value: Any):
        if isinstance(value, str):
            yield value
        elif isinstance(value, dict):
            for key, item in value.items():
                yield str(key)
                yield from cls._strings(item)
        elif isinstance(value, list):
            for item in value:
                yield from cls._strings(item)

    @classmethod
    def _integers(cls, value: Any):
        if isinstance(value, bool):
            return
        if isinstance(value, int):
            yield value
        elif isinstance(value, dict):
            for item in value.values():
                yield from cls._integers(item)
        elif isinstance(value, list):
            for item in value:
                yield from cls._integers(item)


if __name__ == "__main__":
    unittest.main()
