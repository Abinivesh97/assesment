"""NetScope Analyst tests."""
