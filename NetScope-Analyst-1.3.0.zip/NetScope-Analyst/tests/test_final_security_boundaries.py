from __future__ import annotations

import hashlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from netscope.analysis import _consume_tshark_output
from netscope.privacy import protect_vin_value
from netscope.reporting import _vlan_attribution_rows
from netscope.session import SessionManager
from netscope.topology import build_topology, link_findings_to_topology
from netscope.vlan import build_vlan_views


SYNTHETIC_VIN = "ZZZZZZZ0000000001"
SESSION_ID = "00000000-0000-0000-0000-000000000777"


class _CompletedTshark:
    def __init__(self, output: str):
        self.stdout = io.StringIO(output)

    def wait(self, timeout: float | None = None) -> int:
        return 0


def _config(*, include_vin: bool = False) -> dict:
    return {
        "name": "Synthetic security boundary",
        "include_vin_in_reports": include_vin,
        "sources": [
            {
                "source_id": "source-1",
                "alias": "Synthetic bench",
                "vlan_ids": [68],
                "interface": {
                    "name": "Synthetic VLAN interface",
                    "addresses": [{"address": "192.0.2.10", "family": "IPv4"}],
                },
            }
        ],
    }


class FinalSecurityBoundaryTests(unittest.TestCase):
    def test_invalid_explicit_vin_stays_aliased_even_with_plaintext_opt_in(self) -> None:
        opaque_value = "\ufffd" * 17
        protected = protect_vin_value(
            opaque_value,
            SESSION_ID,
            include_plaintext=True,
        )
        self.assertRegex(protected, r"^VIN-[A-F0-9]{12}$")
        self.assertNotIn(opaque_value, protected)
        self.assertEqual(
            protect_vin_value(SYNTHETIC_VIN, SESSION_ID, include_plaintext=True),
            SYNTHETIC_VIN,
        )

        selected = [
            "frame.number",
            "frame.time_epoch",
            "frame.len",
            "_ws.col.Protocol",
            "ip.src",
            "ip.dst",
            "doip.vin",
        ]
        output = "\t".join(
            ["1", "1.0", "64", "DOIP", "192.0.2.20", "192.0.2.10", opaque_value]
        ) + "\n"
        with tempfile.TemporaryDirectory() as temporary:
            capture_path = Path(temporary) / "synthetic.pcapng"
            capture_path.write_bytes(b"synthetic capture placeholder")
            result = _consume_tshark_output(
                _CompletedTshark(output),
                io.StringIO(""),
                capture_path,
                selected,
                [],
                10,
                True,
                SESSION_ID,
                None,
            )
        rendered = json.dumps(result, ensure_ascii=False)
        self.assertNotIn(opaque_value, rendered)
        self.assertIn("VIN-", rendered)
        self.assertTrue(
            any(
                "did not contain a valid 17-character ISO-style VIN" in warning
                for warning in result["analysis_warnings"]
            )
        )

    def test_aggregate_vin_remains_source_level_and_never_enriches_exact_asset_finding(self) -> None:
        config = _config(include_vin=True)
        analyses = [
            {
                "source_id": "source-1",
                "analysis": {
                    "conversations": [],
                    "packet_sample": [],
                    "lldp_neighbors": [],
                    "automotive": {"doip_vins": [{"value": SYNTHETIC_VIN, "count": 1}]},
                },
                "vlan_views": [],
                "vlan_attribution": [],
            }
        ]
        assets = [
            {
                "id": "asset-only",
                "primary_address": "192.0.2.20",
                "addresses": [{"addr": "192.0.2.20", "addrtype": "ipv4"}],
                "sources": ["source-1"],
            }
        ]
        services = [
            {
                "id": "service-doip",
                "asset_id": "asset-only",
                "source_id": "source-1",
                "address": "192.0.2.20",
                "protocol": "tcp",
                "port": 13400,
                "service": "doip",
            }
        ]

        topology = build_topology(SESSION_ID, config, analyses, assets, services)
        asset_node = next(node for node in topology["nodes"] if "asset-only" in node["asset_ids"])
        unresolved = next(node for node in topology["nodes"] if node.get("vehicle_identity_scope") == "source-only")
        self.assertNotIn("observed_vins", asset_node)
        self.assertEqual(unresolved["observed_vins"], [SYNTHETIC_VIN])
        self.assertEqual(unresolved["asset_ids"], [])

        linked = link_findings_to_topology(
            [{"asset_ids": ["asset-only"], "source_ids": ["source-1"]}],
            topology,
        )[0]
        self.assertEqual(linked["vehicle_context"], [])

    def test_conflicting_observed_membership_cannot_project_full_source_or_scans(self) -> None:
        analysis = {
            "packets": 3,
            "vlan_partitions": {
                "untagged": {"packets": 1, "bytes": 64},
                "68": {"packets": 1, "bytes": 64},
                "69": {"packets": 1, "bytes": 64},
            },
            "vlan_stacks": [{"stack": "68", "count": 1}, {"stack": "69", "count": 1}],
            "conversations": [
                {
                    "protocol": "TCP",
                    "endpoint_a": "192.0.2.20",
                    "endpoint_b": "192.0.2.30",
                    "packets": 1,
                    "bytes": 64,
                }
            ],
            "packet_sample": [],
            "lldp_neighbors": [],
            "automotive": {},
        }
        observed = {
            68: {"analysis": {"packets": 1, "conversations": []}},
            69: {"analysis": {"packets": 1, "conversations": []}},
        }
        views, attribution, tag_summary = build_vlan_views(analysis, [68], observed)
        vlan_68 = next(row for row in attribution if row["vlan_id"] == 68)
        self.assertEqual(vlan_68["basis"], "configured-and-observed")
        self.assertEqual(vlan_68["attribution_scope"], "retained-membership")

        analysis_row = {
            "source_id": "source-1",
            "source_alias": "Synthetic bench",
            "analysis": analysis,
            "vlan_views": views,
            "vlan_attribution": attribution,
            "tag_preservation": tag_summary,
        }
        topology = build_topology(SESSION_ID, _config(), [analysis_row], [], [])
        aggregate_edge = next(edge for edge in topology["edges"] if edge["packets"] == 1)
        self.assertEqual(aggregate_edge["vlan_ids"], [])
        report_rows = _vlan_attribution_rows([analysis_row], _config()["sources"])
        report_vlan_68 = next(row for row in report_rows if row["vlan_id"] == 68)
        self.assertEqual(report_vlan_68["active_scan_attribution"], "no — traffic evidence only")

    def test_nonconflicting_configured_source_can_project_full_source_and_scans(self) -> None:
        analysis = {
            "packets": 2,
            "vlan_partitions": {"untagged": {"packets": 2, "bytes": 128}},
            "vlan_stacks": [],
            "conversations": [
                {
                    "protocol": "TCP",
                    "endpoint_a": "192.0.2.20",
                    "endpoint_b": "192.0.2.30",
                    "packets": 2,
                    "bytes": 128,
                }
            ],
            "packet_sample": [],
            "lldp_neighbors": [],
            "automotive": {},
        }
        views, attribution, tag_summary = build_vlan_views(analysis, [68], {})
        self.assertEqual(attribution[0]["attribution_scope"], "full-source")
        row = {
            "source_id": "source-1",
            "source_alias": "Synthetic bench",
            "analysis": analysis,
            "vlan_views": views,
            "vlan_attribution": attribution,
            "tag_preservation": tag_summary,
        }
        topology = build_topology(SESSION_ID, _config(), [row], [], [])
        edge = next(edge for edge in topology["edges"] if edge["packets"] == 2)
        self.assertEqual(edge["vlan_ids"], [68])
        report_row = _vlan_attribution_rows([row], _config()["sources"])[0]
        self.assertEqual(report_row["active_scan_attribution"], "yes")

    def test_vin_opt_out_sanitizes_all_derived_persistence_but_not_raw_capture(self) -> None:
        system = {"tools": {}}
        with tempfile.TemporaryDirectory() as temporary:
            with mock.patch("netscope.session.system_snapshot", return_value=system):
                manager = SessionManager(Path(temporary))
            session_dir = manager._session_dir(SESSION_ID)
            (session_dir / "analysis").mkdir(parents=True)
            (session_dir / "captures").mkdir(parents=True)
            raw_capture = session_dir / "captures" / "raw.pcapng"
            raw_capture.write_bytes(("raw:" + SYNTHETIC_VIN).encode("ascii"))
            state = {
                "id": SESSION_ID,
                "name": f"Case {SYNTHETIC_VIN}",
                "status": "analyzing",
                "config": {
                    "include_vin_in_reports": False,
                    "name": f"Case {SYNTHETIC_VIN}",
                    "topology_notes": f"Identity {SYNTHETIC_VIN}",
                    "sources": [],
                },
                "system": {},
                "captures": [{"path": str(raw_capture)}],
                "scans": [],
                "analyses": [{"note": f"Derived {SYNTHETIC_VIN}"}],
                "warnings": [f"Warning {SYNTHETIC_VIN}"],
                "errors": [],
                "artifacts": {},
            }
            manager._states[SESSION_ID] = state
            manager._audit_hashes[SESSION_ID] = ""
            manager._write_state_dict(state)
            manager._write_metadata(SESSION_ID, state)
            manager._audit(SESSION_ID, "synthetic_event", {"message": f"Audit {SYNTHETIC_VIN}"})
            analysis_path = session_dir / "analysis" / "source-1.json"
            persisted_analysis = manager._write_analysis_result(
                SESSION_ID,
                analysis_path,
                {
                    "capture_file": f"C:/captures/{SYNTHETIC_VIN}.pcapng",
                    "dns_names": [{"name": SYNTHETIC_VIN, "count": 1}],
                    "analysis_warnings": [f"Warning {SYNTHETIC_VIN}"],
                },
            )

            for path in (
                session_dir / "state.json",
                session_dir / "session-metadata.json",
                session_dir / "audit.jsonl",
                analysis_path,
            ):
                text = path.read_text(encoding="utf-8")
                self.assertNotIn(SYNTHETIC_VIN, text, path.name)
                self.assertIn("VIN-", text, path.name)
            self.assertNotIn(SYNTHETIC_VIN, json.dumps(persisted_analysis))
            self.assertIn(SYNTHETIC_VIN, state["name"])
            self.assertEqual(raw_capture.read_bytes(), ("raw:" + SYNTHETIC_VIN).encode("ascii"))

            audit_entry = json.loads((session_dir / "audit.jsonl").read_text(encoding="utf-8"))
            stored_hash = audit_entry.pop("entry_hash")
            canonical = json.dumps(
                audit_entry,
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
                default=str,
            )
            self.assertEqual(stored_hash, hashlib.sha256(canonical.encode("utf-8")).hexdigest())


if __name__ == "__main__":
    unittest.main()
