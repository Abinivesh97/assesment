from __future__ import annotations

import unittest

from netscope.known_targets import MAX_IFCONFIG_TEXT, preview_known_targets
from netscope.validation import ValidationError


class KnownTargetPreviewTests(unittest.TestCase):
    def test_unique_vlan_mapping_extracts_exact_hosts_and_discards_sensitive_fields(self) -> None:
        text = """lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 16384
    inet 127.0.0.1 netmask 0xff000000
vlan42: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> mtu 1496
    ether 02:00:00:00:00:42
    inet6 fe80::42%vlan42 prefixlen 64 scopeid 0x7
    inet 192.168.42.25 netmask 0xffffff00 broadcast 192.168.42.255
    vlan: 42 vlanproto: 802.1q parent interface: eth0
"""
        result = preview_known_targets(
            {
                "text": text,
                "sources": [{"interface_id": "source-interface", "alias": "Synthetic lane", "vlan_ids": [42]}],
            }
        )

        self.assertFalse(result["raw_text_retained"])
        self.assertEqual(result["summary"]["candidate_count"], 1)
        self.assertEqual(result["summary"]["auto_mapped_count"], 1)
        candidate = result["candidates"][0]
        self.assertEqual(candidate["address"], "192.168.42.25")
        self.assertEqual(candidate["vlan_id"], 42)
        self.assertEqual(candidate["source_interface_id"], "source-interface")
        self.assertEqual(candidate["mapping_status"], "mapped-by-vlan")
        self.assertEqual(candidate["prefix_length"], 24)
        self.assertEqual(candidate["network"], "192.168.42.0")
        self.assertEqual(candidate["broadcast"], "192.168.42.255")
        self.assertNotIn("ether", str(result).lower())
        self.assertEqual(result["summary"]["skipped_counts"]["loopback"], 1)
        self.assertEqual(result["summary"]["skipped_counts"]["ecu-scoped-ipv6-link-local"], 1)

    def test_ambiguous_vlan_mapping_remains_unapplied(self) -> None:
        result = preview_known_targets(
            {
                "text": "vlan7: flags=8843<UP,RUNNING> mtu 1496\n    inet 192.168.7.20 netmask 0xffffff00\n",
                "sources": [
                    {"interface_id": "left", "alias": "Left", "vlan_ids": [7]},
                    {"interface_id": "right", "alias": "Right", "vlan_ids": [7]},
                ],
            }
        )
        candidate = result["candidates"][0]
        self.assertIsNone(candidate["source_interface_id"])
        self.assertEqual(candidate["mapping_status"], "ambiguous-vlan")
        self.assertEqual(result["summary"]["manual_mapping_count"], 1)

    def test_duplicates_are_removed_and_non_local_hosts_are_flagged(self) -> None:
        result = preview_known_targets(
            {
                "text": "vlan9: flags=8843<UP,RUNNING> mtu 1496\n    inet 198.51.100.25 netmask 0xffffff00\n    inet 198.51.100.25 netmask 0xffffff00\n",
                "sources": [{"interface_id": "lane", "alias": "Lane", "vlan_ids": [9]}],
            }
        )
        self.assertEqual(len(result["candidates"]), 1)
        self.assertTrue(result["candidates"][0]["requires_non_local_opt_in"])
        self.assertEqual(result["summary"]["skipped_counts"]["duplicate"], 1)
        self.assertIn("Allow non-local scope", result["warnings"][0])

    def test_base_interface_without_vlan_requires_manual_mapping(self) -> None:
        result = preview_known_targets(
            {
                "text": "eth0: flags=8843<UP,RUNNING> mtu 1500\n    inet 192.168.5.20 netmask 0xffffff00\n",
                "sources": [{"interface_id": "lane", "alias": "Lane", "vlan_ids": [5]}],
            }
        )
        self.assertEqual(result["candidates"][0]["mapping_status"], "unmapped")
        self.assertIsNone(result["candidates"][0]["source_interface_id"])

    def test_invalid_or_oversized_input_is_rejected(self) -> None:
        for payload in (
            {"text": "", "sources": [{"interface_id": "lane", "vlan_ids": [1]}]},
            {"text": "x" * (MAX_IFCONFIG_TEXT + 1), "sources": [{"interface_id": "lane", "vlan_ids": [1]}]},
            {"text": "eth0: flags=<UP>\n\x00", "sources": [{"interface_id": "lane", "vlan_ids": [1]}]},
        ):
            with self.subTest(length=len(payload["text"])), self.assertRaises(ValidationError):
                preview_known_targets(payload)

    def test_conflicting_vlan_masks_warn_and_never_create_subnet_targets(self) -> None:
        result = preview_known_targets(
            {
                "text": """vlan18: flags=8843<UP,RUNNING> mtu 1496
    inet 192.168.18.20 netmask 0xffffff80 broadcast 192.168.18.127
    vlan: 18 vlanproto: 802.1q parent interface: eth0
vlan18: flags=8843<UP,RUNNING> mtu 1496
    inet 192.168.18.201 netmask 255.255.255.248 broadcast 192.168.18.207
    vlan: 18 vlanproto: 802.1q parent interface: eth0
""",
                "sources": [{"interface_id": "lane", "alias": "Lane", "vlan_ids": [18]}],
            }
        )
        self.assertEqual(result["summary"]["prefix_conflict_count"], 1)
        self.assertEqual({row["prefix_length"] for row in result["candidates"]}, {25, 29})
        self.assertTrue(all(row["prefix_conflict"] for row in result["candidates"]))
        self.assertTrue(all("/" not in row["address"] for row in result["candidates"]))
        self.assertTrue(
            all(
                row["scope_safety_note"] == "prefix-conflict; exact-host only; subnet expansion prohibited"
                for row in result["candidates"]
            )
        )
        self.assertTrue(any("subnet expansion prohibited" in warning for warning in result["warnings"]))

    def test_duplicate_host_with_different_masks_still_raises_prefix_conflict(self) -> None:
        result = preview_known_targets(
            {
                "text": """vlan12: flags=8843<UP,RUNNING> mtu 1496
    inet 192.168.12.20 netmask 0xffffff00 broadcast 192.168.12.255
    vlan: 12 vlanproto: 802.1q parent interface: eth0
vlan12: flags=8843<UP,RUNNING> mtu 1496
    inet 192.168.12.20 netmask 0xfffffff0 broadcast 192.168.12.31
    vlan: 12 vlanproto: 802.1q parent interface: eth0
""",
                "sources": [{"interface_id": "lane", "alias": "Lane", "vlan_ids": [12]}],
            }
        )
        self.assertEqual(len(result["candidates"]), 1)
        self.assertEqual(result["summary"]["prefix_conflict_count"], 1)
        self.assertTrue(result["candidates"][0]["prefix_conflict"])

    def test_noncontiguous_mask_is_not_used_to_derive_network_or_broadcast(self) -> None:
        result = preview_known_targets(
            {
                "text": "vlan6: flags=8843<UP,RUNNING> mtu 1496\n    inet 192.168.6.25 netmask 255.0.255.0\n",
                "sources": [{"interface_id": "lane", "alias": "Lane", "vlan_ids": [6]}],
            }
        )
        candidate = result["candidates"][0]
        self.assertIsNone(candidate["prefix_length"])
        self.assertIsNone(candidate["network"])
        self.assertIn("non-contiguous", candidate["mask_warning"])
        self.assertEqual(result["summary"]["skipped_counts"]["invalid-or-noncontiguous-mask"], 1)


if __name__ == "__main__":
    unittest.main()
