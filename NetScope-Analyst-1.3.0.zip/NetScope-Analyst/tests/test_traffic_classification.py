from __future__ import annotations

import io
import tempfile
import unittest
from pathlib import Path

from netscope.analysis import _consume_tshark_output
from netscope.topology import build_topology


class _CompletedTshark:
    def __init__(self, output: str):
        self.stdout = io.StringIO(output)

    def wait(self, timeout: float | None = None) -> int:
        return 0


SELECTED = [
    "frame.number",
    "frame.time_epoch",
    "frame.len",
    "frame.cap_len",
    "frame.protocols",
    "eth.src",
    "eth.dst",
    "ip.src",
    "ip.dst",
    "tcp.srcport",
    "tcp.dstport",
    "tcp.len",
    "udp.srcport",
    "udp.dstport",
    "udp.length",
    "data.len",
    "tcp.flags.syn",
    "tcp.flags.ack",
    "vlan.id",
]


def _row(**values: object) -> str:
    return "\t".join(str(values.get(name, "")) for name in SELECTED)


class TrafficClassificationTests(unittest.TestCase):
    def _analyze(self) -> dict:
        host_mac = "02:00:00:00:00:10"
        target_mac = "02:00:00:00:00:20"
        rows = [
            _row(
                **{
                    "frame.number": 1,
                    "frame.time_epoch": 90,
                    "frame.len": 50,
                    "frame.cap_len": 50,
                    "frame.protocols": "eth:ip:udp:data",
                    "eth.src": host_mac,
                    "eth.dst": "01:00:5e:40:ff:01",
                    "ip.src": "192.0.2.10",
                    "ip.dst": "239.255.42.42",
                    "udp.srcport": 42042,
                    "udp.dstport": 42042,
                    "udp.length": 16,
                }
            ),
            _row(
                **{
                    "frame.number": 2,
                    "frame.time_epoch": 91,
                    "frame.len": 62,
                    "frame.protocols": "eth:ip:udp:mdns",
                    "eth.src": host_mac,
                    "eth.dst": "01:00:5e:00:00:fb",
                    "ip.src": "192.0.2.10",
                    "ip.dst": "224.0.0.251",
                    "udp.srcport": 5353,
                    "udp.dstport": 5353,
                    "udp.length": 20,
                }
            ),
            _row(
                **{
                    "frame.number": 3,
                    "frame.time_epoch": 100,
                    "frame.len": 60,
                    "frame.protocols": "eth:ip:tcp",
                    "eth.src": host_mac,
                    "eth.dst": target_mac,
                    "ip.src": "192.0.2.10",
                    "ip.dst": "192.0.2.20",
                    "tcp.srcport": 50000,
                    "tcp.dstport": 44444,
                    "tcp.len": 0,
                    "tcp.flags.syn": 1,
                    "tcp.flags.ack": 0,
                }
            ),
            _row(
                **{
                    "frame.number": 4,
                    "frame.time_epoch": 100.1,
                    "frame.len": 60,
                    "frame.protocols": "eth:ip:tcp",
                    "eth.src": target_mac,
                    "eth.dst": host_mac,
                    "ip.src": "192.0.2.20",
                    "ip.dst": "192.0.2.10",
                    "tcp.srcport": 44444,
                    "tcp.dstport": 50000,
                    "tcp.len": 0,
                    "tcp.flags.syn": 1,
                    "tcp.flags.ack": 1,
                }
            ),
            _row(
                **{
                    "frame.number": 5,
                    "frame.time_epoch": 105,
                    "frame.len": 70,
                    "frame.protocols": "eth:ip:udp:someip",
                    "eth.src": target_mac,
                    "eth.dst": "01:00:5e:40:ff:fb",
                    "ip.src": "192.0.2.20",
                    "ip.dst": "239.192.255.251",
                    "udp.srcport": 30490,
                    "udp.dstport": 30490,
                    "udp.length": 28,
                }
            ),
            _row(
                **{
                    "frame.number": 6,
                    "frame.time_epoch": 110,
                    "frame.len": 60,
                    "frame.protocols": "eth:ip:tcp",
                    "eth.src": target_mac,
                    "eth.dst": host_mac,
                    "ip.src": "192.0.2.20",
                    "ip.dst": "192.0.2.10",
                    "tcp.srcport": 40000,
                    "tcp.dstport": 50001,
                    "tcp.len": 0,
                    "tcp.flags.syn": 0,
                    "tcp.flags.ack": 1,
                }
            ),
        ]
        context = {
            "local_addresses": ["192.0.2.10"],
            "local_macs": [host_mac],
            "authorized_targets": ["192.0.2.20/32"],
            "scan_windows": [
                {
                    "id": "scan-1",
                    "profile": "full_tcp",
                    "started_at": "1970-01-01T00:01:35+00:00",
                    "ended_at": "1970-01-01T00:01:45+00:00",
                    "targets": ["192.0.2.20/32"],
                    "effective_exclusions": ["192.0.2.10/32"],
                }
            ],
        }
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "synthetic.pcapng"
            path.write_bytes(b"synthetic capture placeholder")
            return _consume_tshark_output(
                _CompletedTshark("\n".join(rows) + "\n"),
                io.StringIO(""),
                path,
                SELECTED,
                [],
                20,
                False,
                "synthetic-session",
                None,
                source_context=context,
            )

    def test_separates_scan_host_stimulus_and_remote_payload(self) -> None:
        result = self._analyze()
        classes = {row["class"]: row for row in result["traffic_classes"]}
        self.assertEqual(classes["local-stimulus"]["packets"], 1)
        self.assertEqual(classes["local-background"]["packets"], 1)
        self.assertEqual(classes["scan-probe"]["packets"], 1)
        self.assertEqual(classes["scan-response"]["packets"], 1)
        self.assertEqual(classes["remote-payload"]["payload_bytes"], 20)
        self.assertEqual(classes["remote-control"]["packets"], 1)
        self.assertEqual(result["payload_summary"]["payload_packets"], 3)
        self.assertEqual(result["payload_summary"]["payload_bytes"], 40)
        self.assertEqual(result["traffic_classification"]["scan_window_count"], 1)

    def test_two_way_scan_activity_is_not_a_passive_service_claim(self) -> None:
        result = self._analyze()
        ports = {(row["transport"], row["port"]): row for row in result["port_observations"]}
        probe = ports[("tcp", 44444)]
        self.assertEqual(probe["packets"], 1)
        self.assertEqual(probe["payload_packets"], 0)
        self.assertEqual(probe["syn_without_ack_packets"], 1)
        self.assertEqual(probe["scan_probe_packets"], 1)
        self.assertIsNone(probe["service_guess"])
        self.assertEqual(probe["service_evidence"], "not-established-by-passive-destination-port-count")

    def test_conversations_preserve_legacy_display_but_expose_structured_endpoints(self) -> None:
        result = self._analyze()
        conversation = next(
            row
            for row in result["conversations"]
            if {row["endpoint_a_port"], row["endpoint_b_port"]} == {44444, 50000}
        )
        self.assertEqual(
            {conversation["endpoint_a_address"], conversation["endpoint_b_address"]},
            {"192.0.2.10", "192.0.2.20"},
        )
        self.assertTrue(conversation["endpoint_a"].endswith(str(conversation["endpoint_a_port"])))
        self.assertTrue(result["l2_l3_bindings"])

    def test_syn_outside_verified_window_is_only_an_inferred_probe(self) -> None:
        host_mac = "02:00:00:00:00:10"
        row = _row(**{
            "frame.number": 1, "frame.time_epoch": 50, "frame.len": 60,
            "frame.protocols": "eth:ip:tcp", "eth.src": host_mac,
            "eth.dst": "02:00:00:00:00:20", "ip.src": "192.0.2.10",
            "ip.dst": "192.0.2.20", "tcp.srcport": 50000,
            "tcp.dstport": 44444, "tcp.len": 0, "tcp.flags.syn": 1,
            "tcp.flags.ack": 0,
        })
        context = {
            "local_addresses": ["192.0.2.10"],
            "local_macs": [host_mac],
            "authorized_targets": ["192.0.2.20/32"],
            "scan_windows": [{
                "id": "later-scan", "profile": "full_tcp",
                "started_at": "1970-01-01T00:01:40+00:00",
                "ended_at": "1970-01-01T00:01:50+00:00",
                "targets": ["192.0.2.20/32"],
            }],
        }
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "synthetic.pcapng"
            path.write_bytes(b"synthetic")
            result = _consume_tshark_output(
                _CompletedTshark(row + "\n"), io.StringIO(""), path, SELECTED,
                [], 5, False, "synthetic-session", None, source_context=context,
            )
        classes = {item["class"]: item for item in result["traffic_classes"]}
        self.assertEqual(classes["inferred-probe"]["packets"], 1)
        self.assertNotIn("scan-probe", classes)
        port = result["port_observations"][0]
        self.assertEqual(port["inferred_probe_packets"], 1)
        self.assertEqual(port["scan_probe_packets"], 0)

    def test_host_and_scan_payload_never_become_passive_remote_data(self) -> None:
        host_mac = "02:00:00:00:00:10"
        target_mac = "02:00:00:00:00:20"
        rows = [
            _row(**{"frame.number": 1, "frame.time_epoch": 90, "frame.len": 50,
                "frame.protocols": "eth:ip:udp:data", "eth.src": host_mac,
                "eth.dst": "01:00:5e:40:ff:01", "ip.src": "192.0.2.10",
                "ip.dst": "239.192.255.1", "udp.srcport": 30500,
                "udp.dstport": 30500, "udp.length": 16}),
            _row(**{"frame.number": 2, "frame.time_epoch": 100, "frame.len": 52,
                "frame.protocols": "eth:ip:udp:data", "eth.src": host_mac,
                "eth.dst": target_mac, "ip.src": "192.0.2.10",
                "ip.dst": "192.0.2.20", "udp.srcport": 50000,
                "udp.dstport": 13400, "udp.length": 18}),
            _row(**{"frame.number": 3, "frame.time_epoch": 101, "frame.len": 54,
                "frame.protocols": "eth:ip:udp:data", "eth.src": target_mac,
                "eth.dst": host_mac, "ip.src": "192.0.2.20",
                "ip.dst": "192.0.2.10", "udp.srcport": 13400,
                "udp.dstport": 50000, "udp.length": 20}),
            _row(**{"frame.number": 4, "frame.time_epoch": 110, "frame.len": 62,
                "frame.protocols": "eth:ip:udp:someip", "eth.src": target_mac,
                "eth.dst": "01:00:5e:40:ff:fb", "ip.src": "192.0.2.20",
                "ip.dst": "239.192.255.251", "udp.srcport": 30490,
                "udp.dstport": 30490, "udp.length": 28}),
        ]
        context = {
            "local_addresses": ["192.0.2.10"], "local_macs": [host_mac],
            "authorized_targets": ["192.0.2.20/32"],
            "scan_windows": [{"id": "udp-scan", "profile": "automotive_services",
                "started_at": "1970-01-01T00:01:35+00:00",
                "ended_at": "1970-01-01T00:01:45+00:00",
                "targets": ["192.0.2.20/32"]}],
        }
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "synthetic.pcapng"
            path.write_bytes(b"synthetic")
            result = _consume_tshark_output(
                _CompletedTshark("\n".join(rows) + "\n"), io.StringIO(""),
                path, SELECTED, [], 5, False, "synthetic-session", None,
                source_context=context,
            )
        summary = result["payload_summary"]
        self.assertEqual(summary["observed_payload_bytes"], 50)
        self.assertEqual(summary["host_origin_payload_bytes"], 18)
        self.assertEqual(summary["scan_response_payload_bytes"], 12)
        self.assertEqual(summary["passive_remote_data_candidate_bytes"], 20)
        self.assertEqual(summary["unattributed_payload_bytes"], 0)
        self.assertEqual(summary["ecu_origin_claim"], "not-established-by-direction-or-payload-alone")


class TopologyNoiseAndIdentityTests(unittest.TestCase):
    def test_address_only_nodes_mac_correlation_and_default_suppression(self) -> None:
        session_id = "00000000-0000-0000-0000-000000000777"
        ecu_mac = "02:00:00:00:AA:20"
        sources = []
        analyses = []
        for index, (vlan_id, host, ecu) in enumerate(
            ((68, "192.0.2.10", "192.0.2.20"), (73, "198.51.100.10", "198.51.100.20")),
            start=1,
        ):
            source_id = f"source-{index}"
            sources.append(
                {
                    "source_id": source_id,
                    "alias": f"VLAN {vlan_id}",
                    "vlan_ids": [vlan_id],
                    "known_targets": [{"address": ecu, "vlan_id": vlan_id}],
                    "interface": {
                        "name": f"Synthetic VLAN {vlan_id}",
                        "mac": f"02:00:00:00:00:{index:02X}",
                        "addresses": [{"address": host, "family": "IPv4", "prefix_length": 24}],
                    },
                }
            )
            if index == 1:
                conversation = {
                    "protocol": "tcp",
                    "endpoint_a": f"{host}:50000",
                    "endpoint_b": f"{ecu}:44444",
                    "endpoint_a_address": host,
                    "endpoint_a_port": 50000,
                    "endpoint_b_address": ecu,
                    "endpoint_b_port": 44444,
                    "packets": 2,
                    "bytes": 120,
                    "payload_packets": 0,
                    "payload_bytes": 0,
                    "tcp_syn_without_ack_packets": 2,
                    "traffic_classes": [{"class": "scan-probe", "packets": 2}],
                    "destination_ports": [{"port": 44444, "packets": 2}],
                }
            else:
                conversation = {
                    "protocol": "SOMEIP",
                    "endpoint_a": f"{ecu}:30490",
                    "endpoint_b": "239.192.255.251:30490",
                    "endpoint_a_address": ecu,
                    "endpoint_a_port": 30490,
                    "endpoint_b_address": "239.192.255.251",
                    "endpoint_b_port": 30490,
                    "packets": 10,
                    "bytes": 1000,
                    "payload_packets": 10,
                    "payload_bytes": 500,
                    "traffic_classes": [{"class": "remote-payload", "packets": 10}],
                    "destination_ports": [{"port": 30490, "packets": 10}],
                }
            analyses.append(
                {
                    "source_id": source_id,
                    "analysis": {
                        "conversations": [conversation],
                        "packet_sample": [],
                        "l2_l3_bindings": [
                            {
                                "mac_address": ecu_mac,
                                "address": ecu,
                                "vlan_ids": [vlan_id],
                                "protocols": [{"protocol": "SOMEIP", "count": 1}],
                            }
                        ],
                    },
                    "vlan_attribution": [
                        {
                            "vlan_id": vlan_id,
                            "basis": "configured-source",
                            "confidence": "high",
                            "attribution_scope": "full-source",
                            "tag_observed": False,
                        }
                    ],
                    "vlan_views": [],
                }
            )
        topology = build_topology(
            session_id,
            {"automotive_mode": True, "include_vin_in_reports": False, "sources": sources},
            analyses,
            [],
            [],
        )
        ecu_nodes = [node for node in topology["nodes"] if ecu_mac in node["mac_addresses"]]
        self.assertEqual(len(ecu_nodes), 1)
        ecu_node = ecu_nodes[0]
        self.assertEqual(ecu_node["role"], "ecu")
        self.assertEqual(set(ecu_node["addresses"]), {"192.0.2.20", "198.51.100.20"})
        self.assertEqual(set(ecu_node["vlan_ids"]), {68, 73})
        self.assertEqual(ecu_node["identity_confidence"], "medium")
        self.assertFalse(any(":" in address and address.count(".") == 3 for node in topology["nodes"] for address in node["addresses"]))

        scan_edge = next(edge for edge in topology["edges"] if "scan-probe" in edge["traffic_classes"])
        payload_edge = next(edge for edge in topology["edges"] if "remote-payload" in edge["traffic_classes"])
        self.assertFalse(scan_edge["default_visible"])
        self.assertEqual(scan_edge["suppression_reason"], "scan-or-local-host-noise")
        self.assertTrue(payload_edge["default_visible"])
        self.assertIn(scan_edge["id"], {edge["id"] for edge in topology["edges"]})
        self.assertNotIn(scan_edge["id"], topology["default_view"]["edge_ids"])
        self.assertGreaterEqual(topology["default_view"]["suppressed_edge_count"], 1)
        self.assertEqual(payload_edge["passive_remote_data_candidate_bytes"], 500)
        self.assertEqual(scan_edge["passive_remote_data_candidate_bytes"], 0)

    def test_ecu_role_node_with_only_suppressed_scan_response_is_hidden(self) -> None:
        source_id = "source-1"
        ecu = "192.0.2.20"
        topology = build_topology(
            "00000000-0000-0000-0000-000000000779",
            {"sources": [{
                "source_id": source_id,
                "alias": "Synthetic",
                "vlan_ids": [68],
                "known_targets": [{"address": ecu, "vlan_id": 68}],
                "interface": {
                    "addresses": [{"address": "192.0.2.10"}],
                    "mac": "02:00:00:00:00:10",
                },
            }]},
            [{
                "source_id": source_id,
                "analysis": {
                    "conversations": [{
                        "protocol": "udp",
                        "endpoint_a_address": "192.0.2.10",
                        "endpoint_a_port": 50000,
                        "endpoint_b_address": ecu,
                        "endpoint_b_port": 13400,
                        "packets": 1,
                        "bytes": 60,
                        "payload_packets": 1,
                        "payload_bytes": 12,
                        "traffic_classes": [{
                            "class": "scan-response",
                            "packets": 1,
                            "payload_packets": 1,
                            "payload_bytes": 12,
                        }],
                        "destination_ports": [{"port": 50000, "packets": 1}],
                    }],
                    "packet_sample": [],
                    "l2_l3_bindings": [{
                        "mac_address": "02:00:00:00:00:20",
                        "address": ecu,
                        "protocols": [{"protocol": "SOMEIP", "count": 1}],
                    }],
                },
                "vlan_views": [],
                "vlan_attribution": [{
                    "vlan_id": 68,
                    "basis": "configured-source",
                    "confidence": "high",
                    "attribution_scope": "full-source",
                    "tag_observed": False,
                }],
            }],
            [],
            [],
        )
        ecu_node = next(node for node in topology["nodes"] if ecu in node["addresses"])
        self.assertEqual(ecu_node["role"], "ecu")
        self.assertFalse(ecu_node["default_visible"])
        self.assertNotIn(ecu_node["id"], topology["default_view"]["node_ids"])

    def test_conflicting_source_macs_do_not_force_identity_merge(self) -> None:
        analyses = [
            {
                "source_id": "source-1",
                "analysis": {
                    "l2_l3_bindings": [
                        {"mac_address": "02:00:00:00:00:20", "address": "192.0.2.20"},
                        {"mac_address": "02:00:00:00:00:21", "address": "192.0.2.20"},
                    ],
                    "conversations": [],
                    "packet_sample": [],
                },
                "vlan_views": [],
            }
        ]
        topology = build_topology(
            "00000000-0000-0000-0000-000000000778",
            {
                "sources": [
                    {
                        "source_id": "source-1",
                        "alias": "Synthetic",
                        "vlan_ids": [42],
                        "interface": {"addresses": [], "mac": "02:00:00:00:00:10"},
                    }
                ]
            },
            analyses,
            [],
            [],
        )
        self.assertTrue(topology["identity_warnings"])
        self.assertFalse(any("192.0.2.20" in node["addresses"] for node in topology["nodes"]))


if __name__ == "__main__":
    unittest.main()
