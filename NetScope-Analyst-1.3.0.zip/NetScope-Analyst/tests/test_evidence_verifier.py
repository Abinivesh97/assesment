from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from verify_evidence import verify_session


def _audit_entry(previous_hash: str, event: str) -> dict:
    entry = {
        "timestamp_utc": "2026-01-01T00:00:00+00:00",
        "session_id": "00000000-0000-0000-0000-000000000999",
        "event": event,
        "details": {},
        "previous_hash": previous_hash,
    }
    canonical = json.dumps(entry, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
    return {**entry, "entry_hash": hashlib.sha256(canonical.encode("utf-8")).hexdigest()}


class EvidenceVerifierTests(unittest.TestCase):
    def _session(self, root: Path) -> tuple[Path, Path]:
        session = root / "00000000-0000-0000-0000-000000000999"
        reports = session / "reports"
        reports.mkdir(parents=True)
        evidence = session / "state.json"
        evidence.write_text('{"status":"completed"}', encoding="utf-8")
        first = _audit_entry("", "session_created")
        second = _audit_entry(first["entry_hash"], "session_completed")
        (session / "audit.jsonl").write_text(
            "\n".join(json.dumps(row, ensure_ascii=False) for row in (first, second)) + "\n",
            encoding="utf-8",
        )
        digest = hashlib.sha256(evidence.read_bytes()).hexdigest()
        (reports / "sha256-manifest.txt").write_text(f"{digest}  state.json\n", encoding="utf-8")
        return session, evidence

    def test_valid_session_verifies(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            session, _ = self._session(Path(temporary))
            result = verify_session(session)
        self.assertTrue(result["ok"], result["errors"])
        self.assertEqual(result["manifest_entries"], 1)
        self.assertEqual(result["audit_entries"], 2)

    def test_changed_evidence_and_audit_are_detected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            session, evidence = self._session(Path(temporary))
            evidence.write_text('{"status":"altered"}', encoding="utf-8")
            audit_path = session / "audit.jsonl"
            rows = audit_path.read_text(encoding="utf-8").splitlines()
            changed = json.loads(rows[1])
            changed["event"] = "rewritten"
            rows[1] = json.dumps(changed)
            audit_path.write_text("\n".join(rows) + "\n", encoding="utf-8")
            result = verify_session(session)
        self.assertFalse(result["ok"])
        self.assertTrue(any("SHA-256 mismatch" in error for error in result["errors"]))
        self.assertTrue(any("Audit entry hash mismatch" in error for error in result["errors"]))

    def test_manifest_path_escape_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            session, _ = self._session(root)
            outside = root / "outside.txt"
            outside.write_text("outside", encoding="utf-8")
            digest = hashlib.sha256(outside.read_bytes()).hexdigest()
            (session / "reports" / "sha256-manifest.txt").write_text(
                f"{digest}  ../outside.txt\n",
                encoding="utf-8",
            )
            result = verify_session(session)
        self.assertFalse(result["ok"])
        self.assertTrue(any("escapes the session directory" in error for error in result["errors"]))


if __name__ == "__main__":
    unittest.main()
