"""Allowlisted Nmap job construction and execution."""

from __future__ import annotations

import ipaddress
import subprocess
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from .tools import CREATE_NO_WINDOW


SAFE_ENUMERATION_SCRIPTS = (
    "banner",
    "ssl-cert",
    "ssl-enum-ciphers",
    "http-security-headers",
    "ssh2-enum-algos",
    "smb2-security-mode",
    "rdp-enum-encryption",
    "ftp-anon",
    "dns-recursion",
)

CURATED_VULNERABILITY_SCRIPTS = (
    "ssl-heartbleed",
    "ssl-poodle",
    "smb-vuln-ms17-010",
    "rdp-vuln-ms12-020",
)

PROFILE_LABELS = {
    "automotive_discovery": "Automotive gentle discovery",
    "host_discovery": "Host discovery",
    "quick_tcp": "Quick TCP inventory",
    "standard_tcp": "TCP services and versions",
    "full_tcp": "Full TCP 1–65535",
    "full_tcp_services": "Full TCP + service versions",
    "quick_udp": "Top 100 UDP",
    "full_udp": "Full UDP 1–65535",
    "service_detection": "Service/version detection",
    "os_detection": "OS detection",
    "safe_enumeration": "Curated safe enumeration",
    "vulnerability_checks": "Curated vulnerability checks",
}
RAW_INTERFACE_PROFILES = {"automotive_discovery", "host_discovery", "quick_udp", "full_udp", "os_detection"}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _profile_arguments(profile: str, include_port_zero: bool) -> list[str]:
    full_range = "0-65535" if include_port_zero else "1-65535"
    if profile in ("automotive_discovery", "host_discovery"):
        return ["-sn"]
    if profile == "quick_tcp":
        return ["-sT", "--top-ports", "1000"]
    if profile == "standard_tcp":
        return ["-sT", "--top-ports", "1000", "-sV", "--version-light"]
    if profile == "full_tcp":
        return ["-sT", "-p", full_range]
    if profile == "full_tcp_services":
        return ["-sT", "-p", full_range, "-sV", "--version-light"]
    if profile == "quick_udp":
        return ["-sU", "--top-ports", "100"]
    if profile == "full_udp":
        return ["-sU", "-p", full_range]
    if profile == "service_detection":
        return ["-sT", "--top-ports", "100", "-sV", "--version-all"]
    if profile == "os_detection":
        return ["-O", "--osscan-limit"]
    if profile == "safe_enumeration":
        return ["-sT", "--top-ports", "1000", "-sV", "--version-light", "--script", ",".join(SAFE_ENUMERATION_SCRIPTS)]
    if profile == "vulnerability_checks":
        return ["-sT", "--top-ports", "1000", "-sV", "--version-light", "--script", ",".join(CURATED_VULNERABILITY_SCRIPTS)]
    raise ValueError(f"Unknown Nmap profile: {profile}")


def _target_family(target: str) -> int:
    return ipaddress.ip_network(target, strict=False).version


def build_scan_jobs(nmap_path: str, config: dict[str, Any], session_dir: Path) -> list[dict[str, Any]]:
    scan = config["scan"]
    if not scan.get("enabled"):
        return []
    output_dir = session_dir / "nmap"
    jobs: list[dict[str, Any]] = []
    for source in config.get("sources", []):
        for family in (4, 6):
            targets = [target for target in source.get("targets", []) if _target_family(target) == family]
            if not targets:
                continue
            exclusions = [target for target in scan.get("exclusions", []) if _target_family(target) == family]
            for profile in scan.get("profiles", []):
                base = f"{source['source_id']}-{profile}-ipv{family}"
                xml_path = output_dir / f"{base}.xml"
                normal_path = output_dir / f"{base}.nmap"
                stderr_path = output_dir / f"{base}.stderr.txt"
                argv = [
                    nmap_path,
                    "-n",
                    "--reason",
                    f"-T{scan['timing']}",
                    "--max-rate",
                    str(scan["max_rate"]),
                    "--max-retries",
                    str(scan["max_retries"]),
                    "--host-timeout",
                    f"{scan['host_timeout_seconds']}s",
                    "--stats-every",
                    "10s",
                ]
                if family == 6:
                    argv.append("-6")
                if profile in ("safe_enumeration", "vulnerability_checks"):
                    argv.extend(["--script-timeout", f"{scan['script_timeout_seconds']}s"])
                argv.extend(_profile_arguments(profile, scan.get("include_port_zero", False)))
                raw_interface_bound = bool(source.get("bind_interface") and profile in RAW_INTERFACE_PROFILES)
                source_address = None
                if source.get("bind_interface"):
                    interface = source.get("interface", {})
                    nmap_name = interface.get("nmap_name") or interface.get("name") or interface.get("capture_id")
                    if nmap_name and raw_interface_bound:
                        argv.extend(["-e", str(nmap_name)])
                        source_address = next(
                            (
                                row.get("address")
                                for row in interface.get("addresses", [])
                                if row.get("family") == f"IPv{family}" and row.get("address") and not str(row.get("address")).lower().startswith("fe80:")
                            ),
                            None,
                        )
                        if source_address:
                            argv.extend(["-S", str(source_address)])
                if exclusions:
                    argv.extend(["--exclude", ",".join(exclusions)])
                argv.extend(["-oX", str(xml_path), "-oN", str(normal_path)])
                argv.extend(targets)
                jobs.append(
                    {
                        "id": base,
                        "source_id": source["source_id"],
                        "source_alias": source.get("alias"),
                        "profile": profile,
                        "profile_label": PROFILE_LABELS.get(profile, profile),
                        "family": family,
                        "targets": targets,
                        "binding_mode": (
                            ("raw-interface-and-source" if source_address else "raw-interface")
                            if raw_interface_bound
                            else ("validated-direct-connected-os-route" if source.get("bind_interface") else "operating-system-route")
                        ),
                        "binding_note": (
                            (
                                "Raw-packet profile requested the selected Nmap interface and source address."
                                if source_address
                                else "Raw-packet profile requested the selected Nmap interface; Nmap selects the source address."
                            )
                            if raw_interface_bound
                            else (
                                "TCP connect/version/script sockets follow the Windows route table; targets were constrained to this interface's directly connected prefixes."
                                if source.get("bind_interface")
                                else "No interface attribution is claimed; the operating system selected the route."
                            )
                        ),
                        "target_count": source.get("target_count", 0),
                        "xml_path": str(xml_path),
                        "normal_path": str(normal_path),
                        "stderr_path": str(stderr_path),
                        "argv": argv,
                        "command_display": subprocess.list2cmdline(argv),
                        "status": "queued",
                        "started_at": None,
                        "ended_at": None,
                        "exit_code": None,
                        "error": None,
                    }
                )
    return jobs


def run_scan_job(
    job: dict[str, Any],
    cancel_event: threading.Event,
    on_process: Callable[[str, subprocess.Popen[Any] | None], None],
    on_update: Callable[[dict[str, Any]], None],
) -> dict[str, Any]:
    result = {**job, "status": "running", "started_at": utc_now()}
    if cancel_event.is_set():
        result.update({"status": "cancelled", "ended_at": utc_now(), "error": "Cancelled before the job started"})
        on_update(result)
        return result
    on_update(result)
    stderr_path = Path(job["stderr_path"])
    stderr_path.parent.mkdir(parents=True, exist_ok=True)
    with stderr_path.open("w", encoding="utf-8", errors="replace") as stderr_handle:
        try:
            process = subprocess.Popen(
                job["argv"],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=stderr_handle,
                creationflags=CREATE_NO_WINDOW,
            )
            on_process(job["id"], process)
            while True:
                code = process.poll()
                if code is not None:
                    result["exit_code"] = code
                    result["status"] = "completed" if code == 0 else "failed"
                    if code != 0:
                        result["error"] = f"Nmap exited with code {code}; see stderr artifact"
                    break
                if cancel_event.is_set():
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait(timeout=5)
                    result["exit_code"] = process.returncode
                    result["status"] = "cancelled"
                    result["error"] = "Cancelled by operator"
                    break
                time.sleep(0.25)
        except OSError as exc:
            result["status"] = "failed"
            result["error"] = str(exc)
        finally:
            on_process(job["id"], None)
    result["ended_at"] = utc_now()
    on_update(result)
    return result
