"""Input validation and defensive scope controls."""

from __future__ import annotations

import ipaddress
import platform
import re
from typing import Any


class ValidationError(ValueError):
    pass


LOCAL_V4 = tuple(ipaddress.ip_network(value) for value in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "127.0.0.0/8", "169.254.0.0/16"))
LOCAL_V6 = tuple(ipaddress.ip_network(value) for value in ("fc00::/7", "fe80::/10", "::1/128"))
PROFILE_NAMES = {
    "host_discovery",
    "quick_tcp",
    "standard_tcp",
    "full_tcp",
    "full_tcp_services",
    "quick_udp",
    "full_udp",
    "service_detection",
    "os_detection",
    "automotive_discovery",
    "safe_enumeration",
    "vulnerability_checks",
}
HIGH_IMPACT_PROFILES = {"full_tcp", "full_tcp_services", "quick_udp", "full_udp", "service_detection", "os_detection", "safe_enumeration", "vulnerability_checks"}
INTRUSIVE_PROFILES = {"vulnerability_checks"}


def clean_text(value: Any, maximum: int = 500) -> str:
    text = str(value or "").replace("\x00", "").strip()
    if len(text) > maximum:
        raise ValidationError(f"Text value exceeds {maximum} characters")
    if any(ord(char) < 32 and char not in "\t\r\n" for char in text):
        raise ValidationError("Control characters are not allowed")
    return text


def parse_int(value: Any, name: str, minimum: int, maximum: int) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError) as exc:
        raise ValidationError(f"{name} must be an integer") from exc
    if not minimum <= number <= maximum:
        raise ValidationError(f"{name} must be between {minimum} and {maximum}")
    return number


def parse_bool(value: Any, name: str, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    raise ValidationError(f"{name} must be a JSON boolean")


def parse_ports(value: Any) -> list[int]:
    if value in (None, "", []):
        return []
    tokens = value if isinstance(value, list) else re.split(r"[\s,;]+", str(value).strip())
    result: set[int] = set()
    for token in tokens:
        if token in (None, ""):
            continue
        number = parse_int(token, "port", 0, 65535)
        result.add(number)
    return sorted(result)


def parse_vlan_ids(value: Any) -> list[int]:
    if value in (None, "", []):
        return []
    tokens = value if isinstance(value, list) else re.split(r"[\s,;]+", str(value).strip())
    return sorted({parse_int(token, "VLAN ID", 0, 4095) for token in tokens if token not in (None, "")})


def _is_local_network(network: ipaddress._BaseNetwork) -> bool:
    pools = LOCAL_V4 if network.version == 4 else LOCAL_V6
    return any(network.subnet_of(pool) for pool in pools)


_ZONE_ID = re.compile(r"[A-Za-z0-9_.-]{1,64}")


def _interface_ipv6_zone(interface: dict[str, Any]) -> str | None:
    for entry in interface.get("addresses", []):
        value = str(entry.get("address") or "")
        if entry.get("family") == "IPv6" and "%" in value:
            zone = value.rsplit("%", 1)[1]
            if _ZONE_ID.fullmatch(zone):
                return zone
    if platform.system() == "Windows" and interface.get("if_index") is not None:
        return str(interface["if_index"])
    name = str(interface.get("name") or "")
    return name if _ZONE_ID.fullmatch(name) else None


def _scope_link_local_targets(targets: list[str], interface: dict[str, Any], bind_interface: bool) -> list[str]:
    scoped: list[str] = []
    zone = _interface_ipv6_zone(interface)
    for target in targets:
        network = ipaddress.ip_network(target, strict=False)
        address = network.network_address
        if network.version != 6 or not address.is_link_local:
            scoped.append(target)
            continue
        if not bind_interface:
            raise ValidationError("IPv6 link-local targets require interface binding so their zone and evidence source are unambiguous")
        supplied_zone = getattr(address, "scope_id", None)
        if not zone:
            raise ValidationError("The selected interface has no usable IPv6 zone ID for a link-local target")
        if supplied_zone and str(supplied_zone).casefold() != zone.casefold():
            raise ValidationError(f"IPv6 link-local target zone %{supplied_zone} does not match selected interface zone %{zone}")
        scoped.append(target if supplied_zone else f"{address.compressed}%{zone}")
    return scoped


def _attribution_scopes_overlap(left: ipaddress._BaseNetwork, right: ipaddress._BaseNetwork) -> bool:
    if left.version != right.version or not left.overlaps(right):
        return False
    if left.version == 6 and left.network_address.is_link_local and right.network_address.is_link_local:
        left_zone = getattr(left.network_address, "scope_id", None)
        right_zone = getattr(right.network_address, "scope_id", None)
        if left_zone and right_zone and str(left_zone).casefold() != str(right_zone).casefold():
            return False
    return True


def parse_targets(
    value: Any,
    *,
    allow_public: bool = False,
    allow_large: bool = False,
    maximum_addresses: int = 4096,
) -> tuple[list[str], list[str], int]:
    raw = value if isinstance(value, list) else re.split(r"[\s,;]+", str(value or "").strip())
    targets: list[str] = []
    warnings: list[str] = []
    total = 0
    for token_value in raw:
        token = clean_text(token_value, 160)
        if not token:
            continue
        if token.startswith("-"):
            raise ValidationError(f"Unsupported target syntax: {token}")
        try:
            network = ipaddress.ip_network(token, strict=False)
        except ValueError as exc:
            raise ValidationError(f"Targets must be literal IP addresses or CIDRs: {token}") from exc
        if network.prefixlen == 0:
            raise ValidationError("A /0 target is never accepted")
        scope_id = getattr(network.network_address, "scope_id", None)
        if scope_id is not None and (
            network.version != 6
            or not network.network_address.is_link_local
            or network.prefixlen != 128
            or not _ZONE_ID.fullmatch(str(scope_id))
        ):
            raise ValidationError(f"Unsupported IPv6 zone syntax: {token}")
        if network.version == 6 and network.network_address.is_link_local and network.prefixlen != 128:
            raise ValidationError("IPv6 link-local targets must be individual addresses, not CIDR ranges")
        if network.network_address.is_multicast or network.network_address.is_unspecified:
            raise ValidationError(f"Multicast or unspecified target is not allowed: {token}")
        if network.version == 4 and network.broadcast_address.is_multicast:
            raise ValidationError(f"Multicast target is not allowed: {token}")
        if not _is_local_network(network):
            if not allow_public:
                raise ValidationError(f"Non-local target requires explicit public-scope opt-in: {token}")
            warnings.append(f"Non-local scope explicitly enabled for {network}")
        count = int(network.num_addresses)
        total += count
        normalized = str(network.network_address) if network.prefixlen == network.max_prefixlen else str(network)
        if normalized not in targets:
            targets.append(normalized)
    if total > maximum_addresses and not allow_large:
        raise ValidationError(f"Scope contains {total:,} addresses; explicit large-scope opt-in is required above {maximum_addresses:,}")
    if total > maximum_addresses:
        warnings.append(f"Large scope explicitly enabled: {total:,} addresses")
    if sum(len(target) + 1 for target in targets) > 12_000:
        raise ValidationError("Target list is too long for reliable Windows process execution; combine addresses into approved CIDRs")
    return targets, warnings, total


def validate_session_config(raw: dict[str, Any], interface_inventory: list[dict[str, Any]]) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise ValidationError("Request body must be an object")
    automotive_mode = parse_bool(raw.get("automotive_mode"), "automotive mode", True)
    inventory = {item["id"]: item for item in interface_inventory}
    source_rows = raw.get("sources")
    if not isinstance(source_rows, list) or not source_rows:
        raise ValidationError("Select at least one interface")
    if len(source_rows) > 32:
        raise ValidationError("At most 32 capture sources are allowed per session")

    capture_raw = raw.get("capture") if isinstance(raw.get("capture"), dict) else {}
    capture_enabled = parse_bool(capture_raw.get("enabled"), "capture enabled", True)
    capture = {
        "enabled": capture_enabled,
        "duration_seconds": parse_int(capture_raw.get("duration_seconds", 300), "duration", 0, 86400),
        "max_file_mb": parse_int(capture_raw.get("max_file_mb", 512), "maximum capture size", 0, 32768),
        "packet_limit": parse_int(capture_raw.get("packet_limit", 0), "packet limit", 0, 2_000_000_000),
        "snaplen": parse_int(capture_raw.get("snaplen", 0), "snap length", 0, 262144),
        "promiscuous": parse_bool(capture_raw.get("promiscuous"), "promiscuous mode", True),
        "bpf_filter": clean_text(capture_raw.get("bpf_filter"), 1000),
    }
    if capture_enabled and capture["duration_seconds"] == 0 and capture["max_file_mb"] == 0 and capture["packet_limit"] == 0:
        raise ValidationError("An unlimited capture needs a duration, file-size ceiling, or packet limit")

    scan_raw = raw.get("scan") if isinstance(raw.get("scan"), dict) else {}
    scan_enabled = parse_bool(scan_raw.get("enabled"), "scan enabled", False)
    authorized = parse_bool(scan_raw.get("authorized"), "scan authorization", False)
    if scan_enabled and not authorized:
        raise ValidationError("Active scanning requires authorization acknowledgement")
    profiles = scan_raw.get("profiles", ["automotive_discovery"] if automotive_mode else ["host_discovery"])
    if not isinstance(profiles, list) or not profiles:
        profiles = []
    if not all(isinstance(profile, str) for profile in profiles):
        raise ValidationError("Scan profiles must be strings")
    unknown = set(profiles) - PROFILE_NAMES
    if unknown:
        raise ValidationError(f"Unknown scan profiles: {', '.join(sorted(unknown))}")
    profiles = list(dict.fromkeys(profiles))
    if scan_enabled and not profiles:
        raise ValidationError("Select at least one active scan profile")
    allow_high_impact = parse_bool(scan_raw.get("allow_high_impact"), "high-impact scan opt-in", False)
    if scan_enabled and set(profiles) & HIGH_IMPACT_PROFILES and not allow_high_impact:
        raise ValidationError("Selected scan profiles require high-impact scan opt-in")
    allow_intrusive = parse_bool(scan_raw.get("allow_intrusive"), "intrusive-check opt-in", False)
    if set(profiles) & INTRUSIVE_PROFILES and not allow_intrusive:
        raise ValidationError("Vulnerability checks require the separate intrusive-check opt-in")
    allow_public = parse_bool(scan_raw.get("allow_public"), "public-scope opt-in", False)
    allow_large = parse_bool(scan_raw.get("allow_large"), "large-scope opt-in", False)
    include_port_zero = parse_bool(scan_raw.get("include_port_zero"), "port-zero opt-in", False)
    max_rate = parse_int(scan_raw.get("max_rate", 50 if automotive_mode else 500), "maximum scan rate", 1, 100000)
    timing = parse_int(scan_raw.get("timing", 2 if automotive_mode else 3), "Nmap timing", 0, 5)

    exclusions, exclusion_warnings, _ = parse_targets(
        scan_raw.get("exclusions", []),
        allow_public=True,
        allow_large=True,
        maximum_addresses=2**32,
    ) if scan_raw.get("exclusions") else ([], [], 0)

    sources: list[dict[str, Any]] = []
    seen_interfaces: set[str] = set()
    all_warnings: list[str] = list(exclusion_warnings)
    for position, row in enumerate(source_rows):
        if not isinstance(row, dict):
            raise ValidationError("Each source must be an object")
        interface_id = clean_text(row.get("interface_id"), 200)
        if interface_id not in inventory:
            raise ValidationError(f"Interface is no longer available: {interface_id}")
        if interface_id in seen_interfaces:
            raise ValidationError("Select each physical/OS interface once and list all of its VLAN views in that source")
        seen_interfaces.add(interface_id)
        interface = inventory[interface_id]
        bind_interface = parse_bool(row.get("bind_interface"), "interface binding", True)
        if capture_enabled and not interface.get("capture_ready"):
            raise ValidationError(f"Interface is not capture-ready: {interface.get('name') or interface_id}")
        targets: list[str] = []
        target_count = 0
        if scan_enabled:
            targets, warnings, target_count = parse_targets(
                row.get("targets", []),
                allow_public=allow_public,
                allow_large=allow_large,
            )
            targets = _scope_link_local_targets(targets, interface, bind_interface)
            all_warnings.extend(warnings)
            if not targets:
                raise ValidationError(f"Active scan targets are missing for {interface.get('name') or interface_id}")
            if bind_interface and not interface.get("scan_ready"):
                raise ValidationError(f"{interface.get('name') or interface_id} has no routable address; disable scan binding or use capture-only mode")
            if bind_interface:
                connected_networks = []
                for value in interface.get("networks", []):
                    try:
                        connected_networks.append(ipaddress.ip_network(value, strict=False))
                    except ValueError:
                        continue
                for target in targets:
                    target_network = ipaddress.ip_network(target, strict=False)
                    if not any(
                        target_network.version == connected.version and target_network.subnet_of(connected)
                        for connected in connected_networks
                    ):
                        raise ValidationError(
                            f"Bound target {target} is not inside a directly connected prefix on {interface.get('name') or interface_id}"
                        )
        sources.append(
            {
                "source_id": f"source-{position + 1}",
                "interface_id": interface_id,
                "interface": interface,
                "alias": clean_text(row.get("alias") or interface.get("name") or f"Interface {position + 1}", 120),
                "role": clean_text(row.get("role"), 240),
                "switch_port": clean_text(row.get("switch_port"), 120),
                "vlan_ids": parse_vlan_ids(row.get("vlan_ids")),
                "targets": targets,
                "target_count": target_count,
                "bind_interface": bind_interface,
                "expected_ports": parse_ports(row.get("expected_ports")),
            }
        )

    if scan_enabled:
        aggregate_target_count = sum(int(source.get("target_count", 0)) for source in sources)
        if aggregate_target_count > 4096 and not allow_large:
            raise ValidationError(
                f"Combined session scope contains {aggregate_target_count:,} address attempts; large-scope opt-in is required above 4,096"
            )
        if aggregate_target_count > 4096:
            all_warnings.append(f"Large combined session scope explicitly enabled: {aggregate_target_count:,} address attempts")
        for left_index, left in enumerate(sources):
            if not left.get("bind_interface"):
                continue
            left_targets = [ipaddress.ip_network(value, strict=False) for value in left.get("targets", [])]
            for right in sources[left_index + 1 :]:
                if not right.get("bind_interface"):
                    continue
                right_targets = [ipaddress.ip_network(value, strict=False) for value in right.get("targets", [])]
                if any(_attribution_scopes_overlap(a, b) for a in left_targets for b in right_targets):
                    raise ValidationError(
                        f"Overlapping bound scan scopes on {left.get('alias')} and {right.get('alias')} cannot be attributed reliably"
                    )

    return {
        "name": clean_text(raw.get("name") or "Network assessment", 120),
        "operator": clean_text(raw.get("operator"), 120),
        "authorization_note": clean_text(raw.get("authorization_note"), 1000),
        "topology_notes": clean_text(raw.get("topology_notes"), 4000),
        "automotive_mode": automotive_mode,
        "capture": capture,
        "scan": {
            "enabled": scan_enabled,
            "authorized": authorized,
            "profiles": profiles,
            "allow_public": allow_public,
            "allow_large": allow_large,
            "allow_high_impact": allow_high_impact,
            "allow_intrusive": allow_intrusive,
            "include_port_zero": include_port_zero,
            "max_rate": max_rate,
            "max_retries": parse_int(scan_raw.get("max_retries", 1), "maximum retries", 0, 10),
            "timing": timing,
            "host_timeout_seconds": parse_int(scan_raw.get("host_timeout_seconds", 900), "host timeout", 30, 86400),
            "script_timeout_seconds": parse_int(scan_raw.get("script_timeout_seconds", 120), "script timeout", 10, 3600),
            "exclusions": exclusions,
        },
        "sources": sources,
        "warnings": all_warnings,
    }
