"""JSON, HTML, CSV, manifest, and evidence-bundle generation."""

from __future__ import annotations

import csv
import html
import json
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .analysis import sha256_file
from .findings import severity_counts
from .testcases import evaluate_test_cases


LIMITATIONS = [
    "A capture sees only traffic delivered to the measurement point. Full switched-segment visibility normally requires an authorized TAP or mirror/SPAN configuration.",
    "VLAN offload or the selected capture provider can remove 802.1Q tags. A missing tag in the trace does not prove the frame was untagged on the wire.",
    "Cross-source latency and ordering are not authoritative unless timestamp origin, resolution, and synchronization were independently verified.",
    "Nmap scan packets are part of captures taken at the same time and can change load, discovery, and timing observations.",
    "Open ports, service banners, script output, and protocol expert observations are leads for validation, not automatic proof of a vulnerability.",
    "Network-only analysis cannot prove patch state, vendor backports, local configuration, credentials, access-control policy, or physical-layer behavior.",
    "Encrypted traffic and MACsec remain opaque unless authorized keys and an isolated analysis profile are supplied.",
    "Observed TSN/AVB traffic cannot by itself prove Qbv schedules, Qci policing, queue shaping, or worst-case deterministic latency.",
]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def build_report(
    state: dict[str, Any],
    analyses: list[dict[str, Any]],
    scan_records: list[dict[str, Any]],
    assets: list[dict[str, Any]],
    services: list[dict[str, Any]],
    findings: list[dict[str, Any]],
) -> dict[str, Any]:
    config = state["config"]
    scan_records_by_id = {row.get("id"): row for row in scan_records if row.get("id")}
    scan_evidence_rows = []
    for row in state.get("scans", []):
        record = scan_records_by_id.get(row.get("id"))
        parsed = (record or {}).get("parsed") or {}
        scan_evidence_rows.append(
            {
                **row,
                "analysis_available": bool(record) and not bool(parsed.get("parse_error")),
            }
        )
    capture_totals = {
        "packets": sum((row.get("analysis") or {}).get("packets", 0) for row in analyses),
        "bytes": sum((row.get("analysis") or {}).get("bytes", 0) for row in analyses),
        "capture_files": len([row for row in state.get("captures", []) if row.get("path")]),
        "capture_failures": len([row for row in state.get("captures", []) if row.get("status") == "failed"]),
        "scan_jobs": len(state.get("scans", [])),
        "scan_failures": len([row for row in state.get("scans", []) if row.get("status") == "failed"]),
        "scan_cancellations": len([row for row in state.get("scans", []) if row.get("status") == "cancelled"]),
    }
    open_services = [service for service in services if service.get("state") == "open"]
    report = {
        "schema_version": "1.0",
        "report_id": f"report-{state['id']}",
        "generated_at_utc": utc_now(),
        "session": {
            "id": state["id"],
            "name": state.get("name"),
            "operator": config.get("operator"),
            "authorization_note": config.get("authorization_note"),
            "automotive_mode": config.get("automotive_mode"),
            "topology_notes": config.get("topology_notes"),
            "created_at": state.get("created_at"),
            "started_at": state.get("started_at"),
            "ended_at": state.get("ended_at"),
            "status": state.get("status"),
            "system": state.get("system"),
        },
        "scope": {
            "sources": config.get("sources", []),
            "capture_configuration": config.get("capture", {}),
            "capture_commands": [
                {
                    "source_id": row.get("source_id"),
                    "source_alias": row.get("source_alias"),
                    "capture_id": row.get("capture_id"),
                    "command": row.get("command_display"),
                    "started_at": row.get("started_at"),
                    "ended_at": row.get("ended_at"),
                    "exit_code": row.get("exit_code"),
                    "status": row.get("status"),
                    "size_bytes": row.get("size_bytes"),
                }
                for row in state.get("captures", [])
            ],
            "scan_configuration": config.get("scan", {}),
            "effective_nmap_commands": [
                {
                    "id": row.get("id"),
                    "source_id": row.get("source_id"),
                    "profile": row.get("profile"),
                    "family": row.get("family"),
                    "command": row.get("command_display"),
                    "started_at": row.get("started_at"),
                    "ended_at": row.get("ended_at"),
                    "exit_code": row.get("exit_code"),
                    "status": row.get("status"),
                    "binding_mode": row.get("binding_mode"),
                    "binding_note": row.get("binding_note"),
                    "analysis_available": row.get("analysis_available"),
                }
                for row in scan_evidence_rows
            ],
        },
        "coverage": capture_totals,
        "executive_summary": {
            "assets": len(assets),
            "open_services": len(open_services),
            "findings": len(findings),
            "findings_by_severity": severity_counts(findings),
            "observed_vlans": sorted(
                {
                    vlan
                    for row in analyses
                    for vlan in (row.get("analysis") or {}).get("vlan_partitions", {})
                    if vlan != "untagged"
                }
            ),
        },
        "assets": assets,
        "services": services,
        "traffic_analysis": analyses,
        "nmap_results": scan_records,
        "findings": findings,
        "test_case_matrix": evaluate_test_cases(
            config,
            analyses,
            services,
            findings,
            captures=state.get("captures", []),
            scans=scan_evidence_rows,
        ),
        "recommendations": _recommendations(findings, config),
        "warnings": state.get("warnings", []),
        "errors": state.get("errors", []),
        "limitations": LIMITATIONS,
    }
    return report


def _recommendations(findings: list[dict[str, Any]], config: dict[str, Any]) -> list[str]:
    result: list[str] = []
    if any(item.get("category") == "policy-deviation" for item in findings):
        result.append("Reconcile unexpected ports with an ECU/asset owner and maintain a version-controlled expected-service baseline per VLAN and vehicle state.")
    if any(item.get("category") == "vlan-policy" for item in findings):
        result.append("Review Marvell switch access/trunk membership, native VLAN behavior, mirror sources, and inter-VLAN routing controls.")
    if any(item.get("category") == "traffic-observation" for item in findings):
        result.append("Replace or contain cleartext management/application protocols and verify that diagnostics and credentials are not exposed across trust boundaries.")
    if config.get("automotive_mode"):
        result.extend(
            [
                "Import the project ARXML/FIBEX/ODX or an approved ECU/service catalogue before deciding whether a SOME/IP, DoIP, UDS, or dynamic port is unexpected.",
                "Validate capture completeness, VN5620 timestamp provenance, Vector channel mapping, VLAN tag fidelity, and packet drops against a known bench trace.",
                "Run intrusive or full-range enumeration only in an authorized stationary bench state, one ECU at a time, with recovery access available.",
            ]
        )
    if not result:
        result.append("Retain the evidence and compare it with an approved asset, service, VLAN, and timing baseline; absence of a finding is not proof of absence.")
    return result


def _write_csv(path: Path, fieldnames: list[str], rows: Iterable[dict[str, Any]]) -> None:
    def safe(value: Any) -> Any:
        if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@")):
            return "'" + value
        return value

    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: safe(value) for key, value in row.items()})


def _text(value: Any) -> str:
    if value is None:
        return "—"
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def _table(headers: list[tuple[str, str]], rows: Iterable[dict[str, Any]], empty: str = "No data") -> str:
    values = list(rows)
    if not values:
        return f'<p class="muted">{html.escape(empty)}</p>'
    head = "".join(f"<th>{html.escape(label)}</th>" for _, label in headers)
    body = []
    for row in values:
        cells = "".join(f"<td>{html.escape(_text(row.get(key)))}</td>" for key, _ in headers)
        body.append(f"<tr>{cells}</tr>")
    return f'<div class="table-wrap"><table><thead><tr>{head}</tr></thead><tbody>{"".join(body)}</tbody></table></div>'


def _render_html(report: dict[str, Any], source_id: str | None = None, vlan_id: int | None = None) -> str:
    session = report["session"]
    sources = report["scope"]["sources"]
    if source_id:
        sources = [row for row in sources if row.get("source_id") == source_id]
    source_ids = {row.get("source_id") for row in sources}
    assets = [row for row in report["assets"] if not source_id or set(row.get("sources", [])) & source_ids]
    services = [row for row in report["services"] if not source_id or row.get("source_id") in source_ids]
    findings = [row for row in report["findings"] if not source_id or set(row.get("source_ids", [])) & source_ids]
    analyses = [row for row in report["traffic_analysis"] if not source_id or row.get("source_id") in source_ids]
    vlan_service_attribution = True
    vlan_attribution_note = ""
    if vlan_id is not None:
        vlan_service_attribution = any(
            int(source.get("interface", {}).get("vlan_id", -1) or -1) == vlan_id
            or (len(source.get("vlan_ids", [])) == 1 and int(source["vlan_ids"][0]) == vlan_id)
            for source in sources
        )
        if not vlan_service_attribution:
            assets = []
            services = []
            findings = [
                finding
                for finding in findings
                if any(str(evidence.get("vlan")) == str(vlan_id) for evidence in finding.get("evidence", []))
            ]
            vlan_attribution_note = (
                "This is a traffic-only VLAN partition from a multi-VLAN source. Active-scan assets, services, "
                "findings, and commands are excluded because the selected egress route cannot be attributed to this VLAN alone."
            )
    title_suffix = f" — {sources[0].get('alias')}" if source_id and sources else ""
    if vlan_id is not None:
        title_suffix += f" — VLAN {vlan_id}"
    counts = Counter(item.get("severity", "info") for item in findings)

    source_cards = []
    for source in sources:
        interface = source.get("interface", {})
        addresses = ", ".join(f"{row.get('address')}/{row.get('prefix_length')}" for row in interface.get("addresses", [])) or "No L3 address"
        source_cards.append(
            f"""<article class="source-card">
            <h3>{html.escape(_text(source.get('alias')))}</h3>
            <p>{html.escape(_text(interface.get('description') or interface.get('name')))}</p>
            <dl><dt>Role / switch port</dt><dd>{html.escape(_text(source.get('role') or source.get('switch_port')))}</dd>
            <dt>Capture provider</dt><dd>{html.escape(_text(interface.get('provider')))}</dd>
            <dt>Addresses</dt><dd>{html.escape(addresses)}</dd>
            <dt>Expected VLANs</dt><dd>{html.escape(', '.join(map(str, source.get('vlan_ids', []))) or 'Not supplied')}</dd>
            <dt>Expected ports</dt><dd>{html.escape(', '.join(map(str, source.get('expected_ports', []))) or 'Not supplied')}</dd></dl>
            </article>"""
        )

    analysis_sections = []
    for row in analyses:
        analysis = row.get("analysis") or {}
        if vlan_id is not None:
            vlan_view = next((item for item in row.get("vlan_views", []) if int(item.get("vlan_id", -1)) == vlan_id), None)
            if not vlan_view:
                continue
            analysis = vlan_view.get("analysis") or {}
        protocol_table = _table([("protocol", "Protocol"), ("count", "Packets")], analysis.get("protocols", [])[:25])
        vlan_table = _table(
            [("vlan", "VLAN"), ("packets", "Packets"), ("bytes", "Bytes")],
            [{"vlan": key, "packets": value.get("packets"), "bytes": value.get("bytes")} for key, value in analysis.get("vlan_partitions", {}).items()],
        )
        auto = analysis.get("automotive", {})
        auto_rows = []
        for category, entries in auto.items():
            for entry in entries[:20]:
                auto_rows.append({"category": category.replace("_", " "), "value": entry.get("value"), "count": entry.get("count")})
        automotive_table = _table([("category", "Category"), ("value", "Decoded value"), ("count", "Packets")], auto_rows, "No supported automotive fields were decoded")
        endpoint_table = _table(
            [("address", "Endpoint"), ("sent_packets", "Sent packets"), ("sent_bytes", "Sent bytes"), ("received_packets", "Received packets"), ("received_bytes", "Received bytes")],
            analysis.get("top_endpoints", [])[:50],
        )
        conversation_table = _table(
            [("protocol", "Protocol"), ("endpoint_a", "Endpoint A"), ("endpoint_b", "Endpoint B"), ("packets", "Packets"), ("bytes", "Bytes")],
            analysis.get("conversations", [])[:75],
        )
        port_table = _table(
            [("transport", "Transport"), ("port", "Destination port"), ("service_guess", "Service guess"), ("packets", "Packets")],
            analysis.get("destination_ports", [])[:75],
        )
        name_rows = (
            [{"type": "DNS query", **item} for item in analysis.get("dns_names", [])[:50]]
            + [{"type": "TLS SNI", **item} for item in analysis.get("tls_server_names", [])[:50]]
            + [{"type": "HTTP Host", **item} for item in analysis.get("http_hosts", [])[:50]]
        )
        name_table = _table([("type", "Type"), ("name", "Name"), ("count", "Packets")], name_rows, "No DNS, TLS SNI, or HTTP host metadata decoded")
        lldp_table = _table([("neighbor", "LLDP neighbor"), ("count", "Packets")], analysis.get("lldp_neighbors", []), "No LLDP neighbors decoded")
        event_rows = [{"event": key.replace("_", " "), "count": value} for key, value in analysis.get("tcp_events", {}).items()]
        event_rows.extend(analysis.get("automotive_expert_events", [])[:100])
        event_table = _table([("event", "Event / field"), ("count", "Count")], event_rows, "No selected transport or automotive expert events decoded")
        vlan_stack_table = _table([("stack", "Tag stack / PCP / DEI"), ("count", "Packets")], analysis.get("vlan_stacks", []), "No retained VLAN tag stacks")
        analysis_sections.append(
            f"""<section><h2>Traffic — {html.escape(_text(row.get('source_alias') or row.get('source_id')))}</h2>
            <div class="metrics"><div><b>{analysis.get('packets', 0):,}</b><span>packets</span></div><div><b>{analysis.get('bytes', 0):,}</b><span>bytes</span></div><div><b>{analysis.get('duration_seconds', 0):.3f}</b><span>seconds</span></div><div><b>{analysis.get('reported_capture_drops', 0):,}</b><span>reported drops</span></div><div><b>{len(analysis.get('vlan_partitions', {}))}</b><span>VLAN views</span></div></div>
            <h3>Protocol hierarchy</h3>{protocol_table}<h3>VLAN partitions</h3>{vlan_table}<h3>VLAN tag stacks</h3>{vlan_stack_table}
            <h3>Automotive Ethernet</h3>{automotive_table}<h3>Transport and protocol events</h3>{event_table}
            <h3>Top endpoints</h3>{endpoint_table}<h3>Top conversations</h3>{conversation_table}<h3>Observed destination ports</h3>{port_table}
            <h3>Name and application metadata</h3>{name_table}<h3>LLDP topology observations</h3>{lldp_table}</section>"""
        )

    service_rows = [{**row, "product_version": " ".join(filter(None, (row.get("product"), row.get("version")))), "scripts_text": "; ".join(script.get("id", "") for script in row.get("scripts", []))} for row in services]
    findings_rows = [{**row, "sources_text": ", ".join(row.get("source_ids", [])), "cves_text": ", ".join(row.get("cve_ids", []))} for row in findings]
    command_rows = [
        row
        for row in report["scope"].get("effective_nmap_commands", [])
        if (not source_id or row.get("source_id") in source_ids) and vlan_service_attribution
    ]
    capture_command_rows = [
        row
        for row in report["scope"].get("capture_commands", [])
        if not source_id or row.get("source_id") in source_ids
    ]
    matrix_analyses = []
    for row in analyses:
        if vlan_id is None:
            matrix_analyses.append(row)
            continue
        vlan_view = next(
            (item for item in row.get("vlan_views", []) if int(item.get("vlan_id", -1)) == vlan_id),
            None,
        )
        if vlan_view:
            matrix_analyses.append({**row, "analysis": vlan_view.get("analysis") or {}, "vlan_views": [vlan_view]})
    visible_packets = sum((row.get("analysis") or {}).get("packets", 0) for row in matrix_analyses)
    if source_id or vlan_id is not None:
        matrix_config = {
            "automotive_mode": session.get("automotive_mode"),
            "capture": report["scope"].get("capture_configuration", {}),
            "scan": report["scope"].get("scan_configuration", {}),
            "sources": sources,
        }
        test_case_rows = evaluate_test_cases(
            matrix_config,
            matrix_analyses,
            services,
            findings,
            captures=capture_command_rows,
            scans=command_rows,
        )
    else:
        test_case_rows = report.get("test_case_matrix", [])
    generated = report.get("generated_at_utc")
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>{html.escape(_text(session.get('name')))}{html.escape(title_suffix)} — NetScope Report</title>
    <style>
    :root{{--ink:#182528;--muted:#607174;--line:#dbe5e3;--paper:#fff;--wash:#f3f7f6;--navy:#0c2c33;--teal:#0b8177;--red:#b2333e;--amber:#b06700}}
    *{{box-sizing:border-box}} body{{margin:0;background:var(--wash);color:var(--ink);font:14px/1.55 Inter,Segoe UI,Arial,sans-serif}} main{{max-width:1160px;margin:0 auto;background:var(--paper);min-height:100vh;padding:48px 54px}} header{{border-bottom:4px solid var(--teal);padding-bottom:26px}} .eyebrow{{letter-spacing:.16em;text-transform:uppercase;color:var(--teal);font-weight:700}} h1{{font-size:34px;line-height:1.15;margin:8px 0}} h2{{font-size:22px;margin:40px 0 14px;border-bottom:1px solid var(--line);padding-bottom:8px}} h3{{font-size:16px;margin:24px 0 8px}} .muted{{color:var(--muted)}} .metrics{{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin:24px 0}} .metrics div{{background:var(--navy);color:white;padding:18px;border-radius:8px}} .metrics b{{font-size:24px;display:block}} .metrics span{{color:#b8d2d1;text-transform:uppercase;font-size:10px;letter-spacing:.1em}} .source-grid{{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}} .source-card{{border:1px solid var(--line);border-radius:8px;padding:18px}} .source-card h3{{margin-top:0}} dl{{display:grid;grid-template-columns:140px 1fr;gap:6px 10px}} dt{{color:var(--muted)}} dd{{margin:0}} .table-wrap{{overflow:auto;border:1px solid var(--line);border-radius:7px}} table{{width:100%;border-collapse:collapse;font-size:12px}} th{{background:#edf4f2;text-align:left;color:#31494c}} th,td{{padding:8px 10px;border-bottom:1px solid var(--line);vertical-align:top}} .severity{{text-transform:uppercase;font-weight:700}} .severity.high,.severity.critical{{color:var(--red)}} .severity.medium{{color:var(--amber)}} .callout{{border-left:4px solid var(--amber);background:#fff6e8;padding:12px 16px;margin:12px 0}} footer{{margin-top:50px;border-top:1px solid var(--line);padding-top:16px;color:var(--muted);font-size:11px}}
    @media print{{body{{background:#fff}}main{{max-width:none;padding:20px}}.table-wrap{{overflow:visible}}}}
    </style></head><body><main>
    <header><div class="eyebrow">NetScope Analyst · evidence report</div><h1>{html.escape(_text(session.get('name')))}{html.escape(title_suffix)}</h1><p class="muted">Session {html.escape(_text(session.get('id')))} · Generated {html.escape(_text(generated))}</p></header>
    <section><h2>Executive summary</h2><div class="metrics"><div><b>{len(assets)}</b><span>assets</span></div><div><b>{len([row for row in services if row.get('state') == 'open'])}</b><span>open services</span></div><div><b>{counts['high'] + counts['critical']}</b><span>high / critical</span></div><div><b>{counts['medium']}</b><span>medium</span></div><div><b>{visible_packets:,}</b><span>packets</span></div></div>
    <div class="callout">Open ports and automated protocol observations require validation. They are not automatically confirmed vulnerabilities or unnecessary services.</div></section>
    <section><h2>Scope and topology</h2><p>{html.escape(_text(session.get('topology_notes') or 'No topology notes supplied.'))}</p><div class="source-grid">{''.join(source_cards)}</div></section>
    {f'<div class="callout">{html.escape(vlan_attribution_note)}</div>' if vlan_attribution_note else ''}
    <section><h2>Assets and services</h2>{_table([('address','Address'),('protocol','Protocol'),('port','Port'),('state','State'),('service','Service'),('product_version','Product / version'),('reason','Reason'),('scripts_text','Scripts')], service_rows, 'No Nmap service data')}</section>
    <section><h2>Findings</h2>{_table([('severity','Severity'),('title','Finding'),('confidence','Confidence'),('status','Status'),('cves_text','CVE IDs'),('sources_text','Sources'),('description','Evidence interpretation'),('remediation','Recommendation')], findings_rows, 'No automated findings')}</section>
    <section><h2>Eleven-test automotive security coverage</h2>{_table([('id','Test case'),('title','Objective'),('coverage','Coverage'),('status','Scoped status'),('evidence_summary','Evidence summary'),('limitation','Limitation / requirement')], test_case_rows, 'No test-case evaluation')}</section>
    {''.join(analysis_sections)}
    <section><h2>Capture evidence trail</h2>{_table([('source_id','Source'),('capture_id','Capture interface'),('status','Status'),('started_at','Started'),('ended_at','Ended'),('exit_code','Exit'),('size_bytes','Bytes'),('command','Exact command')], capture_command_rows, 'No live capture command was run')}</section>
    <section><h2>Active scan audit trail</h2>{_table([('source_id','Source'),('profile','Profile'),('family','IP family'),('status','Status'),('binding_mode','Vantage binding'),('binding_note','Attribution note'),('started_at','Started'),('ended_at','Ended'),('exit_code','Exit'),('command','Exact command')], command_rows, 'Active scanning was not run')}</section>
    <section><h2>Warnings and incomplete work</h2>{_table([('type','Type'),('message','Message')], [{'type':'warning','message':item} for item in report.get('warnings', [])] + [{'type':'error','message':item} for item in report.get('errors', [])], 'No application warnings or errors')}</section>
    <section><h2>Recommendations</h2><ol>{''.join(f'<li>{html.escape(item)}</li>' for item in report['recommendations'])}</ol></section>
    <section><h2>Limitations</h2><ul>{''.join(f'<li>{html.escape(item)}</li>' for item in report['limitations'])}</ul></section>
    <footer>NetScope Analyst report · Exact commands, raw XML, capture files, and hashes are retained as separate evidence artifacts.</footer>
    </main></body></html>"""


def generate_reports(
    session_dir: Path,
    state: dict[str, Any],
    analyses: list[dict[str, Any]],
    scan_records: list[dict[str, Any]],
    assets: list[dict[str, Any]],
    services: list[dict[str, Any]],
    findings: list[dict[str, Any]],
) -> tuple[dict[str, Any], dict[str, str]]:
    reports_dir = session_dir / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    report = build_report(state, analyses, scan_records, assets, services, findings)
    json_path = reports_dir / "report.json"
    html_path = reports_dir / "report.html"
    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    html_path.write_text(_render_html(report), encoding="utf-8")

    assets_csv = reports_dir / "assets.csv"
    services_csv = reports_dir / "services.csv"
    findings_csv = reports_dir / "findings.csv"
    _write_csv(assets_csv, ["id", "primary_address", "mac", "vendor", "hostnames", "status", "sources", "os_matches"], ({**row, "hostnames": "; ".join(row.get("hostnames", [])), "sources": "; ".join(row.get("sources", [])), "os_matches": _text(row.get("os_matches", []))} for row in assets))
    _write_csv(services_csv, ["id", "asset_id", "address", "source_id", "protocol", "port", "state", "reason", "service", "product", "version", "extra_info", "method", "confidence", "cpe"], services)
    _write_csv(findings_csv, ["id", "severity", "confidence", "status", "category", "title", "cve_ids", "description", "remediation", "source_ids", "asset_ids", "service_ids"], ({**row, "cve_ids": "; ".join(row.get("cve_ids", [])), "source_ids": "; ".join(row.get("source_ids", [])), "asset_ids": "; ".join(row.get("asset_ids", [])), "service_ids": "; ".join(row.get("service_ids", []))} for row in findings))

    artifacts: dict[str, str] = {
        "report_html": str(html_path),
        "report_json": str(json_path),
        "assets_csv": str(assets_csv),
        "services_csv": str(services_csv),
        "findings_csv": str(findings_csv),
    }
    for source in state["config"].get("sources", []):
        source_id = source["source_id"]
        source_path = reports_dir / f"report-{source_id}.html"
        source_path.write_text(_render_html(report, source_id=source_id), encoding="utf-8")
        artifacts[f"report_{source_id}"] = str(source_path)
        analysis_row = next((row for row in analyses if row.get("source_id") == source_id), None)
        for vlan_view in (analysis_row or {}).get("vlan_views", []):
            vlan_id = int(vlan_view["vlan_id"])
            vlan_path = reports_dir / f"report-{source_id}-vlan-{vlan_id}.html"
            vlan_path.write_text(_render_html(report, source_id=source_id, vlan_id=vlan_id), encoding="utf-8")
            artifacts[f"report_{source_id}_vlan_{vlan_id}"] = str(vlan_path)

    manifest_path, bundle_path = refresh_evidence_bundle(session_dir)
    artifacts["sha256_manifest"] = str(manifest_path)
    artifacts["evidence_bundle"] = str(bundle_path)
    return report, artifacts


def refresh_evidence_bundle(session_dir: Path) -> tuple[Path, Path]:
    reports_dir = session_dir / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = reports_dir / "sha256-manifest.txt"
    bundle_path = reports_dir / "reports-and-evidence.zip"
    excluded = {manifest_path.resolve(), bundle_path.resolve()}
    evidence_files: list[Path] = [
        path
        for path in (session_dir / "state.json", session_dir / "session-metadata.json", session_dir / "audit.jsonl")
        if path.is_file()
    ]
    for folder in (session_dir / "captures", session_dir / "nmap", session_dir / "analysis", reports_dir):
        if folder.exists():
            evidence_files.extend(path for path in folder.rglob("*") if path.is_file() and path.resolve() not in excluded)
    manifest_lines = []
    for path in sorted(set(evidence_files)):
        relative = path.relative_to(session_dir).as_posix()
        manifest_lines.append(f"{sha256_file(path)}  {relative}")
    manifest_path.write_text("\n".join(manifest_lines) + "\n", encoding="utf-8")

    with zipfile.ZipFile(bundle_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
        bundle.writestr("README.txt", "This bundle excludes packet captures by default because they can be large and contain sensitive payloads. Verify all retained artifacts against sha256-manifest.txt.\n")
        for path in sorted(set(evidence_files + [manifest_path])):
            if path.suffix.lower() in (".pcap", ".pcapng", ".cap", ".blf", ".erf", ".snoop"):
                continue
            bundle.write(path, path.relative_to(session_dir).as_posix())
    return manifest_path, bundle_path
