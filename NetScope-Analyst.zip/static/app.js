(() => {
  "use strict";

  const ACTIVE_STATES = new Set([
    "queued",
    "starting",
    "capturing",
    "capturing-and-scanning",
    "scanning",
    "stopping",
    "analyzing",
    "reporting",
  ]);

  const HIGH_IMPACT_PROFILES = new Set([
    "full_tcp",
    "full_tcp_services",
    "quick_udp",
    "full_udp",
    "service_detection",
    "standard_tcp",
    "os_detection",
    "safe_enumeration",
    "vulnerability_checks",
  ]);

  const INTRUSIVE_PROFILES = new Set(["vulnerability_checks"]);

  const FALLBACK_PROFILES = {
    automotive_discovery: { label: "Automotive gentle discovery", impact: "low", description: "Host discovery with conservative automotive defaults." },
    host_discovery: { label: "Host discovery", impact: "low", description: "ARP/ND and standard Nmap host discovery." },
    quick_tcp: { label: "Quick TCP inventory", impact: "moderate", description: "Nmap's top 1,000 TCP ports." },
    standard_tcp: { label: "TCP services and versions", impact: "high", description: "Top TCP ports plus lightweight version probes." },
    full_tcp: { label: "Full TCP 1–65535", impact: "high", description: "Every standard TCP port." },
    full_tcp_services: { label: "Full TCP + service versions", impact: "very-high", description: "Every TCP port plus version probes on discovered open services." },
    quick_udp: { label: "Top 100 UDP", impact: "high", description: "Focused UDP inventory." },
    full_udp: { label: "Full UDP 1–65535", impact: "very-high", description: "Long-running, bench-only UDP range." },
    service_detection: { label: "Service/version detection", impact: "high", description: "Exhaustive service/version probes against the top 100 TCP ports." },
    os_detection: { label: "OS detection", impact: "high", description: "Heuristic operating-system fingerprinting." },
    safe_enumeration: { label: "Curated safe enumeration", impact: "high", description: "Pinned banner, TLS, SSH, SMB, RDP, FTP, HTTP, and DNS checks." },
    vulnerability_checks: { label: "Curated vulnerability checks", impact: "intrusive", description: "Small pinned NSE allowlist; results require validation." },
  };

  const VIEW_COPY = {
    assessment: ["Assessment workspace", "Build a new assessment"],
    active: ["Live evidence", "Session activity & results"],
    history: ["Evidence archive", "Session history"],
  };

  const token = document.querySelector('meta[name="netscope-token"]')?.content || "";
  const byId = (id) => document.getElementById(id);
  const queryAll = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  const ui = {
    pageEyebrow: byId("pageEyebrow"),
    pageTitle: byId("pageTitle"),
    globalBanner: byId("globalBanner"),
    globalBannerTitle: byId("globalBannerTitle"),
    globalBannerText: byId("globalBannerText"),
    readinessOrbit: byId("readinessOrbit"),
    readinessScore: byId("readinessScore"),
    systemSummary: byId("systemSummary"),
    preflightGrid: byId("preflightGrid"),
    profileGrid: byId("profileGrid"),
    interfaceGrid: byId("interfaceGrid"),
    interfaceReadinessNotice: byId("interfaceReadinessNotice"),
    interfaceSearch: byId("interfaceSearch"),
    selectedCount: byId("selectedCount"),
    sourceConfigSection: byId("sourceConfigSection"),
    sourceList: byId("sourceList"),
    scanSettings: byId("scanSettings"),
    scanDisabledMessage: byId("scanDisabledMessage"),
    launchSummary: byId("launchSummary"),
    launchDetail: byId("launchDetail"),
    reviewLaunchButton: byId("reviewLaunchButton"),
    reviewDialog: byId("reviewDialog"),
    reviewSummary: byId("reviewSummary"),
    reviewWarning: byId("reviewWarning"),
    confirmLaunchButton: byId("confirmLaunchButton"),
    activeEmptyState: byId("activeEmptyState"),
    sessionDetail: byId("sessionDetail"),
    sessionStatusBadge: byId("sessionStatusBadge"),
    sessionModeBadge: byId("sessionModeBadge"),
    activeSessionName: byId("activeSessionName"),
    activeSessionId: byId("activeSessionId"),
    activeSessionTime: byId("activeSessionTime"),
    stopCaptureButton: byId("stopCaptureButton"),
    cancelScansButton: byId("cancelScansButton"),
    sessionMetrics: byId("sessionMetrics"),
    sourceProgressGrid: byId("sourceProgressGrid"),
    liveIndicator: byId("liveIndicator"),
    findingsCount: byId("findingsCount"),
    findingsTableBody: byId("findingsTableBody"),
    servicesCount: byId("servicesCount"),
    servicesTableBody: byId("servicesTableBody"),
    artifactGrid: byId("artifactGrid"),
    messageLogPanel: byId("messageLogPanel"),
    messageLog: byId("messageLog"),
    historyList: byId("historyList"),
    navActiveStatus: byId("navActiveStatus"),
    navActiveCount: byId("navActiveCount"),
    navHistoryCount: byId("navHistoryCount"),
    importDialog: byId("importDialog"),
    importFile: byId("importFile"),
    fileDrop: byId("fileDrop"),
    fileDropTitle: byId("fileDropTitle"),
    fileDropDetail: byId("fileDropDetail"),
    uploadProgress: byId("uploadProgress"),
    uploadProgressBar: byId("uploadProgressBar"),
    uploadProgressText: byId("uploadProgressText"),
    confirmImportButton: byId("confirmImportButton"),
    toastRegion: byId("toastRegion"),
  };

  const state = {
    system: null,
    profiles: { ...FALLBACK_PROFILES },
    interfaces: [],
    sessions: [],
    selectedSources: new Map(),
    selectedProfiles: new Set(["automotive_discovery"]),
    interfaceFilter: "all",
    activeSession: null,
    activeSessionId: localStorage.getItem("netscope.activeSessionId") || null,
    pollTimer: null,
    currentView: "assessment",
    loading: new Set(),
    uploadRequest: null,
  };

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function splitTokens(value) {
    if (Array.isArray(value)) return value.map(String).filter(Boolean);
    return String(value || "").split(/[\s,;]+/).map((item) => item.trim()).filter(Boolean);
  }

  function toInteger(id, fallback = 0) {
    const value = Number.parseInt(byId(id)?.value, 10);
    return Number.isFinite(value) ? value : fallback;
  }

  function formatNumber(value) {
    const number = Number(value || 0);
    return new Intl.NumberFormat(undefined, { notation: number >= 1000000 ? "compact" : "standard", maximumFractionDigits: 1 }).format(number);
  }

  function formatBytes(value) {
    let bytes = Number(value || 0);
    if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
    const units = ["B", "KB", "MB", "GB", "TB"];
    let index = 0;
    while (bytes >= 1024 && index < units.length - 1) {
      bytes /= 1024;
      index += 1;
    }
    return `${bytes.toFixed(index === 0 ? 0 : bytes >= 10 ? 1 : 2)} ${units[index]}`;
  }

  function formatDate(value, includeTime = true) {
    if (!value) return "—";
    const date = new Date(value);
    if (Number.isNaN(date.valueOf())) return String(value);
    return new Intl.DateTimeFormat(undefined, includeTime
      ? { dateStyle: "medium", timeStyle: "short" }
      : { dateStyle: "medium" }).format(date);
  }

  function formatDuration(seconds) {
    const total = Math.max(0, Math.floor(Number(seconds || 0)));
    const hours = Math.floor(total / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const secs = total % 60;
    if (hours) return `${hours}h ${minutes}m ${secs}s`;
    if (minutes) return `${minutes}m ${secs}s`;
    return `${secs}s`;
  }

  function elapsedTime(session) {
    if (!session?.started_at) return "Waiting to start";
    const end = session.ended_at ? new Date(session.ended_at) : new Date();
    const start = new Date(session.started_at);
    return `${formatDuration((end - start) / 1000)} elapsed`;
  }

  function statusLabel(status) {
    return String(status || "unknown").replaceAll("-", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
  }

  function statusClass(status) {
    if (ACTIVE_STATES.has(status)) return "status-badge--active";
    if (status === "completed") return "status-badge--complete";
    if (["completed-with-errors", "interrupted", "cancelled", "stopped"].includes(status)) return "status-badge--warn";
    if (status === "failed") return "status-badge--failed";
    return "";
  }

  function isPrivateRecommendedTarget(network) {
    const value = String(network || "").trim().toLowerCase();
    if (/^(fc|fd)[0-9a-f]{2}:/.test(value)) return true;
    const address = value.split("/", 1)[0];
    const octets = address.split(".").map(Number);
    if (octets.length !== 4 || octets.some((part) => !Number.isInteger(part))) return false;
    return octets[0] === 10
      || (octets[0] === 172 && octets[1] >= 16 && octets[1] <= 31)
      || (octets[0] === 192 && octets[1] === 168);
  }

  function sourceRecommendedTargets(iface) {
    if (Array.isArray(iface.recommended_targets)) return iface.recommended_targets.filter(Boolean);
    return (Array.isArray(iface.networks) ? iface.networks : []).filter(isPrivateRecommendedTarget);
  }

  async function api(path, options = {}) {
    const method = String(options.method || "GET").toUpperCase();
    const headers = new Headers(options.headers || {});
    headers.set("Accept", "application/json");
    if (method !== "GET" && method !== "HEAD") headers.set("X-NetScope-Token", token);
    let body = options.body;
    if (body !== undefined && body !== null && !(body instanceof Blob) && !(body instanceof ArrayBuffer) && typeof body !== "string") {
      headers.set("Content-Type", "application/json");
      body = JSON.stringify(body);
    }
    const response = await fetch(path, { method, headers, body, cache: "no-store" });
    const contentType = response.headers.get("content-type") || "";
    const payload = contentType.includes("application/json") ? await response.json() : { ok: response.ok, error: await response.text() };
    if (!response.ok || payload?.ok === false) throw new Error(payload?.error || `${response.status} ${response.statusText}`);
    return payload;
  }

  function showBanner(title, message) {
    ui.globalBannerTitle.textContent = title;
    ui.globalBannerText.textContent = message;
    ui.globalBanner.classList.remove("is-hidden");
  }

  function hideBanner() {
    ui.globalBanner.classList.add("is-hidden");
  }

  function toast(title, message = "", type = "success") {
    const item = document.createElement("div");
    item.className = `toast${type === "error" ? " toast--error" : ""}`;
    item.innerHTML = `<span>${type === "error" ? "!" : "✓"}</span><div><strong>${escapeHtml(title)}</strong>${message ? `<p>${escapeHtml(message)}</p>` : ""}</div>`;
    ui.toastRegion.append(item);
    window.setTimeout(() => item.remove(), 5200);
  }

  function setButtonBusy(button, busy, busyText) {
    if (!button) return;
    if (busy) {
      button.dataset.originalText = button.textContent;
      button.textContent = busyText || "Working…";
      button.disabled = true;
    } else {
      button.textContent = button.dataset.originalText || button.textContent;
      button.disabled = false;
      delete button.dataset.originalText;
    }
  }

  function setView(view) {
    const safeView = VIEW_COPY[view] ? view : "assessment";
    state.currentView = safeView;
    queryAll(".view").forEach((element) => element.classList.toggle("is-active", element.dataset.view === safeView));
    queryAll("[data-view-target]").forEach((button) => button.classList.toggle("is-active", button.dataset.viewTarget === safeView));
    ui.pageEyebrow.textContent = VIEW_COPY[safeView][0];
    ui.pageTitle.textContent = VIEW_COPY[safeView][1];
    history.replaceState(null, "", `#${safeView}`);
    if (safeView === "history") loadSessions(true);
    if (safeView === "active" && state.activeSessionId) loadSession(state.activeSessionId, true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function loadSystem(refresh = false) {
    try {
      const result = refresh
        ? await api("/api/system/refresh", { method: "POST", body: {} })
        : await api("/api/system");
      state.system = result.system || result;
      if (result.profiles) state.profiles = result.profiles;
      if (refresh) {
        const profileResult = await api("/api/system");
        if (profileResult.profiles) state.profiles = profileResult.profiles;
      }
      renderPreflight();
      renderProfiles();
      renderInterfaces();
      updateLaunchState();
      return state.system;
    } catch (error) {
      renderPreflight(error);
      throw error;
    }
  }

  async function loadInterfaces() {
    try {
      const result = await api("/api/interfaces");
      const interfaces = Array.isArray(result) ? result : result.interfaces;
      state.interfaces = Array.isArray(interfaces) ? interfaces : [];
      for (const [id, source] of state.selectedSources) {
        const current = state.interfaces.find((item) => item.id === id);
        if (current) source.interface = current;
      }
      renderInterfaces();
      return state.interfaces;
    } catch (error) {
      ui.interfaceGrid.innerHTML = `<div class="empty-inline"><strong>Interface inventory unavailable</strong><p>${escapeHtml(error.message)}</p></div>`;
      throw error;
    }
  }

  async function refreshEnvironment(button) {
    setButtonBusy(button, true, "Checking…");
    hideBanner();
    const results = await Promise.allSettled([loadSystem(true), loadInterfaces()]);
    const failures = results.filter((result) => result.status === "rejected");
    if (failures.length) {
      showBanner("Preflight could not complete", failures.map((item) => item.reason?.message || "Unknown error").join(" · "));
      toast("Preflight failed", "Review the local service and tool installation.", "error");
    } else {
      toast("Preflight refreshed", `${state.interfaces.length} interfaces detected.`);
    }
    setButtonBusy(button, false);
  }

  function renderPreflight(error = null) {
    if (error || !state.system) {
      ui.systemSummary.textContent = error ? error.message : "System inventory is unavailable.";
      ui.preflightGrid.innerHTML = `<div class="empty-inline"><strong>Unable to inspect local tools</strong><p>Confirm the NetScope service is running on localhost.</p></div>`;
      ui.readinessScore.textContent = "0%";
      ui.readinessOrbit.style.setProperty("--score", "0deg");
      return;
    }

    const system = state.system;
    const tools = system.tools || {};
    const captureReady = Boolean(system.capture_available ?? (tools.dumpcap?.available || tools.tshark?.available));
    const analysisReady = Boolean(system.analysis_available ?? tools.tshark?.available);
    const scanReady = Boolean(system.scan_available ?? tools.nmap?.available);
    const capabilityScore = [captureReady, analysisReady, scanReady].filter(Boolean).length;
    const percentage = Math.round(capabilityScore / 3 * 100);
    ui.readinessScore.textContent = `${percentage}%`;
    ui.readinessOrbit.style.setProperty("--score", `${percentage * 3.6}deg`);
    ui.systemSummary.textContent = `${system.hostname || "Local host"} · ${system.platform || "Platform unavailable"} · Python ${system.python || "—"}`;

    const cards = [
      { key: "dumpcap", initials: "DC", label: "Capture engine", ready: captureReady, detail: tools.dumpcap || tools.tshark, missing: "Install Wireshark / Npcap" },
      { key: "tshark", initials: "TS", label: "Packet analysis", ready: analysisReady, detail: tools.tshark, missing: "TShark is required" },
      { key: "nmap", initials: "NM", label: "Active enumeration", ready: scanReady, detail: tools.nmap, missing: "Optional: install Nmap" },
    ];

    ui.preflightGrid.innerHTML = cards.map((card) => {
      const version = card.detail?.version || card.detail?.path || card.missing;
      return `<div class="tool-card">
        <span class="tool-card__icon">${card.initials}</span>
        <div><strong>${escapeHtml(card.label)}</strong><small title="${escapeHtml(version)}">${escapeHtml(version)}</small></div>
        <span class="tool-state ${card.ready ? "tool-state--ok" : "tool-state--bad"}"><i class="status-dot ${card.ready ? "status-dot--ok" : "status-dot--bad"}"></i>${card.ready ? "Ready" : "Missing"}</span>
      </div>`;
    }).join("");
  }

  function renderProfiles() {
    const entries = Object.entries(state.profiles || FALLBACK_PROFILES);
    ui.profileGrid.innerHTML = entries.map(([id, profile]) => {
      const checked = state.selectedProfiles.has(id);
      const impact = String(profile.impact || "low").toLowerCase();
      return `<label class="profile-card ${checked ? "is-selected" : ""}" data-profile-card="${escapeHtml(id)}">
        <input type="checkbox" value="${escapeHtml(id)}" data-profile-input ${checked ? "checked" : ""}>
        <span><strong>${escapeHtml(profile.label || id)}</strong><small>${escapeHtml(profile.description || "")}</small></span>
        <em class="impact-tag impact-tag--${escapeHtml(impact)}">${escapeHtml(impact)}</em>
      </label>`;
    }).join("");
  }

  function defaultSource(iface) {
    return {
      interface: iface,
      alias: iface.name || iface.capture_description || "Network source",
      role: "",
      switchPort: "",
      vlanIds: iface.vlan_id === null || iface.vlan_id === undefined ? "" : String(iface.vlan_id),
      targets: sourceRecommendedTargets(iface).join(", "),
      bindInterface: Boolean(iface.scan_ready),
      expectedPorts: "",
    };
  }

  function interfaceReadyForCurrentMode(iface) {
    if (byId("captureEnabled").checked) return Boolean(iface.capture_ready);
    if (byId("scanEnabled").checked) return Boolean(iface.scan_ready);
    return Boolean(iface.capture_ready || iface.scan_ready);
  }

  function readyInterfacesForCurrentMode() {
    return state.interfaces.filter(interfaceReadyForCurrentMode);
  }

  function currentReadyLabel() {
    if (byId("captureEnabled").checked) return "capture-ready";
    if (byId("scanEnabled").checked) return "scan-ready";
    return "usable";
  }

  function renderInterfaceReadinessNotice() {
    if (!ui.interfaceReadinessNotice) return;
    const captureEnabled = byId("captureEnabled").checked;
    const scanEnabled = byId("scanEnabled").checked;
    const captureReadyCount = state.interfaces.filter((iface) => iface.capture_ready).length;
    const scanReadyCount = state.interfaces.filter((iface) => iface.scan_ready).length;
    const captureToolsReady = Boolean(state.system?.capture_available && state.system?.analysis_available);
    const scanToolReady = Boolean(state.system?.scan_available || state.system?.tools?.nmap?.available);
    let title = "";
    let message = "";
    let action = "";

    if (captureEnabled && state.system && !captureToolsReady) {
      title = "Packet capture setup is incomplete";
      message = "Windows detected the adapters, but TShark/Dumpcap cannot expose them yet. Install Wireshark with TShark, Dumpcap, and Npcap, restart NetScope, then run preflight.";
      if (scanToolReady) {
        action = '<button class="button button--quiet" type="button" data-switch-scan-only>Switch to Nmap-only</button>';
      }
    } else if (captureEnabled && state.interfaces.length && captureReadyCount === 0) {
      title = "No capture-ready interfaces";
      message = "No adapter is currently exposed by TShark/Dumpcap. Check Wireshark/Npcap installation and Vector or extcap visibility, then run preflight.";
    } else if (captureEnabled && captureReadyCount < state.interfaces.length) {
      title = captureReadyCount + " capture-ready adapter" + (captureReadyCount === 1 ? "" : "s");
      message = "Dimmed cards are visible to Windows but not to the active capture engine. They cannot create packet evidence in capture mode.";
    } else if (!captureEnabled && scanEnabled) {
      title = "Nmap-only mode";
      message = scanReadyCount
        ? scanReadyCount + " adapter" + (scanReadyCount === 1 ? " is" : "s are") + " route-ready. Other adapters remain manually selectable for an explicitly unbound OS-routed scan."
        : "No adapter has a currently active routable address. Review link state, addressing, and targets before scanning.";
    } else if (!captureEnabled && !scanEnabled) {
      title = "No collection mode enabled";
      message = "Enable packet capture after Wireshark preflight, or enable authorized Nmap enumeration.";
    }

    ui.interfaceReadinessNotice.classList.toggle("is-hidden", !title);
    ui.interfaceReadinessNotice.innerHTML = title
      ? '<span aria-hidden="true">!</span><div><strong>' + title + '</strong><p>' + message + '</p></div>' + action
      : "";
  }

  function interfaceMatchesFilter(iface) {
    if (state.interfaceFilter === "ready" && !interfaceReadyForCurrentMode(iface)) return false;
    if (state.interfaceFilter === "up" && !["up", "connected", "unknown"].includes(String(iface.status || "").toLowerCase())) return false;
    const needle = ui.interfaceSearch.value.trim().toLowerCase();
    if (!needle) return true;
    const searchable = [
      iface.name,
      iface.description,
      iface.capture_description,
      iface.kind,
      iface.vlan_id,
      ...(iface.networks || []),
      ...(iface.addresses || []).map((address) => address.address),
    ].join(" ").toLowerCase();
    return searchable.includes(needle);
  }

  function renderInterfaces() {
    const captureEnabled = byId("captureEnabled").checked;
    const visible = state.interfaces.filter(interfaceMatchesFilter);
    if (!visible.length) {
      ui.interfaceGrid.innerHTML = `<div class="empty-inline"><strong>No interfaces match this view</strong><p>Refresh preflight or change the interface filter.</p></div>`;
    } else {
      ui.interfaceGrid.innerHTML = visible.map((iface) => {
        const selected = state.selectedSources.has(iface.id);
        const unavailable = captureEnabled && !iface.capture_ready;
        const blockedReasonLabel = state.system && (!state.system.capture_available || !state.system.analysis_available)
          ? "Install TShark/Dumpcap"
          : "Not capture-exposed";
        const addresses = (iface.addresses || []).slice(0, 3).map((item) => `${item.address || ""}${item.prefix_length !== undefined ? `/${item.prefix_length}` : ""}`);
        const networks = iface.networks || [];
        const description = iface.description || iface.capture_description || iface.capture_id || "No adapter description";
        const status = iface.status || "Unknown";
        return `<label class="interface-card ${selected ? "is-selected" : ""} ${unavailable ? "is-unavailable" : ""}" data-interface-card="${escapeHtml(iface.id)}" title="${unavailable ? "Capture is enabled and this adapter is not exposed to TShark/Dumpcap" : ""}">
          <input class="interface-checkbox" type="checkbox" data-interface-id="${escapeHtml(iface.id)}" ${selected ? "checked" : ""} ${unavailable ? "disabled" : ""}>
          <span class="interface-check" aria-hidden="true"></span>
          <div>
            <div class="interface-card__head"><strong>${escapeHtml(iface.name || iface.capture_description || iface.id)}</strong>${iface.virtual ? '<span class="tag">Virtual</span>' : ""}</div>
            <p class="interface-card__description" title="${escapeHtml(description)}">${escapeHtml(description)}</p>
            <div class="interface-meta">
              <span>${escapeHtml(iface.kind || "Interface")}</span>
              ${iface.link_speed ? `<span>${escapeHtml(iface.link_speed)}</span>` : ""}
              ${iface.vlan_id !== null && iface.vlan_id !== undefined ? `<span>VLAN ${escapeHtml(iface.vlan_id)}</span>` : ""}
              ${(addresses.length ? addresses : networks).map((value) => `<span title="${escapeHtml(value)}">${escapeHtml(value)}</span>`).join("")}
              ${unavailable ? `<span class="interface-blocked-reason">${escapeHtml(blockedReasonLabel)}</span>` : ""}
            </div>
          </div>
          <div class="interface-card__side">
            <div class="readiness-icons"><span class="${iface.capture_ready ? "is-ready" : ""}" title="${iface.capture_ready ? "Capture-ready" : "Not capture-ready"}">CAP</span><span class="${iface.scan_ready ? "is-ready" : ""}" title="${iface.scan_ready ? "Routable for scans" : "No routable network"}">IP</span></div>
            <span class="interface-status"><i class="status-dot ${String(status).toLowerCase() === "up" ? "status-dot--ok" : ""}"></i>${escapeHtml(status)}</span>
          </div>
        </label>`;
      }).join("");
    }
    renderInterfaceReadinessNotice();
    renderSelectedSources();
    updateReadyButton();
  }

  function updateReadyButton() {
    const ready = readyInterfacesForCurrentMode();
    const allSelected = ready.length > 0 && ready.every((iface) => state.selectedSources.has(iface.id));
    const label = currentReadyLabel();
    const readyButton = byId("selectReadyButton");
    readyButton.textContent = (allSelected ? "Clear " : "Select ") + label;
    readyButton.disabled = ready.length === 0;
    const filterButton = document.querySelector('[data-interface-filter="ready"]');
    if (filterButton) filterButton.textContent = label.charAt(0).toUpperCase() + label.slice(1);
  }

  function renderSelectedSources() {
    const sources = Array.from(state.selectedSources.entries());
    ui.selectedCount.textContent = String(sources.length);
    ui.sourceConfigSection.classList.toggle("is-hidden", sources.length === 0);
    ui.sourceList.innerHTML = sources.map(([id, source], index) => {
      const iface = source.interface;
      const networks = iface.networks || [];
      return `<article class="source-editor" data-source-editor="${escapeHtml(id)}">
        <div class="source-editor__head">
          <span class="source-editor__index">${String(index + 1).padStart(2, "0")}</span>
          <div class="source-editor__title"><strong data-source-title>${escapeHtml(source.alias || iface.name || id)}</strong><small>${escapeHtml(iface.kind || "Interface")} · ${escapeHtml(networks.join(", ") || "No routed subnet detected")}</small></div>
          ${source.vlanIds ? `<span class="tag">VLAN ${escapeHtml(source.vlanIds)}</span>` : ""}
          <button class="source-editor__remove" type="button" data-remove-source="${escapeHtml(id)}" title="Remove source" aria-label="Remove ${escapeHtml(source.alias || iface.name || id)}">×</button>
        </div>
        <details ${sources.length === 1 ? "open" : ""}>
          <summary>Configure source metadata, baseline &amp; targets</summary>
          <div class="source-editor__body">
            <div class="form-grid form-grid--three">
              <label class="field"><span>Source alias</span><input maxlength="120" data-source-field="alias" value="${escapeHtml(source.alias)}"></label>
              <label class="field"><span>Role / vantage point</span><input maxlength="240" data-source-field="role" value="${escapeHtml(source.role)}" placeholder="ECU subnet, mirror trunk…"></label>
              <label class="field"><span>Switch / mirror port</span><input maxlength="120" data-source-field="switchPort" value="${escapeHtml(source.switchPort)}" placeholder="Port 7 / SPAN 2"></label>
              <label class="field"><span>Expected VLAN IDs</span><input data-source-field="vlanIds" value="${escapeHtml(source.vlanIds)}" placeholder="10, 20, 120"></label>
              <label class="field"><span>Expected open ports</span><input data-source-field="expectedPorts" value="${escapeHtml(source.expectedPorts)}" placeholder="22, 443, 13400"><small>Open ports outside this baseline become policy-deviation findings.</small></label>
              <label class="check-row"><input type="checkbox" data-source-field="bindInterface" ${source.bindInterface ? "checked" : ""}><span><strong>Bind Nmap to this adapter</strong><small>${iface.scan_ready ? "Routable address detected." : "No routable address detected; leave off unless routing is verified."}</small></span></label>
              <label class="field field--full"><span>Authorized scan targets</span><input data-source-field="targets" value="${escapeHtml(source.targets)}" placeholder="Literal IPs/CIDRs only"><small>${sourceRecommendedTargets(iface).length ? "Pre-filled only from backend-recommended private/ULA networks; review before scanning." : "No safe target was inferred. Public/global networks are never pre-filled."}</small></label>
            </div>
          </div>
        </details>
      </article>`;
    }).join("");
    updateLaunchState();
  }

  function updateSourceFromControl(control) {
    const editor = control.closest("[data-source-editor]");
    if (!editor) return;
    const source = state.selectedSources.get(editor.dataset.sourceEditor);
    if (!source) return;
    const field = control.dataset.sourceField;
    source[field] = control.type === "checkbox" ? control.checked : control.value;
    if (field === "alias") {
      const title = editor.querySelector("[data-source-title]");
      if (title) title.textContent = control.value || source.interface.name || editor.dataset.sourceEditor;
    }
    updateLaunchState();
  }

  function setScanUi() {
    const enabled = byId("scanEnabled").checked;
    ui.scanSettings.classList.toggle("is-disabled", !enabled);
    queryAll("#scanSettingsBody input, #scanSettingsBody select").forEach((control) => { control.disabled = !enabled; });
    renderInterfaces();
    updateLaunchState();
  }

  function applyAutomotiveDefaults() {
    const automotive = byId("automotiveMode").checked;
    if (automotive) {
      byId("maxRate").value = "50";
      byId("nmapTiming").value = "2";
      if (state.selectedProfiles.size === 0 || (state.selectedProfiles.size === 1 && state.selectedProfiles.has("host_discovery"))) {
        state.selectedProfiles = new Set(["automotive_discovery"]);
      }
    } else {
      byId("maxRate").value = "500";
      byId("nmapTiming").value = "3";
      if (state.selectedProfiles.size === 1 && state.selectedProfiles.has("automotive_discovery")) {
        state.selectedProfiles = new Set(["host_discovery"]);
      }
    }
    renderProfiles();
    updateLaunchState();
  }

  function buildConfig() {
    const sources = Array.from(state.selectedSources.entries()).map(([interfaceId, source]) => ({
      interface_id: interfaceId,
      alias: source.alias,
      role: source.role,
      switch_port: source.switchPort,
      vlan_ids: splitTokens(source.vlanIds),
      targets: splitTokens(source.targets),
      bind_interface: Boolean(source.bindInterface),
      expected_ports: splitTokens(source.expectedPorts),
    }));

    return {
      name: byId("sessionName").value.trim() || "Network assessment",
      operator: byId("operator").value.trim(),
      authorization_note: byId("authorizationNote").value.trim(),
      topology_notes: byId("topologyNotes").value.trim(),
      automotive_mode: byId("automotiveMode").checked,
      capture: {
        enabled: byId("captureEnabled").checked,
        duration_seconds: toInteger("durationSeconds", 300),
        max_file_mb: toInteger("maxFileMb", 512),
        packet_limit: toInteger("packetLimit", 0),
        snaplen: toInteger("snaplen", 0),
        promiscuous: byId("promiscuous").checked,
        bpf_filter: byId("bpfFilter").value.trim(),
      },
      scan: {
        enabled: byId("scanEnabled").checked,
        authorized: byId("scanAuthorized").checked,
        profiles: Array.from(state.selectedProfiles),
        allow_public: byId("allowPublic").checked,
        allow_large: byId("allowLarge").checked,
        allow_high_impact: byId("allowHighImpact").checked,
        allow_intrusive: byId("allowIntrusive").checked,
        include_port_zero: byId("includePortZero").checked,
        max_rate: toInteger("maxRate", 50),
        max_retries: toInteger("maxRetries", 1),
        timing: toInteger("nmapTiming", 2),
        host_timeout_seconds: toInteger("hostTimeout", 900),
        script_timeout_seconds: toInteger("scriptTimeout", 120),
        exclusions: splitTokens(byId("scanExclusions").value),
      },
      sources,
    };
  }

  function configurationIssues(config = buildConfig()) {
    const issues = [];
    if (!config.sources.length) issues.push("Select at least one source.");
    if (!config.capture.enabled && !config.scan.enabled) issues.push("Enable packet capture or active scanning.");
    if (config.capture.enabled) {
      const unavailable = config.sources.find((source) => !state.selectedSources.get(source.interface_id)?.interface?.capture_ready);
      if (unavailable) issues.push("Every selected source must be capture-ready while packet capture is enabled.");
      if (!config.capture.duration_seconds && !config.capture.max_file_mb && !config.capture.packet_limit) issues.push("Set a capture duration, file ceiling, or packet limit.");
      if (!state.system?.capture_available && !state.system?.tools?.tshark?.available) issues.push("A Wireshark capture engine is not available.");
      if (!state.system?.analysis_available && !state.system?.tools?.tshark?.available) issues.push("TShark is required for analysis.");
    }
    if (config.scan.enabled) {
      if (!state.system?.scan_available && !state.system?.tools?.nmap?.available) issues.push("Nmap is not available.");
      if (!config.scan.authorized) issues.push("Acknowledge authorization for active scanning.");
      if (!config.scan.profiles.length) issues.push("Select at least one Nmap profile.");
      if (config.sources.some((source) => !source.targets.length)) issues.push("Every scan source needs at least one literal IP or CIDR target.");
      if (config.scan.profiles.some((profile) => HIGH_IMPACT_PROFILES.has(profile)) && !config.scan.allow_high_impact) issues.push("Selected profiles require the high-impact opt-in.");
      if (config.scan.profiles.some((profile) => INTRUSIVE_PROFILES.has(profile)) && !config.scan.allow_intrusive) issues.push("Vulnerability checks require the separate intrusive-check opt-in.");
    }
    return issues;
  }

  function updateLaunchState() {
    const config = buildConfig();
    const issues = configurationIssues(config);
    const sourceCount = config.sources.length;
    const modes = [config.capture.enabled ? "parallel capture" : "", config.scan.enabled ? `${config.scan.profiles.length} scan profile${config.scan.profiles.length === 1 ? "" : "s"}` : ""].filter(Boolean);
    if (issues.length) {
      ui.launchSummary.textContent = issues[0];
      ui.launchDetail.textContent = sourceCount ? `${sourceCount} source${sourceCount === 1 ? "" : "s"} selected · complete the required controls above.` : "The configuration is validated again by the local service before any process starts.";
    } else {
      ui.launchSummary.textContent = `${sourceCount} source${sourceCount === 1 ? "" : "s"} ready for ${modes.join(" + ")}`;
      ui.launchDetail.textContent = config.automotive_mode ? "Automotive mode: conservative rate and single scan worker." : "Standard network mode: scoped capture and enumeration.";
    }
    ui.reviewLaunchButton.disabled = issues.length > 0;
  }

  function openReview() {
    const config = buildConfig();
    const issues = configurationIssues(config);
    if (issues.length) {
      toast("Configuration incomplete", issues[0], "error");
      return;
    }

    const targetCount = config.sources.reduce((total, source) => total + source.targets.length, 0);
    const profiles = config.scan.profiles.map((id) => state.profiles[id]?.label || id);
    ui.reviewSummary.innerHTML = [
      ["Session", config.name, `${config.automotive_mode ? "Automotive" : "Standard"} mode · ${config.operator || "Operator not recorded"}`],
      ["Sources", `${config.sources.length} selected`, config.sources.map((source) => source.alias).join(" · ")],
      ["Capture", config.capture.enabled ? `${config.capture.duration_seconds ? formatDuration(config.capture.duration_seconds) : "Guardrail-based"} capture` : "Disabled", config.capture.enabled ? `${config.capture.max_file_mb ? `${config.capture.max_file_mb} MB/source ceiling` : "No file-size ceiling"}${config.capture.bpf_filter ? ` · filter: ${config.capture.bpf_filter}` : " · no BPF filter"}` : "No live packets will be collected"],
      ["Enumeration", config.scan.enabled ? `${profiles.length} profile${profiles.length === 1 ? "" : "s"} across ${targetCount} target expression${targetCount === 1 ? "" : "s"}` : "Disabled", config.scan.enabled ? profiles.join(" · ") : "Passive analysis only"],
      ["Evidence", "Separate source artifacts + combined report", "PCAPNG, Nmap output, HTML/JSON reports, CSV tables, and SHA-256 manifest when available"],
    ].map(([label, value, detail]) => `<div class="review-row"><span>${escapeHtml(label)}</span><div><strong>${escapeHtml(value)}</strong><small>${escapeHtml(detail)}</small></div></div>`).join("");

    const cautions = [];
    if (config.scan.enabled) cautions.push("Active packets will be sent to the reviewed target scope.");
    if (config.scan.allow_public) cautions.push("Non-local scope is enabled.");
    if (config.scan.allow_large) cautions.push("Large scope is enabled.");
    if (config.scan.allow_intrusive) cautions.push("Curated vulnerability checks are enabled.");
    if (config.capture.promiscuous) cautions.push("Promiscuous mode does not provide switched traffic without correct TAP/SPAN topology.");
    ui.reviewWarning.classList.toggle("is-hidden", cautions.length === 0);
    const warningText = ui.reviewWarning.querySelector("p");
    if (warningText) warningText.textContent = cautions.join(" ");
    ui.reviewDialog.showModal();
  }

  async function launchAssessment() {
    const config = buildConfig();
    const issues = configurationIssues(config);
    if (issues.length) {
      ui.reviewDialog.close();
      toast("Configuration incomplete", issues[0], "error");
      return;
    }
    setButtonBusy(ui.confirmLaunchButton, true, "Starting…");
    try {
      const result = await api("/api/sessions", { method: "POST", body: config });
      const session = result.session || result;
      state.activeSession = session;
      state.activeSessionId = session.id;
      localStorage.setItem("netscope.activeSessionId", session.id);
      ui.reviewDialog.close();
      renderSession(session);
      await loadSessions(true);
      setView("active");
      schedulePolling();
      toast("Assessment started", `${config.sources.length} source${config.sources.length === 1 ? "" : "s"} queued.`);
    } catch (error) {
      toast("Assessment did not start", error.message, "error");
    } finally {
      setButtonBusy(ui.confirmLaunchButton, false);
    }
  }

  async function loadSessions(silent = false) {
    try {
      const result = await api("/api/sessions");
      state.sessions = Array.isArray(result) ? result : (result.sessions || []);
      renderHistory();
      updateNavigationState();
      return state.sessions;
    } catch (error) {
      ui.historyList.innerHTML = `<div class="empty-inline"><strong>Session history unavailable</strong><p>${escapeHtml(error.message)}</p></div>`;
      if (!silent) toast("Could not load session history", error.message, "error");
      return [];
    }
  }

  function updateNavigationState() {
    const active = state.sessions.filter((session) => ACTIVE_STATES.has(session.status));
    ui.navActiveCount.classList.toggle("is-hidden", active.length === 0);
    ui.navActiveCount.textContent = String(active.length);
    ui.navActiveStatus.textContent = active.length ? `${active.length} running` : (state.activeSession ? statusLabel(state.activeSession.status) : "Nothing running");
    ui.navHistoryCount.textContent = `${state.sessions.length} session${state.sessions.length === 1 ? "" : "s"}`;
  }

  function renderHistory() {
    if (!state.sessions.length) {
      ui.historyList.innerHTML = `<div class="empty-inline"><strong>No saved sessions yet</strong><p>Completed and interrupted evidence sessions appear here.</p></div>`;
      return;
    }
    ui.historyList.innerHTML = state.sessions.map((session) => {
      const summary = session.summary || {};
      const severity = summary.findings_by_severity || {};
      const materialFindings = Number(severity.critical || 0) + Number(severity.high || 0) + Number(severity.medium || 0);
      return `<article class="history-row">
        <div class="history-main"><strong>${escapeHtml(session.name || "Untitled session")}</strong><small>${escapeHtml(session.id)} · ${escapeHtml(formatDate(session.created_at))}</small></div>
        <span class="status-badge ${statusClass(session.status)}">${escapeHtml(statusLabel(session.status))}</span>
        <div class="history-stat"><span>Sources</span><strong>${formatNumber(session.source_count)}</strong></div>
        <div class="history-stat"><span>Assets</span><strong>${formatNumber(summary.assets)}</strong></div>
        <div class="history-stat"><span>Open services</span><strong>${formatNumber(summary.open_services)}</strong></div>
        <div class="history-stat"><span>Review findings</span><strong>${formatNumber(materialFindings)}</strong></div>
        <button class="button button--quiet" type="button" data-open-session="${escapeHtml(session.id)}">Open</button>
      </article>`;
    }).join("");
  }

  async function loadSession(sessionId, silent = false) {
    if (!sessionId) return null;
    try {
      const result = await api(`/api/sessions/${encodeURIComponent(sessionId)}`);
      const session = result.session || result;
      state.activeSession = session;
      state.activeSessionId = session.id;
      localStorage.setItem("netscope.activeSessionId", session.id);
      renderSession(session);
      schedulePolling();
      return session;
    } catch (error) {
      if (!silent) toast("Could not load session", error.message, "error");
      if (error.message.toLowerCase().includes("unknown")) {
        localStorage.removeItem("netscope.activeSessionId");
        state.activeSessionId = null;
      }
      return null;
    }
  }

  function schedulePolling() {
    window.clearTimeout(state.pollTimer);
    if (!state.activeSessionId || !state.activeSession || !ACTIVE_STATES.has(state.activeSession.status)) return;
    state.pollTimer = window.setTimeout(async () => {
      if (!document.hidden) await loadSession(state.activeSessionId, true);
      else schedulePolling();
    }, 1500);
  }

  function renderSession(session) {
    if (!session) {
      ui.activeEmptyState.classList.remove("is-hidden");
      ui.sessionDetail.classList.add("is-hidden");
      return;
    }
    ui.activeEmptyState.classList.add("is-hidden");
    ui.sessionDetail.classList.remove("is-hidden");

    ui.activeSessionName.textContent = session.name || "Untitled session";
    ui.activeSessionId.textContent = session.id || "—";
    ui.activeSessionTime.textContent = `${formatDate(session.started_at || session.created_at)} · ${elapsedTime(session)}`;
    ui.sessionStatusBadge.className = `status-badge ${statusClass(session.status)}`;
    ui.sessionStatusBadge.textContent = statusLabel(session.status);
    ui.sessionModeBadge.textContent = session.mode === "import" ? "Offline import" : (session.config?.automotive_mode ? "Automotive" : "Standard network");

    const active = ACTIVE_STATES.has(session.status);
    const captureActive = active && (session.captures || []).some((capture) => ["queued", "running"].includes(capture.status));
    const scanActive = active && (session.scans || []).some((scan) => ["queued", "running"].includes(scan.status));
    ui.stopCaptureButton.disabled = !captureActive;
    ui.cancelScansButton.disabled = !scanActive;
    ui.liveIndicator.classList.toggle("is-idle", !active);
    ui.liveIndicator.innerHTML = `<i></i>${active ? "Live" : "Final"}`;

    const summary = session.summary || {};
    const captureBytes = (session.captures || []).reduce((total, capture) => total + Number(capture.size_bytes || 0), 0);
    const severity = summary.findings_by_severity || {};
    const reviewFindings = Number(severity.critical || 0) + Number(severity.high || 0) + Number(severity.medium || 0);
    const metrics = [
      ["Sources", session.config?.sources?.length || session.captures?.length || 0, session.mode === "import" ? "imported capture" : "selected vantage points"],
      ["Capture size", formatBytes(captureBytes || summary.bytes), formatNumber(summary.packets || 0) + " analyzed packets"],
      ["Assets", formatNumber(summary.assets || session.assets?.length || 0), "unique addresses"],
      ["Open services", formatNumber(summary.open_services || (session.services || []).filter((item) => item.state === "open").length), "Nmap observations"],
      ["Findings", formatNumber(summary.findings || session.findings?.length || 0), `${reviewFindings} medium or above`, reviewFindings ? "alert" : ""],
      ["Artifacts", formatNumber(Object.keys(session.artifacts || {}).length), "reports & evidence"],
    ];
    ui.sessionMetrics.innerHTML = metrics.map(([label, value, detail, style]) => `<div class="metric-card ${style === "alert" ? "metric-card--alert" : ""}"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong><small>${escapeHtml(detail)}</small></div>`).join("");

    renderSourceProgress(session);
    renderFindings(session);
    renderServices(session);
    renderArtifacts(session);
    renderMessages(session);
    updateNavigationState();
    if (!active) {
      window.clearTimeout(state.pollTimer);
      loadSessions(true);
    }
  }

  function renderSourceProgress(session) {
    const sources = session.config?.sources || [];
    if (!sources.length) {
      ui.sourceProgressGrid.innerHTML = `<div class="empty-inline"><strong>No source progress recorded</strong></div>`;
      return;
    }
    ui.sourceProgressGrid.innerHTML = sources.map((source) => {
      const capture = (session.captures || []).find((item) => item.source_id === source.source_id);
      const scans = (session.scans || []).filter((item) => item.source_id === source.source_id);
      const completedScans = scans.filter((item) => item.status === "completed").length;
      const failedScans = scans.filter((item) => ["failed", "cancelled"].includes(item.status)).length;
      const currentScan = scans.find((item) => item.status === "running");
      const strips = scans.length
        ? scans.map((scan) => `<span class="is-${escapeHtml(scan.status || "queued")}" title="${escapeHtml(scan.profile_label || scan.profile)}: ${escapeHtml(statusLabel(scan.status))}"></span>`).join("")
        : '<span title="No scans configured"></span>';
      const interfaceName = source.interface?.name || source.interface?.capture_description || source.interface_id;
      return `<article class="progress-card">
        <div class="progress-card__head"><div><strong>${escapeHtml(source.alias || interfaceName)}</strong><small>${escapeHtml(interfaceName)}${source.vlan_ids?.length ? ` · VLAN ${escapeHtml(source.vlan_ids.join(", "))}` : ""}</small></div><span class="status-badge ${statusClass(capture?.status)}">${escapeHtml(capture ? statusLabel(capture.status) : "Scan only")}</span></div>
        <div class="progress-card__stats">
          <div class="progress-stat"><span>Capture</span><strong>${escapeHtml(formatBytes(capture?.size_bytes || 0))}</strong></div>
          <div class="progress-stat"><span>Scans</span><strong>${completedScans}/${scans.length}</strong></div>
          <div class="progress-stat"><span>Current</span><strong>${escapeHtml(currentScan?.profile_label || (failedScans ? `${failedScans} failed` : scans.length ? "Waiting" : "Passive"))}</strong></div>
        </div>
        <div class="job-strip">${strips}</div>
      </article>`;
    }).join("");
  }

  function sourceNameMap(session) {
    return new Map((session.config?.sources || []).map((source) => [source.source_id, source.alias || source.interface?.name || source.source_id]));
  }

  function renderFindings(session) {
    const findings = session.findings || [];
    const sourceNames = sourceNameMap(session);
    ui.findingsCount.textContent = String(findings.length);
    if (!findings.length) {
      ui.findingsTableBody.innerHTML = `<tr><td class="table-empty" colspan="4">${ACTIVE_STATES.has(session.status) ? "Findings appear after packet and scan analysis." : "No automated findings were generated."}</td></tr>`;
      return;
    }
    ui.findingsTableBody.innerHTML = findings.slice(0, 30).map((finding) => {
      const sources = (finding.source_ids || []).map((id) => sourceNames.get(id) || id).join(", ") || "Combined";
      return `<tr>
        <td><span class="severity severity--${escapeHtml(finding.severity || "info")}">${escapeHtml(finding.severity || "info")}</span></td>
        <td title="${escapeHtml(finding.description || "")}"><strong>${escapeHtml(finding.title || "Untitled finding")}</strong><small>${escapeHtml(finding.category || "observation")} · ${escapeHtml(finding.status || "needs review")}</small></td>
        <td>${escapeHtml(sources)}</td>
        <td>${escapeHtml(finding.confidence || "—")}</td>
      </tr>`;
    }).join("");
  }

  function renderServices(session) {
    const services = (session.services || []).filter((service) => service.state === "open");
    ui.servicesCount.textContent = String(services.length);
    if (!services.length) {
      ui.servicesTableBody.innerHTML = `<tr><td class="table-empty" colspan="4">${ACTIVE_STATES.has(session.status) ? "Services appear when Nmap results are analyzed." : "No open services were recorded."}</td></tr>`;
      return;
    }
    ui.servicesTableBody.innerHTML = services.slice(0, 40).map((service) => {
      const product = [service.product, service.version, service.extra_info].filter(Boolean).join(" ") || "Not identified";
      return `<tr>
        <td><strong>${escapeHtml(service.address || "—")}</strong><small>${escapeHtml(service.source_id || "")}</small></td>
        <td><strong>${escapeHtml(service.port)}</strong><small>${escapeHtml(String(service.protocol || "tcp").toUpperCase())}</small></td>
        <td>${escapeHtml(service.service || "unknown")}</td>
        <td title="${escapeHtml(product)}">${escapeHtml(product)}</td>
      </tr>`;
    }).join("");
  }

  function artifactPresentation(key, value) {
    const lower = `${key} ${value}`.toLowerCase();
    if (lower.includes("html")) return ["HTML", "Interactive report"];
    if (lower.includes("json")) return ["JSON", "Structured data"];
    if (lower.includes("csv")) return ["CSV", "Analyst table"];
    if (lower.includes("manifest") || lower.includes("sha")) return ["HASH", "Integrity manifest"];
    if (lower.includes("pcap") || lower.includes("capture")) return ["PCAP", "Packet evidence"];
    if (lower.includes("nmap") && lower.includes("xml")) return ["XML", "Nmap XML"];
    if (lower.includes("nmap")) return ["TXT", "Nmap output"];
    return ["FILE", "Session artifact"];
  }

  function renderArtifacts(session) {
    const artifacts = Object.entries(session.artifacts || {});
    if (!artifacts.length) {
      ui.artifactGrid.innerHTML = `<div class="empty-inline"><strong>${ACTIVE_STATES.has(session.status) ? "Artifacts are being prepared" : "No artifacts are available"}</strong><p>Capture evidence appears first; reports are added after analysis.</p></div>`;
      return;
    }
    ui.artifactGrid.innerHTML = artifacts.map(([key, value]) => {
      const [type, detail] = artifactPresentation(key, value);
      const filename = String(value || "").split(/[\\/]/).pop() || key;
      const href = `/api/sessions/${encodeURIComponent(session.id)}/artifact/${encodeURIComponent(key)}`;
      return `<a class="artifact-card" href="${href}" target="_blank" rel="noopener">
        <span class="artifact-card__icon">${escapeHtml(type)}</span>
        <span><strong title="${escapeHtml(filename)}">${escapeHtml(filename)}</strong><small>${escapeHtml(detail)} · ${escapeHtml(key)}</small></span>
        <span aria-hidden="true">↗</span>
      </a>`;
    }).join("");
  }

  function renderMessages(session) {
    const messages = [
      ...(session.warnings || []).map((message) => ({ type: "warning", message })),
      ...(session.errors || []).map((message) => ({ type: "error", message })),
      ...(session.captures || []).filter((item) => item.error).map((item) => ({ type: "error", message: `${item.source_alias || item.id}: ${item.error}` })),
      ...(session.scans || []).filter((item) => item.error).map((item) => ({ type: "error", message: `${item.profile_label || item.profile}: ${item.error}` })),
    ];
    ui.messageLogPanel.classList.toggle("is-hidden", messages.length === 0);
    ui.messageLog.innerHTML = messages.map((item) => `<li class="${item.type === "error" ? "is-error" : ""}"><span>${item.type === "error" ? "×" : "!"}</span><span>${escapeHtml(item.message)}</span></li>`).join("");
  }

  async function stopCapture() {
    if (!state.activeSessionId || !window.confirm("Stop all running captures in this session? Nmap jobs will continue.")) return;
    setButtonBusy(ui.stopCaptureButton, true, "Stopping…");
    try {
      const result = await api(`/api/sessions/${encodeURIComponent(state.activeSessionId)}/stop-capture`, { method: "POST", body: {} });
      state.activeSession = result.session || result;
      renderSession(state.activeSession);
      schedulePolling();
      toast("Capture stop requested", "Existing PCAPNG evidence will be preserved.");
    } catch (error) {
      toast("Could not stop capture", error.message, "error");
    } finally {
      setButtonBusy(ui.stopCaptureButton, false);
      renderSession(state.activeSession);
    }
  }

  async function cancelScans() {
    if (!state.activeSessionId || !window.confirm("Cancel all queued and running Nmap jobs? Packet captures will continue.")) return;
    setButtonBusy(ui.cancelScansButton, true, "Cancelling…");
    try {
      const result = await api(`/api/sessions/${encodeURIComponent(state.activeSessionId)}/cancel-scans`, { method: "POST", body: {} });
      state.activeSession = result.session || result;
      renderSession(state.activeSession);
      schedulePolling();
      toast("Scan cancellation requested", "Capture jobs are unchanged.");
    } catch (error) {
      toast("Could not cancel scans", error.message, "error");
    } finally {
      setButtonBusy(ui.cancelScansButton, false);
      renderSession(state.activeSession);
    }
  }

  function openImportDialog() {
    ui.uploadProgress.classList.add("is-hidden");
    ui.uploadProgressBar.style.width = "0%";
    ui.confirmImportButton.disabled = false;
    ui.importDialog.showModal();
  }

  function setImportFile(file) {
    if (!file) {
      ui.fileDropTitle.textContent = "Choose a capture file";
      ui.fileDropDetail.textContent = "or drop it here · up to 32 GB";
      return;
    }
    ui.fileDropTitle.textContent = file.name;
    ui.fileDropDetail.textContent = `${formatBytes(file.size)} · ready to import`;
    if (!byId("importAlias").value) byId("importAlias").value = file.name.replace(/\.[^.]+$/, "");
    if (!byId("importName").value) byId("importName").value = `Import — ${file.name.replace(/\.[^.]+$/, "")}`;
  }

  function importMetadata() {
    return {
      name: byId("importName").value.trim(),
      operator: byId("operator").value.trim(),
      alias: byId("importAlias").value.trim(),
      role: byId("importRole").value.trim(),
      switch_port: byId("importSwitchPort").value.trim(),
      vlan_ids: splitTokens(byId("importVlans").value),
      expected_ports: splitTokens(byId("importExpectedPorts").value),
      topology_notes: byId("importTopologyNotes").value.trim(),
      automotive_mode: byId("importAutomotive").checked,
    };
  }

  function uploadImport() {
    const file = ui.importFile.files?.[0];
    if (!file) {
      toast("Choose a capture file", "Supported formats: PCAP, PCAPNG, CAP, BLF, ERF, and Snoop.", "error");
      return;
    }
    if (file.size > 32 * 1024 * 1024 * 1024) {
      toast("Capture is too large", "The local import limit is 32 GB.", "error");
      return;
    }

    const request = new XMLHttpRequest();
    state.uploadRequest = request;
    ui.uploadProgress.classList.remove("is-hidden");
    ui.confirmImportButton.disabled = true;
    ui.uploadProgressText.textContent = "Uploading to the local analyzer…";
    request.open("POST", "/api/import");
    request.responseType = "json";
    request.setRequestHeader("Content-Type", "application/octet-stream");
    request.setRequestHeader("X-NetScope-Token", token);
    request.setRequestHeader("X-NetScope-Filename", encodeURIComponent(file.name));
    request.setRequestHeader("X-NetScope-Metadata", encodeURIComponent(JSON.stringify(importMetadata())));
    request.upload.addEventListener("progress", (event) => {
      if (!event.lengthComputable) return;
      const percentage = Math.round(event.loaded / event.total * 100);
      ui.uploadProgressBar.style.width = `${percentage}%`;
      ui.uploadProgressText.textContent = `${percentage}% · ${formatBytes(event.loaded)} of ${formatBytes(event.total)}`;
    });
    request.addEventListener("load", async () => {
      state.uploadRequest = null;
      const payload = request.response || {};
      if (request.status < 200 || request.status >= 300 || payload.ok === false) {
        ui.confirmImportButton.disabled = false;
        ui.uploadProgressText.textContent = payload.error || `Import failed (${request.status})`;
        toast("Import failed", payload.error || `HTTP ${request.status}`, "error");
        return;
      }
      const session = payload.session || payload;
      state.activeSession = session;
      state.activeSessionId = session.id;
      localStorage.setItem("netscope.activeSessionId", session.id);
      ui.uploadProgressBar.style.width = "100%";
      ui.uploadProgressText.textContent = "Upload complete · analysis queued";
      await loadSessions(true);
      ui.importDialog.close();
      renderSession(session);
      setView("active");
      schedulePolling();
      toast("Capture imported", "Offline analysis has started.");
    });
    request.addEventListener("error", () => {
      state.uploadRequest = null;
      ui.confirmImportButton.disabled = false;
      ui.uploadProgressText.textContent = "The local upload connection failed.";
      toast("Import failed", "The local upload connection failed.", "error");
    });
    request.send(file);
  }

  function bindEvents() {
    queryAll("[data-view-target]").forEach((button) => button.addEventListener("click", () => setView(button.dataset.viewTarget)));
    queryAll("[data-view-link]").forEach((button) => button.addEventListener("click", () => setView(button.dataset.viewLink)));
    byId("dismissBanner").addEventListener("click", hideBanner);
    byId("refreshPreflightButton").addEventListener("click", (event) => refreshEnvironment(event.currentTarget));
    byId("globalRefreshButton").addEventListener("click", (event) => refreshEnvironment(event.currentTarget));
    byId("refreshHistoryButton").addEventListener("click", (event) => {
      setButtonBusy(event.currentTarget, true, "Refreshing…");
      loadSessions(false).finally(() => setButtonBusy(event.currentTarget, false));
    });
    byId("refreshSessionButton").addEventListener("click", (event) => {
      if (!state.activeSessionId) return;
      event.currentTarget.disabled = true;
      loadSession(state.activeSessionId, false).finally(() => { event.currentTarget.disabled = false; });
    });

    ui.interfaceSearch.addEventListener("input", renderInterfaces);
    queryAll("[data-interface-filter]").forEach((button) => button.addEventListener("click", () => {
      state.interfaceFilter = button.dataset.interfaceFilter;
      queryAll("[data-interface-filter]").forEach((item) => item.classList.toggle("is-active", item === button));
      renderInterfaces();
    }));

    byId("selectReadyButton").addEventListener("click", () => {
      const ready = readyInterfacesForCurrentMode();
      const allSelected = ready.length > 0 && ready.every((iface) => state.selectedSources.has(iface.id));
      ready.forEach((iface) => {
        if (allSelected) state.selectedSources.delete(iface.id);
        else if (!state.selectedSources.has(iface.id)) state.selectedSources.set(iface.id, defaultSource(iface));
      });
      renderInterfaces();
    });

    ui.interfaceReadinessNotice.addEventListener("click", (event) => {
      const switchButton = event.target.closest("[data-switch-scan-only]");
      if (!switchButton) return;
      byId("captureEnabled").checked = false;
      byId("captureSettings").classList.add("is-hidden");
      byId("scanEnabled").checked = true;
      setScanUi();
      toast("Nmap-only mode enabled", "Select scan-ready adapters and provide authorized literal IP or CIDR targets.");
    });

    ui.interfaceGrid.addEventListener("change", (event) => {
      const control = event.target.closest(".interface-checkbox");
      if (!control) return;
      const iface = state.interfaces.find((item) => item.id === control.dataset.interfaceId);
      if (!iface) return;
      if (control.checked) state.selectedSources.set(iface.id, state.selectedSources.get(iface.id) || defaultSource(iface));
      else state.selectedSources.delete(iface.id);
      renderInterfaces();
    });

    ui.sourceList.addEventListener("input", (event) => {
      if (event.target.matches("[data-source-field]")) updateSourceFromControl(event.target);
    });
    ui.sourceList.addEventListener("change", (event) => {
      if (event.target.matches("[data-source-field]")) updateSourceFromControl(event.target);
    });
    ui.sourceList.addEventListener("click", (event) => {
      const removeButton = event.target.closest("[data-remove-source]");
      if (!removeButton) return;
      state.selectedSources.delete(removeButton.dataset.removeSource);
      renderInterfaces();
    });

    ui.profileGrid.addEventListener("change", (event) => {
      const input = event.target.closest("[data-profile-input]");
      if (!input) return;
      if (input.checked) state.selectedProfiles.add(input.value);
      else state.selectedProfiles.delete(input.value);
      input.closest(".profile-card")?.classList.toggle("is-selected", input.checked);
      updateLaunchState();
    });

    byId("scanEnabled").addEventListener("change", setScanUi);
    byId("captureEnabled").addEventListener("change", () => {
      byId("captureSettings").classList.toggle("is-hidden", !byId("captureEnabled").checked);
      renderInterfaces();
      updateLaunchState();
    });
    byId("automotiveMode").addEventListener("change", applyAutomotiveDefaults);

    queryAll("#assessmentForm input, #assessmentForm textarea, #assessmentForm select").forEach((control) => {
      if (control.id === "interfaceSearch") return;
      control.addEventListener("input", updateLaunchState);
      control.addEventListener("change", updateLaunchState);
    });
    byId("assessmentForm").addEventListener("submit", (event) => {
      event.preventDefault();
      openReview();
    });
    ui.confirmLaunchButton.addEventListener("click", launchAssessment);

    ui.stopCaptureButton.addEventListener("click", stopCapture);
    ui.cancelScansButton.addEventListener("click", cancelScans);
    ui.historyList.addEventListener("click", async (event) => {
      const button = event.target.closest("[data-open-session]");
      if (!button) return;
      setButtonBusy(button, true, "Opening…");
      const session = await loadSession(button.dataset.openSession, false);
      setButtonBusy(button, false);
      if (session) setView("active");
    });

    byId("openImportButton").addEventListener("click", openImportDialog);
    ui.importFile.addEventListener("change", () => setImportFile(ui.importFile.files?.[0]));
    ["dragenter", "dragover"].forEach((name) => ui.fileDrop.addEventListener(name, (event) => {
      event.preventDefault();
      ui.fileDrop.classList.add("is-dragging");
    }));
    ["dragleave", "drop"].forEach((name) => ui.fileDrop.addEventListener(name, (event) => {
      event.preventDefault();
      ui.fileDrop.classList.remove("is-dragging");
    }));
    ui.fileDrop.addEventListener("drop", (event) => {
      const file = event.dataTransfer?.files?.[0];
      if (!file) return;
      const transfer = new DataTransfer();
      transfer.items.add(file);
      ui.importFile.files = transfer.files;
      setImportFile(file);
    });
    ui.confirmImportButton.addEventListener("click", uploadImport);
    ui.importDialog.addEventListener("cancel", (event) => {
      if (!state.uploadRequest) return;
      event.preventDefault();
      if (window.confirm("Cancel the current upload?")) {
        state.uploadRequest.abort();
        state.uploadRequest = null;
        ui.importDialog.close();
      }
    });

    document.addEventListener("visibilitychange", () => {
      if (!document.hidden && state.activeSessionId && state.activeSession && ACTIVE_STATES.has(state.activeSession.status)) loadSession(state.activeSessionId, true);
    });
  }

  async function initialize() {
    bindEvents();
    setScanUi();
    const initialView = location.hash.slice(1);
    if (VIEW_COPY[initialView]) setView(initialView);
    const results = await Promise.allSettled([loadSystem(false), loadInterfaces(), loadSessions(true)]);
    const failures = results.filter((result) => result.status === "rejected");
    if (failures.length) {
      showBanner("Some local capabilities are unavailable", failures.map((item) => item.reason?.message || "Unknown error").join(" · "));
    }

    if (state.activeSessionId) {
      await loadSession(state.activeSessionId, true);
    } else {
      const running = state.sessions.find((session) => ACTIVE_STATES.has(session.status));
      if (running) await loadSession(running.id, true);
    }
    updateLaunchState();
  }

  initialize().catch((error) => {
    showBanner("Dashboard initialization failed", error.message);
    toast("Dashboard error", error.message, "error");
  });
})();
