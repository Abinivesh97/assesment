from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from netscope.scanner import build_scan_jobs
from netscope.tools import _networks, _recommended_targets, _scan_link_active
from netscope.validation import ValidationError, parse_targets, validate_session_config

from tests.test_core import sample_config, sample_interface


def ipv6_link_local_interface() -> dict:
    interface = sample_interface()
    interface.update(
        {
            "if_index": 15,
            "addresses": [
                {
                    "address": "fe80::abcd%15",
                    "family": "IPv6",
                    "prefix_length": 64,
                }
            ],
            "networks": ["fe80::/64"],
        }
    )
    return interface


class IPv6LinkLocalTargetTests(unittest.TestCase):
    def test_parse_targets_accepts_single_scoped_link_local_address(self) -> None:
        targets, warnings, count = parse_targets("fe80::1234%15")
        self.assertEqual(targets, ["fe80::1234%15"])
        self.assertEqual(warnings, [])
        self.assertEqual(count, 1)

    def test_parse_targets_accepts_safe_named_scope_and_normalizes_explicit_host_prefix(self) -> None:
        targets, warnings, count = parse_targets(["fe80::1234%eth0", "fe80::1234%15/128"])
        self.assertEqual(targets, ["fe80::1234%eth0", "fe80::1234%15"])
        self.assertEqual(warnings, [])
        self.assertEqual(count, 2)

    def test_parse_targets_rejects_malformed_scopes_and_link_local_ranges(self) -> None:
        for target in (
            "fe80::1234%",
            "fe80::1234%eth$0",
            "fe80::1234%eth/0",
            "fe80::1234/127",
            "fe80::/64",
        ):
            with self.subTest(target=target), self.assertRaises(ValidationError):
                parse_targets(target)

    def test_validation_auto_scopes_unscoped_link_local_address_for_bound_source(self) -> None:
        raw = sample_config()
        raw["sources"][0]["targets"] = ["fe80::1234"]
        validated = validate_session_config(raw, [ipv6_link_local_interface()])
        self.assertEqual(validated["sources"][0]["targets"], ["fe80::1234%15"])

    def test_validation_rejects_link_local_scope_mismatched_to_bound_interface(self) -> None:
        raw = sample_config()
        raw["sources"][0]["targets"] = ["fe80::1234%12"]
        with self.assertRaises(ValidationError):
            validate_session_config(raw, [ipv6_link_local_interface()])

    def test_same_link_local_address_on_different_interface_zones_is_not_an_overlap(self) -> None:
        left = ipv6_link_local_interface()
        left["id"] = "left"
        right = ipv6_link_local_interface()
        right.update(
            {
                "id": "right",
                "if_index": 16,
                "addresses": [{"address": "fe80::dcba%16", "family": "IPv6", "prefix_length": 64}],
            }
        )
        raw = sample_config()
        raw["sources"] = [
            {"interface_id": "left", "alias": "Left", "targets": ["fe80::1234"], "bind_interface": True},
            {"interface_id": "right", "alias": "Right", "targets": ["fe80::1234"], "bind_interface": True},
        ]
        validated = validate_session_config(raw, [left, right])
        self.assertEqual(validated["sources"][0]["targets"], ["fe80::1234%15"])
        self.assertEqual(validated["sources"][1]["targets"], ["fe80::1234%16"])

    def test_link_local_network_is_retained_but_not_recommended_as_prefilled_scope(self) -> None:
        networks = _networks(
            [
                {
                    "address": "fe80::abcd%15",
                    "family": "IPv6",
                    "prefix_length": 64,
                }
            ]
        )
        self.assertEqual(networks, ["fe80::/64"])
        self.assertEqual(_recommended_targets(networks), [])

    def test_link_local_raw_scan_records_interface_only_binding_truthfully(self) -> None:
        raw = sample_config()
        raw["scan"]["profiles"] = ["host_discovery"]
        raw["sources"][0]["targets"] = ["fe80::1234"]
        validated = validate_session_config(raw, [ipv6_link_local_interface()])
        with tempfile.TemporaryDirectory() as temporary:
            jobs = build_scan_jobs("nmap", validated, Path(temporary))
        self.assertEqual(len(jobs), 1)
        self.assertEqual(jobs[0]["binding_mode"], "raw-interface")
        self.assertIn("Nmap selects the source address", jobs[0]["binding_note"])
        self.assertIn("fe80::1234%15", jobs[0]["argv"])

    def test_scan_link_status_accepts_usable_and_rejects_inactive_states(self) -> None:
        for status in ("Up", "Unknown"):
            with self.subTest(status=status):
                self.assertTrue(_scan_link_active(status))
        for status in ("Disconnected", "Disabled", "Down"):
            with self.subTest(status=status):
                self.assertFalse(_scan_link_active(status))


if __name__ == "__main__":
    unittest.main()
