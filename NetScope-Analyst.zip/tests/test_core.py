from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

from netscope.findings import build_findings, build_inventory
from netscope.nmap_parser import parse_nmap_xml
from netscope.reporting import build_report, generate_reports
from netscope.scanner import build_scan_jobs
from netscope.session import SessionManager
from netscope.testcases import evaluate_test_cases
from netscope.tools import parse_capture_interfaces, parse_nmap_interface_map
from netscope.validation import ValidationError, parse_ports, parse_targets, validate_session_config


def sample_interface() -> dict:
    return {
        "id": "guid-a",
        "capture_id": r"\Device\NPF_{00000000-0000-0000-0000-000000000001}",
        "capture_description": "Ethernet VLAN 42",
        "name": "VLAN42",
        "description": "Vector VN5620 VLAN 42",
        "guid": "00000000-0000-0000-0000-000000000001",
        "capture_ready": True,
        "scan_ready": True,
        "status": "Up",
        "addresses": [{"address": "192.168.42.10", "family": "IPv4", "prefix_length": 24}],
        "networks": ["192.168.42.0/24"],
        "provider": "tshark",
        "capture_helper": "dumpcap",
        "kind": "Automotive / Vector",
    }


def sample_config() -> dict:
    return {
        "name": "Bench",
        "operator": "Analyst",
        "authorization_note": "Approved bench",
        "topology_notes": "ECU → VN5620 → Marvell mirror → PC",
        "automotive_mode": True,
        "capture": {
            "enabled": True,
            "duration_seconds": 60,
            "max_file_mb": 64,
            "packet_limit": 0,
            "snaplen": 0,
            "promiscuous": True,
            "bpf_filter": "",
        },
        "scan": {
            "enabled": True,
            "authorized": True,
            "profiles": ["automotive_discovery", "quick_tcp"],
            "allow_high_impact": False,
            "allow_intrusive": False,
            "allow_public": False,
            "allow_large": False,
            "max_rate": 50,
            "max_retries": 1,
            "timing": 2,
            "host_timeout_seconds": 900,
            "script_timeout_seconds": 120,
            "include_port_zero": False,
            "exclusions": [],
        },
        "sources": [
            {
                "interface_id": "guid-a",
                "alias": "Powertrain VLAN",
                "role": "VN5620 channel A",
                "switch_port": "Marvell P3 mirror",
                "vlan_ids": [42],
                "targets": ["192.168.42.0/24"],
                "bind_interface": True,
                "expected_ports": [13400, 30490],
            }
        ],
    }


class ValidationTests(unittest.TestCase):
    def test_local_targets_are_normalized(self) -> None:
        targets, warnings, count = parse_targets("192.168.42.7/24, fd00::1")
        self.assertEqual(targets, ["192.168.42.0/24", "fd00::1"])
        self.assertEqual(warnings, [])
        self.assertEqual(count, 257)

    def test_public_and_option_injection_are_rejected(self) -> None:
        with self.assertRaises(ValidationError):
            parse_targets("8.8.8.8")
        with self.assertRaises(ValidationError):
            parse_targets("-iR")
        with self.assertRaises(ValidationError):
            parse_targets("0.0.0.0/0", allow_public=True, allow_large=True)

    def test_large_scope_requires_opt_in(self) -> None:
        with self.assertRaises(ValidationError):
            parse_targets("10.0.0.0/8")

    def test_port_boundaries(self) -> None:
        self.assertEqual(parse_ports("0, 13400, 65535,13400"), [0, 13400, 65535])
        with self.assertRaises(ValidationError):
            parse_ports("65536")

    def test_session_profile_gates(self) -> None:
        raw = sample_config()
        validated = validate_session_config(raw, [sample_interface()])
        self.assertEqual(validated["sources"][0]["vlan_ids"], [42])
        raw["scan"]["profiles"] = ["full_tcp"]
        with self.assertRaises(ValidationError):
            validate_session_config(raw, [sample_interface()])

    def test_string_boolean_and_off_interface_target_are_rejected(self) -> None:
        raw = sample_config()
        raw["scan"]["authorized"] = "false"
        with self.assertRaises(ValidationError):
            validate_session_config(raw, [sample_interface()])
        raw = sample_config()
        raw["sources"][0]["targets"] = ["192.168.99.0/24"]
        with self.assertRaises(ValidationError):
            validate_session_config(raw, [sample_interface()])

    def test_duplicate_profiles_are_deduplicated(self) -> None:
        raw = sample_config()
        raw["scan"]["profiles"] = ["quick_tcp", "quick_tcp"]
        validated = validate_session_config(raw, [sample_interface()])
        self.assertEqual(validated["scan"]["profiles"], ["quick_tcp"])


class ToolAndScannerTests(unittest.TestCase):
    def test_capture_interface_parser_preserves_windows_guid(self) -> None:
        output = "1. \\Device\\NPF_{00000000-0000-0000-0000-000000000001} (VLAN 42)\n2. lo (Loopback)\n"
        rows = parse_capture_interfaces(output)
        self.assertEqual(rows[0]["capture_index"], 1)
        self.assertEqual(rows[0]["capture_description"], "VLAN 42")
        self.assertEqual(rows[0]["guid"], "00000000-0000-0000-0000-000000000001")

    def test_nmap_windows_device_mapping(self) -> None:
        output = """DEV    WINDEVICE
eth9   \\Device\\NPF_{00000000-0000-0000-0000-000000000001}
<none> \\Device\\NPF_{00000000-0000-0000-0000-000000000002}

**************************ROUTES**************************
"""
        mapping = parse_nmap_interface_map(output)
        self.assertEqual(mapping[r"\device\npf_{00000000-0000-0000-0000-000000000001}"], "eth9")

    def test_scan_jobs_split_family_and_use_allowlisted_arguments(self) -> None:
        raw = sample_config()
        config = validate_session_config(raw, [sample_interface()])
        with tempfile.TemporaryDirectory() as temporary:
            session_dir = Path(temporary) / "new-session"
            jobs = build_scan_jobs("nmap", config, session_dir)
            self.assertFalse(session_dir.exists())
        self.assertEqual(len(jobs), 2)
        quick = next(job for job in jobs if job["profile"] == "quick_tcp")
        self.assertIn("--top-ports", quick["argv"])
        self.assertIn("192.168.42.0/24", quick["argv"])
        self.assertNotIn("--script", quick["argv"])
        self.assertNotIn("-e", quick["argv"])
        self.assertEqual(quick["binding_mode"], "validated-direct-connected-os-route")

    def test_scan_enabled_session_registers_before_creating_output_directories(self) -> None:
        system = {
            "tools": {
                "dumpcap": {"available": True, "path": "dumpcap"},
                "tshark": {"available": True, "path": "tshark"},
                "nmap": {"available": True, "path": "nmap"},
            }
        }
        with tempfile.TemporaryDirectory() as temporary:
            with mock.patch("netscope.session.system_snapshot", return_value=system):
                manager = SessionManager(Path(temporary))
            with (
                mock.patch.object(manager, "interfaces", return_value=[sample_interface()]),
                mock.patch("netscope.session.threading.Thread.start"),
            ):
                state = manager.start_session(sample_config())

            session_dir = manager.sessions_dir / state["id"]
            self.assertEqual(state["status"], "queued")
            self.assertTrue((session_dir / "state.json").is_file())
            self.assertTrue((session_dir / "session-metadata.json").is_file())
            self.assertFalse((session_dir / "nmap").exists())

    def test_full_tcp_service_profile_covers_complete_range_with_version_probes(self) -> None:
        raw = sample_config()
        raw["scan"]["profiles"] = ["full_tcp_services"]
        raw["scan"]["allow_high_impact"] = True
        config = validate_session_config(raw, [sample_interface()])
        with tempfile.TemporaryDirectory() as temporary:
            jobs = build_scan_jobs("nmap", config, Path(temporary))
        job = jobs[0]
        port_index = job["argv"].index("-p")
        self.assertEqual(job["argv"][port_index + 1], "1-65535")
        self.assertIn("-sV", job["argv"])
        self.assertIn("--version-light", job["argv"])


class ParsingAndReportingTests(unittest.TestCase):
    XML = """<?xml version="1.0"?>
<nmaprun scanner="nmap" args="nmap -sV 192.168.42.20" start="1" version="7.95">
  <scaninfo type="connect" protocol="tcp" numservices="2" services="23,13400"/>
  <host starttime="1" endtime="2">
    <status state="up" reason="syn-ack"/>
    <address addr="192.168.42.20" addrtype="ipv4"/>
    <address addr="00:11:22:33:44:55" addrtype="mac" vendor="Example"/>
    <hostnames><hostname name="ecu-a"/></hostnames>
    <ports>
      <port protocol="tcp" portid="23"><state state="open" reason="syn-ack"/><service name="telnet" product="Example ECU shell" method="probed" conf="10"/></port>
      <port protocol="tcp" portid="13400"><state state="open" reason="syn-ack"/><service name="unknown" method="table" conf="3"/>
        <script id="ssl-heartbleed" output="VULNERABLE CVE-2014-0160"/>
      </port>
    </ports>
  </host>
  <runstats><finished time="2" elapsed="1.0"/><hosts up="1" down="0" total="1"/></runstats>
</nmaprun>"""

    def test_nmap_inventory_and_findings(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            xml_path = Path(temporary) / "scan.xml"
            xml_path.write_text(self.XML, encoding="utf-8")
            parsed = parse_nmap_xml(xml_path)
        records = [{"source_id": "source-1", "parsed": parsed}]
        assets, services = build_inventory(records)
        config = validate_session_config(sample_config(), [sample_interface()])
        findings = build_findings(config, [], services)
        self.assertEqual(len(assets), 1)
        self.assertTrue(any("Telnet" in row["title"] for row in findings))
        self.assertTrue(any("CVE-2014-0160" in row.get("cve_ids", []) for row in findings))
        self.assertTrue(any("DoIP" in row["title"] for row in findings))

    def test_report_html_escapes_hostile_banner(self) -> None:
        config = validate_session_config(sample_config(), [sample_interface()])
        state = {
            "id": "00000000-0000-0000-0000-000000000099",
            "name": "Bench <script>alert(1)</script>",
            "status": "completed",
            "created_at": "2026-01-01T00:00:00+00:00",
            "started_at": "2026-01-01T00:00:00+00:00",
            "ended_at": "2026-01-01T00:01:00+00:00",
            "config": config,
            "system": {},
            "captures": [],
            "scans": [],
            "warnings": [],
            "errors": [],
        }
        report = build_report(state, [], [], [], [], [])
        with tempfile.TemporaryDirectory() as temporary:
            _, artifacts = generate_reports(Path(temporary), state, [], [], [], [], [])
            rendered = Path(artifacts["report_html"]).read_text(encoding="utf-8")
        self.assertNotIn("<script>alert(1)</script>", rendered)
        self.assertIn("&lt;script&gt;alert(1)&lt;/script&gt;", rendered)
        self.assertEqual(report["executive_summary"]["assets"], 0)

    def test_test_case_matrix_does_not_treat_failed_jobs_as_completed_evidence(self) -> None:
        config = sample_config()
        services = [{"source_id": "source-1", "state": "open", "port": 23, "service": "telnet"}]
        rows = evaluate_test_cases(
            config,
            [],
            services,
            [],
            captures=[{"source_id": "source-1", "status": "failed"}],
            scans=[{"source_id": "source-1", "profile": "quick_tcp", "status": "cancelled"}],
        )
        statuses = {row["id"]: row["status"] for row in rows}
        self.assertEqual(statuses["Eth_TC_001"], "incomplete")
        self.assertNotEqual(statuses["Eth_TC_002"], "evidence-collected")
        self.assertEqual(statuses["Eth_TC_004"], "incomplete")
        self.assertEqual(statuses["Eth_TC_006"], "incomplete")

    def test_test_case_matrix_accepts_analyzed_stopped_capture_and_completed_scan(self) -> None:
        config = sample_config()
        analyses = [
            {
                "source_id": "source-1",
                "analysis": {
                    "packets": 12,
                    "protocols": [{"protocol": "HTTP", "count": 3}],
                    "vlan_partitions": {"42": {"packets": 12, "bytes": 1200}},
                },
            }
        ]
        services = [{"source_id": "source-1", "state": "open", "port": 80, "service": "http"}]
        rows = evaluate_test_cases(
            config,
            analyses,
            services,
            [],
            captures=[{"source_id": "source-1", "status": "stopped"}],
            scans=[{"source_id": "source-1", "profile": "quick_tcp", "status": "completed"}],
        )
        statuses = {row["id"]: row["status"] for row in rows}
        self.assertEqual(statuses["Eth_TC_001"], "evidence-collected")
        self.assertEqual(statuses["Eth_TC_002"], "evidence-collected")
        self.assertEqual(statuses["Eth_TC_004"], "partial-evidence")
        self.assertEqual(statuses["Eth_TC_006"], "evidence-collected")

    def test_test_case_matrix_marks_mixed_execution_as_partial(self) -> None:
        config = sample_config()
        analyses = [
            {
                "source_id": "source-1",
                "analysis": {
                    "packets": 8,
                    "protocols": [{"protocol": "HTTP", "count": 2}],
                    "vlan_partitions": {"42": {"packets": 8, "bytes": 800}},
                },
            }
        ]
        rows = evaluate_test_cases(
            config,
            analyses,
            [],
            [],
            captures=[
                {"source_id": "source-1", "status": "completed"},
                {"source_id": "source-2", "status": "failed"},
            ],
            scans=[
                {"source_id": "source-1", "profile": "quick_tcp", "status": "completed"},
                {"source_id": "source-1", "profile": "standard_tcp", "status": "failed"},
            ],
        )
        statuses = {row["id"]: row["status"] for row in rows}
        self.assertEqual(statuses["Eth_TC_001"], "partial-evidence")
        self.assertEqual(statuses["Eth_TC_002"], "partial-evidence")
        self.assertEqual(statuses["Eth_TC_006"], "partial-evidence")

    def test_vlan_report_recomputes_test_matrix_from_vlan_evidence(self) -> None:
        config = sample_config()
        config["sources"][0].update(
            {
                "source_id": "source-1",
                "vlan_ids": [42, 43],
                "interface": sample_interface(),
            }
        )
        analyses = [
            {
                "source_id": "source-1",
                "source_alias": "Powertrain VLAN",
                "analysis": {
                    "packets": 10,
                    "bytes": 1000,
                    "protocols": [{"protocol": "HTTP", "count": 6}],
                    "vlan_partitions": {
                        "42": {"packets": 4, "bytes": 400},
                        "43": {"packets": 6, "bytes": 600},
                    },
                },
                "vlan_views": [
                    {
                        "vlan_id": 42,
                        "analysis": {
                            "packets": 4,
                            "bytes": 400,
                            "duration_seconds": 1.0,
                            "protocols": [{"protocol": "DNS", "count": 4}],
                            "vlan_partitions": {"42": {"packets": 4, "bytes": 400}},
                        },
                    },
                    {
                        "vlan_id": 43,
                        "analysis": {
                            "packets": 6,
                            "bytes": 600,
                            "duration_seconds": 1.0,
                            "protocols": [{"protocol": "HTTP", "count": 6}],
                            "vlan_partitions": {"43": {"packets": 6, "bytes": 600}},
                        },
                    },
                ],
            }
        ]
        state = {
            "id": "00000000-0000-0000-0000-000000000100",
            "name": "Two VLAN bench",
            "status": "completed",
            "created_at": "2026-01-01T00:00:00+00:00",
            "started_at": "2026-01-01T00:00:00+00:00",
            "ended_at": "2026-01-01T00:01:00+00:00",
            "config": config,
            "system": {},
            "captures": [{"source_id": "source-1", "status": "completed"}],
            "scans": [{"source_id": "source-1", "profile": "quick_tcp", "status": "completed"}],
            "warnings": [],
            "errors": [],
        }
        services = [{"source_id": "source-1", "state": "open", "port": 80, "service": "http"}]
        with tempfile.TemporaryDirectory() as temporary:
            report, artifacts = generate_reports(Path(temporary), state, analyses, [], [], services, [])
            vlan_42 = Path(artifacts["report_source-1_vlan_42"]).read_text(encoding="utf-8")
        global_statuses = {row["id"]: row["status"] for row in report["test_case_matrix"]}
        self.assertEqual(global_statuses["Eth_TC_001"], "evidence-collected")
        self.assertIn("HTTP packets: 0; TLS/SSL packets: 0; open web-service records: 0.", vlan_42)
        self.assertNotIn("open web-service records: 1.", vlan_42)


if __name__ == "__main__":
    unittest.main()
