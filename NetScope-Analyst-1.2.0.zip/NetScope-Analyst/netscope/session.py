"""Session orchestration for capture, Nmap, analysis, and reports."""

from __future__ import annotations

import concurrent.futures
import copy
import hashlib
import json
import os
import re
import shutil
import subprocess
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .analysis import analyze_capture, split_vlan_capture, write_analysis_json
from .findings import build_findings, build_inventory, severity_counts
from .nmap_parser import parse_nmap_xml
from .privacy import sanitize_vin_data
from .reporting import generate_reports, refresh_evidence_bundle
from .scanner import build_scan_jobs, run_scan_job
from .testcases import evaluate_test_cases
from .tools import CREATE_NO_WINDOW, list_interfaces, system_snapshot
from .validation import ValidationError, clean_text, parse_bool, parse_ports, parse_vlan_ids, validate_session_config
from .vlan import build_vlan_views


ACTIVE_STATES = {"queued", "starting", "capturing", "capturing-and-scanning", "scanning", "stopping", "analyzing", "reporting"}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _slug(value: str, maximum: int = 80) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9_.-]+", "-", value).strip(".-")
    return (cleaned or "source")[:maximum]


class SessionManager:
    def __init__(self, data_dir: str | Path):
        self.data_dir = Path(data_dir).resolve()
        self.sessions_dir = self.data_dir / "sessions"
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._states: dict[str, dict[str, Any]] = {}
        self._threads: dict[str, threading.Thread] = {}
        self._capture_processes: dict[str, dict[str, subprocess.Popen[Any]]] = {}
        self._scan_processes: dict[str, dict[str, subprocess.Popen[Any]]] = {}
        self._analysis_processes: dict[str, dict[str, subprocess.Popen[Any]]] = {}
        self._capture_stop: dict[str, threading.Event] = {}
        self._scan_stop: dict[str, threading.Event] = {}
        self._shutdown_event = threading.Event()
        self._closing = False
        self._audit_hashes: dict[str, str] = {}
        self._system = system_snapshot()
        self._load_existing()

    @property
    def system(self) -> dict[str, Any]:
        return copy.deepcopy(self._system)

    def refresh_system(self) -> dict[str, Any]:
        snapshot = system_snapshot()
        with self._lock:
            self._system = snapshot
        return copy.deepcopy(snapshot)

    def interfaces(self) -> list[dict[str, Any]]:
        tshark = self._system["tools"]["tshark"]["path"]
        nmap = self._system["tools"]["nmap"]["path"]
        dumpcap = self._system["tools"]["dumpcap"]["path"]
        return list_interfaces(tshark, nmap, dumpcap)

    def _load_existing(self) -> None:
        for path in self.sessions_dir.glob("*/state.json"):
            try:
                state = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            session_id = state.get("id")
            if not session_id:
                continue
            self._audit_hashes[session_id] = self._last_audit_hash(session_id)
            if state.get("status") in ACTIVE_STATES:
                state["status"] = "interrupted"
                state["ended_at"] = utc_now()
                state.setdefault("errors", []).append("The application exited before this session completed. Existing evidence was preserved.")
                self._write_state_dict(state)
                self._audit(session_id, "session_interrupted", {"reason": "application restart"})
            self._states[session_id] = state

    def _session_dir(self, session_id: str) -> Path:
        if not re.fullmatch(r"[0-9a-f-]{36}", session_id):
            raise KeyError("Unknown session")
        path = (self.sessions_dir / session_id).resolve()
        if path.parent != self.sessions_dir:
            raise KeyError("Unknown session")
        return path

    def _last_audit_hash(self, session_id: str) -> str:
        path = self._session_dir(session_id) / "audit.jsonl"
        if not path.is_file():
            return ""
        try:
            lines = [line for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
            return str(json.loads(lines[-1]).get("entry_hash", "")) if lines else ""
        except (OSError, json.JSONDecodeError):
            return ""

    def _include_plaintext_vin(self, session_id: str, state: dict[str, Any] | None = None) -> bool:
        reference = state if isinstance(state, dict) else self._states.get(session_id, {})
        return (reference.get("config") or {}).get("include_vin_in_reports") is True

    def _persisted_value(
        self,
        session_id: str,
        value: Any,
        state: dict[str, Any] | None = None,
    ) -> Any:
        return sanitize_vin_data(
            value,
            session_id,
            include_plaintext=self._include_plaintext_vin(session_id, state),
        )

    def _audit(self, session_id: str, event: str, details: dict[str, Any] | None = None) -> None:
        with self._lock:
            previous_hash = self._audit_hashes.get(session_id, "")
            entry = {
                "timestamp_utc": utc_now(),
                "session_id": session_id,
                "event": event,
                "details": details or {},
                "previous_hash": previous_hash,
            }
            entry = self._persisted_value(session_id, entry)
            canonical = json.dumps(entry, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
            entry_hash = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
            entry["entry_hash"] = entry_hash
            path = self._session_dir(session_id) / "audit.jsonl"
            with path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(entry, ensure_ascii=False, default=str) + "\n")
                handle.flush()
                os.fsync(handle.fileno())
            self._audit_hashes[session_id] = entry_hash

    def _write_metadata(self, session_id: str, state: dict[str, Any]) -> None:
        metadata = {
            "schema_version": "1.0",
            "session_id": session_id,
            "created_at": state.get("created_at"),
            "mode": state.get("mode", "live"),
            "config": state.get("config"),
            "system": state.get("system"),
        }
        metadata = self._persisted_value(session_id, metadata, state)
        path = self._session_dir(session_id) / "session-metadata.json"
        path.write_text(json.dumps(metadata, indent=2, ensure_ascii=False, default=str), encoding="utf-8")

    def _write_state_dict(self, state: dict[str, Any]) -> None:
        session_dir = self._session_dir(state["id"])
        session_dir.mkdir(parents=True, exist_ok=True)
        target = session_dir / "state.json"
        temporary = session_dir / "state.json.tmp"
        persisted = self._persisted_value(state["id"], state, state)
        temporary.write_text(json.dumps(persisted, indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(temporary, target)

    def _write_analysis_result(
        self,
        session_id: str,
        path: Path,
        analysis: dict[str, Any],
    ) -> dict[str, Any]:
        persisted = self._persisted_value(session_id, analysis)
        write_analysis_json(path, persisted)
        return persisted

    def _save(self, session_id: str) -> None:
        with self._lock:
            self._write_state_dict(self._states[session_id])

    def _set(self, session_id: str, **changes: Any) -> None:
        with self._lock:
            previous_status = self._states[session_id].get("status")
            self._states[session_id].update(changes)
            self._write_state_dict(self._states[session_id])
            current_status = self._states[session_id].get("status")
            if current_status != previous_status:
                self._audit(session_id, "session_status_changed", {"from": previous_status, "to": current_status})

    def list_sessions(self) -> list[dict[str, Any]]:
        with self._lock:
            rows = []
            for state in self._states.values():
                rows.append(
                    {
                        "id": state["id"],
                        "name": state.get("name"),
                        "status": state.get("status"),
                        "created_at": state.get("created_at"),
                        "started_at": state.get("started_at"),
                        "ended_at": state.get("ended_at"),
                        "summary": state.get("summary", {}),
                        "source_count": len(state.get("config", {}).get("sources", [])),
                        "artifacts": state.get("artifacts", {}),
                    }
                )
        rows.sort(key=lambda row: row.get("created_at") or "", reverse=True)
        return rows

    def get_session(self, session_id: str) -> dict[str, Any]:
        with self._lock:
            if session_id not in self._states:
                raise KeyError("Unknown session")
            return copy.deepcopy(self._states[session_id])

    def _ensure_accepting_sessions(self) -> None:
        if self._closing:
            raise ValidationError("The application is shutting down and cannot start another session")

    def _validated_launch_config(
        self,
        raw_config: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        with self._lock:
            self._ensure_accepting_sessions()
        interfaces = self.interfaces()
        config = validate_session_config(raw_config, interfaces)
        tools = self._system["tools"]
        if config["capture"]["enabled"]:
            if not (tools["dumpcap"]["available"] or tools["tshark"]["available"]):
                raise ValidationError("Wireshark Dumpcap/TShark is required for capture")
            if not tools["tshark"]["available"]:
                raise ValidationError("TShark is required for packet analysis")
        if config["scan"]["enabled"] and not tools["nmap"]["available"]:
            raise ValidationError("Nmap is required for active scan profiles")
        if not config["capture"]["enabled"] and not config["scan"]["enabled"]:
            raise ValidationError("Enable passive capture, active scanning, or import an existing capture")
        return config, tools

    def plan_session(self, raw_config: dict[str, Any]) -> dict[str, Any]:
        """Validate and expose the exact local execution plan without starting it."""

        config, tools = self._validated_launch_config(raw_config)
        plan_dir = self.sessions_dir / ".review-plan"
        scans = (
            build_scan_jobs(tools["nmap"]["path"], config, plan_dir)
            if config["scan"]["enabled"]
            else []
        )
        if len(scans) > 128:
            raise ValidationError(
                "The selected sources, address families, and profiles create more than 128 scan jobs"
            )
        target_address_count = sum(
            int(source.get("target_count", 0)) for source in config.get("sources", [])
        )
        return {
            "config": config,
            "capture": {
                "enabled": bool(config["capture"]["enabled"]),
                "source_count": len(config.get("sources", [])) if config["capture"]["enabled"] else 0,
            },
            "scan": {
                "enabled": bool(config["scan"]["enabled"]),
                "job_count": len(scans),
                "target_address_count_before_exclusions": target_address_count,
                "profile_address_attempts_before_exclusions": (
                    target_address_count * len(config["scan"].get("profiles", []))
                ),
                "source_plans": [
                    {
                        "source_id": source.get("source_id"),
                        "source_alias": source.get("alias"),
                        **source.get("scan_plan", {}),
                    }
                    for source in config.get("sources", [])
                ],
                "jobs": [
                    {
                        "id": row.get("id"),
                        "source_id": row.get("source_id"),
                        "profile": row.get("profile"),
                        "family": row.get("family"),
                        "targets": row.get("targets", []),
                        "manual_exclusions": row.get("manual_exclusions", []),
                        "automatic_exclusions": row.get("automatic_exclusions", []),
                        "effective_exclusions": row.get("effective_exclusions", []),
                        "route_verification": row.get("route_verification", []),
                        "binding_mode": row.get("binding_mode"),
                        "binding_note": row.get("binding_note"),
                    }
                    for row in scans
                ],
            },
            "warnings": list(config.get("warnings", [])),
        }

    def start_session(self, raw_config: dict[str, Any]) -> dict[str, Any]:
        config, tools = self._validated_launch_config(raw_config)

        session_id = str(uuid.uuid4())
        session_dir = self._session_dir(session_id)
        captures: list[dict[str, Any]] = []
        if config["capture"]["enabled"]:
            for source in config["sources"]:
                filename_alias = self._persisted_value(session_id, source["alias"], {"config": config})
                filename = f"{source['source_id']}-{_slug(filename_alias)}.pcapng"
                capture_path = session_dir / "captures" / filename
                stderr_path = session_dir / "captures" / f"{filename}.stderr.txt"
                captures.append(
                    {
                        "id": source["source_id"],
                        "source_id": source["source_id"],
                        "source_alias": source["alias"],
                        "interface_id": source["interface_id"],
                        "capture_id": source["interface"].get("capture_id"),
                        "path": str(capture_path),
                        "stderr_path": str(stderr_path),
                        "status": "queued",
                        "started_at": None,
                        "ended_at": None,
                        "exit_code": None,
                        "pid": None,
                        "size_bytes": 0,
                        "error": None,
                        "command_display": None,
                    }
                )
        scans = build_scan_jobs(tools["nmap"]["path"], config, session_dir) if config["scan"]["enabled"] else []
        if len(scans) > 128:
            raise ValidationError("The selected sources, address families, and profiles create more than 128 scan jobs")
        initial_artifacts: dict[str, str] = {}
        for row in captures:
            initial_artifacts[f"capture_{row['source_id']}"] = row["path"]
            initial_artifacts[f"capture_{row['source_id']}_stderr"] = row["stderr_path"]
        for row in scans:
            initial_artifacts[f"nmap_{row['id']}_xml"] = row["xml_path"]
            initial_artifacts[f"nmap_{row['id']}_text"] = row["normal_path"]
            initial_artifacts[f"nmap_{row['id']}_stderr"] = row["stderr_path"]
        state: dict[str, Any] = {
            "id": session_id,
            "name": config["name"],
            "status": "queued",
            "created_at": utc_now(),
            "started_at": None,
            "ended_at": None,
            "config": config,
            "system": self.system,
            "captures": captures,
            "scans": scans,
            "analyses": [],
            "assets": [],
            "services": [],
            "findings": [],
            "summary": {},
            "artifacts": initial_artifacts,
            "warnings": list(config.get("warnings", [])),
            "errors": [],
        }
        session_dir_created = False
        try:
            with self._lock:
                self._ensure_accepting_sessions()
                session_dir.mkdir(parents=True, exist_ok=False)
                session_dir_created = True
                self._states[session_id] = state
                self._capture_stop[session_id] = threading.Event()
                self._scan_stop[session_id] = threading.Event()
                self._capture_processes[session_id] = {}
                self._scan_processes[session_id] = {}
                self._analysis_processes[session_id] = {}
                self._audit_hashes[session_id] = ""
                self._write_metadata(session_id, state)
                self._write_state_dict(state)
                config_hash = hashlib.sha256(json.dumps(config, sort_keys=True, default=str).encode("utf-8")).hexdigest()
                self._audit(session_id, "session_created", {"name": config["name"], "source_count": len(config["sources"]), "config_sha256": config_hash})
                thread = threading.Thread(target=self._run_session, args=(session_id,), name=f"netscope-{session_id[:8]}", daemon=True)
                self._threads[session_id] = thread
                thread.start()
        except BaseException:
            with self._lock:
                self._states.pop(session_id, None)
                self._capture_stop.pop(session_id, None)
                self._scan_stop.pop(session_id, None)
                self._capture_processes.pop(session_id, None)
                self._scan_processes.pop(session_id, None)
                self._analysis_processes.pop(session_id, None)
                self._audit_hashes.pop(session_id, None)
                self._threads.pop(session_id, None)
            if session_dir_created and session_dir.parent == self.sessions_dir and session_dir.exists():
                shutil.rmtree(session_dir)
            raise
        return self.get_session(session_id)

    def import_capture(self, upload_path: str | Path, original_filename: str, metadata: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            self._ensure_accepting_sessions()
        tshark = self._system["tools"]["tshark"]["path"]
        if not tshark:
            raise ValidationError("TShark is required to analyze an imported capture")
        source_path = Path(upload_path).resolve()
        if not source_path.is_file():
            raise ValidationError("Uploaded capture is unavailable")
        extension = Path(original_filename).suffix.lower()
        if extension not in {".pcap", ".pcapng", ".cap", ".blf", ".erf", ".snoop"}:
            raise ValidationError("Supported imports are PCAP, PCAPNG, CAP, BLF, ERF, and Snoop files")
        alias = clean_text(metadata.get("alias") or Path(original_filename).stem or "Imported capture", 120)
        role = clean_text(metadata.get("role"), 240)
        switch_port = clean_text(metadata.get("switch_port"), 120)
        vlan_ids = parse_vlan_ids(metadata.get("vlan_ids"))
        expected_ports = parse_ports(metadata.get("expected_ports"))
        session_name = clean_text(metadata.get("name") or f"Import — {alias}", 120)
        operator = clean_text(metadata.get("operator"), 120)
        topology_notes = clean_text(metadata.get("topology_notes"), 4000)
        automotive_mode = parse_bool(metadata.get("automotive_mode"), "automotive mode", True)
        include_vin_in_reports = parse_bool(
            metadata.get("include_vin_in_reports"),
            "VIN report opt-in",
            False,
        )
        source_size = source_path.stat().st_size
        session_id = str(uuid.uuid4())
        session_dir = self._session_dir(session_id)
        destination = session_dir / "captures" / f"source-1-imported{extension}"
        source = {
            "source_id": "source-1",
            "interface_id": "imported-capture",
            "interface": {
                "id": "imported-capture",
                "name": original_filename,
                "description": "Offline imported capture",
                "capture_id": original_filename,
                "provider": "import",
                "capture_ready": False,
                "scan_ready": False,
                "addresses": [],
                "networks": [],
                "kind": "Imported",
            },
            "alias": alias,
            "role": role,
            "switch_port": switch_port,
            "vlan_ids": vlan_ids,
            "targets": [],
            "target_count": 0,
            "bind_interface": False,
            "expected_ports": expected_ports,
        }
        config = {
            "name": session_name,
            "operator": operator,
            "authorization_note": "",
            "topology_notes": topology_notes,
            "automotive_mode": automotive_mode,
            "include_vin_in_reports": include_vin_in_reports,
            "capture": {"enabled": False, "imported": True, "duration_seconds": 0, "max_file_mb": 0, "packet_limit": 0, "snaplen": 0, "promiscuous": False, "bpf_filter": ""},
            "scan": {"enabled": False, "authorized": False, "profiles": [], "allow_public": False, "allow_large": False, "allow_high_impact": False, "allow_intrusive": False, "include_port_zero": False, "max_rate": 50, "max_retries": 1, "timing": 2, "host_timeout_seconds": 900, "script_timeout_seconds": 120, "exclusions": []},
            "sources": [source],
            "warnings": ["Offline import: source-port identity, direction metadata, timestamp provenance, and VLAN fidelity depend on the exporting tool and must be verified."],
        }
        capture = {
            "id": "source-1",
            "source_id": "source-1",
            "source_alias": alias,
            "interface_id": "imported-capture",
            "capture_id": original_filename,
            "path": str(destination),
            "stderr_path": None,
            "status": "completed",
            "started_at": None,
            "ended_at": None,
            "exit_code": 0,
            "pid": None,
            "size_bytes": source_size,
            "error": None,
            "command_display": None,
            "original_filename": original_filename,
        }
        state = {
            "id": session_id,
            "mode": "import",
            "name": config["name"],
            "status": "queued",
            "created_at": utc_now(),
            "started_at": None,
            "ended_at": None,
            "config": config,
            "system": self.system,
            "captures": [capture],
            "scans": [],
            "analyses": [],
            "assets": [],
            "services": [],
            "findings": [],
            "summary": {},
            "artifacts": {"capture_source-1": str(destination)},
            "warnings": list(config["warnings"]),
            "errors": [],
        }
        session_dir_created = False
        try:
            with self._lock:
                self._ensure_accepting_sessions()
                session_dir.mkdir(parents=True, exist_ok=False)
                session_dir_created = True
                destination.parent.mkdir(parents=True, exist_ok=True)
                try:
                    os.replace(source_path, destination)
                except OSError:
                    shutil.move(str(source_path), str(destination))
                self._states[session_id] = state
                self._capture_stop[session_id] = threading.Event()
                self._scan_stop[session_id] = threading.Event()
                self._capture_processes[session_id] = {}
                self._scan_processes[session_id] = {}
                self._analysis_processes[session_id] = {}
                self._audit_hashes[session_id] = ""
                self._write_metadata(session_id, state)
                self._write_state_dict(state)
                self._audit(session_id, "capture_imported", {"original_filename": original_filename, "size_bytes": source_size})
                thread = threading.Thread(target=self._run_session, args=(session_id,), name=f"netscope-import-{session_id[:8]}", daemon=True)
                self._threads[session_id] = thread
                thread.start()
        except BaseException:
            with self._lock:
                self._states.pop(session_id, None)
                self._capture_stop.pop(session_id, None)
                self._scan_stop.pop(session_id, None)
                self._capture_processes.pop(session_id, None)
                self._scan_processes.pop(session_id, None)
                self._analysis_processes.pop(session_id, None)
                self._audit_hashes.pop(session_id, None)
                self._threads.pop(session_id, None)
            safe_to_remove_session_dir = session_dir_created
            if session_dir_created and not source_path.exists():
                safe_to_remove_session_dir = False
                if destination.exists():
                    try:
                        try:
                            os.replace(destination, source_path)
                        except OSError:
                            shutil.move(str(destination), str(source_path))
                    except OSError:
                        pass
                    else:
                        safe_to_remove_session_dir = True
            if safe_to_remove_session_dir and session_dir.parent == self.sessions_dir and session_dir.exists():
                shutil.rmtree(session_dir)
            raise
        return self.get_session(session_id)

    def _capture_command(self, source: dict[str, Any], capture: dict[str, Any], path: Path) -> list[str]:
        tools = self._system["tools"]
        requested_helper = source["interface"].get("capture_helper")
        executable = (
            tools.get(requested_helper or "", {}).get("path")
            or tools["dumpcap"]["path"]
            or tools["tshark"]["path"]
        )
        argv = [executable, "-q", "-i", str(source["interface"].get("capture_id")), "-w", str(path), "-B", "32"]
        if capture["duration_seconds"]:
            argv.extend(["-a", f"duration:{capture['duration_seconds']}"])
        if capture["max_file_mb"]:
            argv.extend(["-a", f"filesize:{capture['max_file_mb'] * 1024}"])
        if capture["packet_limit"]:
            argv.extend(["-c", str(capture["packet_limit"])])
        if capture["snaplen"]:
            argv.extend(["-s", str(capture["snaplen"])])
        if not capture["promiscuous"]:
            argv.append("-p")
        if capture["bpf_filter"]:
            argv.extend(["-f", capture["bpf_filter"]])
        return argv

    def _update_capture(self, session_id: str, capture_id: str, **changes: Any) -> None:
        with self._lock:
            row = next(item for item in self._states[session_id]["captures"] if item["id"] == capture_id)
            previous_status = row.get("status")
            row.update(changes)
            self._write_state_dict(self._states[session_id])
            if row.get("status") != previous_status:
                self._audit(
                    session_id,
                    "capture_status_changed",
                    {"capture_id": capture_id, "from": previous_status, "to": row.get("status"), "exit_code": row.get("exit_code"), "size_bytes": row.get("size_bytes")},
                )

    def _update_scan(self, session_id: str, updated: dict[str, Any]) -> None:
        with self._lock:
            rows = self._states[session_id]["scans"]
            previous_status = None
            for index, row in enumerate(rows):
                if row["id"] == updated["id"]:
                    previous_status = row.get("status")
                    rows[index] = updated
                    break
            self._write_state_dict(self._states[session_id])
            if updated.get("status") != previous_status:
                self._audit(
                    session_id,
                    "scan_status_changed",
                    {"scan_id": updated.get("id"), "profile": updated.get("profile"), "from": previous_status, "to": updated.get("status"), "exit_code": updated.get("exit_code")},
                )

    def _register_capture_process(self, session_id: str, capture_id: str, process: subprocess.Popen[Any] | None) -> None:
        terminate_late_process = False
        with self._lock:
            if process is None:
                self._capture_processes.get(session_id, {}).pop(capture_id, None)
            else:
                self._capture_processes.setdefault(session_id, {})[capture_id] = process
                terminate_late_process = self._closing
        if terminate_late_process:
            self._terminate_capture(process)

    def _register_scan_process(self, session_id: str, job_id: str, process: subprocess.Popen[Any] | None) -> None:
        terminate_late_process = False
        with self._lock:
            if process is None:
                self._scan_processes.get(session_id, {}).pop(job_id, None)
            else:
                self._scan_processes.setdefault(session_id, {})[job_id] = process
                terminate_late_process = self._closing
        if terminate_late_process:
            self._terminate_capture(process)

    def _register_analysis_process(self, session_id: str, analysis_id: str, process: subprocess.Popen[Any] | None) -> None:
        terminate_late_process = False
        with self._lock:
            if process is None:
                self._analysis_processes.get(session_id, {}).pop(analysis_id, None)
            else:
                self._analysis_processes.setdefault(session_id, {})[analysis_id] = process
                terminate_late_process = self._closing
        if terminate_late_process:
            self._terminate_capture(process)

    def _terminate_capture(self, process: subprocess.Popen[Any]) -> bool:
        if process.poll() is not None:
            return True
        try:
            process.terminate()
        except OSError:
            pass
        try:
            process.wait(timeout=5)
        except (OSError, subprocess.TimeoutExpired):
            if process.poll() is not None:
                return True
            try:
                process.kill()
                process.wait(timeout=5)
            except (OSError, subprocess.TimeoutExpired):
                return process.poll() is not None
        return process.poll() is not None

    def _session_processes(self, session_id: str) -> list[subprocess.Popen[Any]]:
        with self._lock:
            processes = [
                *self._capture_processes.get(session_id, {}).values(),
                *self._scan_processes.get(session_id, {}).values(),
                *self._analysis_processes.get(session_id, {}).values(),
            ]
        return list({id(process): process for process in processes}.values())

    def _quiesce_session(
        self,
        session_id: str,
        executor: concurrent.futures.ThreadPoolExecutor | None,
        capture_handles: dict[str, Any],
    ) -> tuple[list[str], bool]:
        errors: list[str] = []
        all_stopped = True
        with self._lock:
            capture_stop = self._capture_stop.get(session_id)
            scan_stop = self._scan_stop.get(session_id)
            if capture_stop is not None:
                capture_stop.set()
            if scan_stop is not None:
                scan_stop.set()

        for process in self._session_processes(session_id):
            try:
                if not self._terminate_capture(process):
                    all_stopped = False
                    errors.append(f"Process {getattr(process, 'pid', 'unknown')} did not stop")
            except Exception as exc:
                all_stopped = False
                errors.append(f"Process cleanup failed: {exc}")

        if executor is not None:
            try:
                executor.shutdown(wait=True, cancel_futures=True)
            except Exception as exc:
                all_stopped = False
                errors.append(f"Scan worker cleanup failed: {exc}")

        for process in self._session_processes(session_id):
            try:
                if not self._terminate_capture(process):
                    all_stopped = False
                    errors.append(f"Process {getattr(process, 'pid', 'unknown')} did not stop")
            except Exception as exc:
                all_stopped = False
                errors.append(f"Process cleanup failed: {exc}")

        for handle in list(capture_handles.values()):
            try:
                handle.close()
            except OSError as exc:
                all_stopped = False
                errors.append(f"Capture log cleanup failed: {exc}")
        capture_handles.clear()

        with self._lock:
            registries = (
                self._capture_processes.get(session_id, {}),
                self._scan_processes.get(session_id, {}),
                self._analysis_processes.get(session_id, {}),
            )
            for registry in registries:
                for process_id, process in list(registry.items()):
                    if process.poll() is None:
                        all_stopped = False
                    else:
                        registry.pop(process_id, None)
        return errors, all_stopped

    def _remove_partial_reports(self, session_dir: Path) -> list[str]:
        reports_dir = session_dir / "reports"
        if not reports_dir.is_dir():
            return []
        paths = {
            reports_dir / "report.json",
            reports_dir / "report.html",
            reports_dir / "assets.csv",
            reports_dir / "services.csv",
            reports_dir / "findings.csv",
            reports_dir / "topology-nodes.csv",
            reports_dir / "topology-flows.csv",
            reports_dir / "support-diagnostics.json",
            reports_dir / "sha256-manifest.txt",
            reports_dir / "reports-and-evidence.zip",
            *reports_dir.glob("report-*.html"),
        }
        errors: list[str] = []
        for path in paths:
            try:
                path.unlink(missing_ok=True)
            except OSError as exc:
                errors.append(f"Could not remove partial report {path.name}: {exc}")
        return errors

    def _run_session(self, session_id: str) -> None:
        state = self.get_session(session_id)
        config = state["config"]
        session_dir = self._session_dir(session_id)
        capture_handles: dict[str, Any] = {}
        executor: concurrent.futures.ThreadPoolExecutor | None = None
        reports_started = False
        quiesced = False
        try:
            self._set(session_id, status="starting", started_at=utc_now())
            capture_plan = [] if state.get("mode") == "import" else list(zip(config["sources"], state["captures"]))
            for source, capture_row in capture_plan:
                capture_path = Path(capture_row["path"])
                capture_path.parent.mkdir(parents=True, exist_ok=True)
                stderr_path = Path(capture_row["stderr_path"])
                stderr_handle = stderr_path.open("w", encoding="utf-8", errors="replace")
                capture_handles[capture_row["id"]] = stderr_handle
                argv = self._capture_command(source, config["capture"], capture_path)
                try:
                    process = subprocess.Popen(
                        argv,
                        stdin=subprocess.DEVNULL,
                        stdout=subprocess.DEVNULL,
                        stderr=stderr_handle,
                        creationflags=CREATE_NO_WINDOW,
                    )
                    self._register_capture_process(session_id, capture_row["id"], process)
                    self._update_capture(
                        session_id,
                        capture_row["id"],
                        status="running",
                        started_at=utc_now(),
                        pid=process.pid,
                        command_display=subprocess.list2cmdline(argv),
                    )
                except OSError as exc:
                    capture_handles.pop(capture_row["id"], None)
                    stderr_handle.close()
                    self._update_capture(session_id, capture_row["id"], status="failed", ended_at=utc_now(), error=str(exc))

            if capture_plan:
                time.sleep(0.8)
            with self._lock:
                capture_processes = list(self._capture_processes.get(session_id, {}).items())
            healthy_capture_sources = {
                capture_id
                for capture_id, process in capture_processes
                if process.poll() is None
            }
            scan_jobs = self.get_session(session_id)["scans"]
            worker_count = 1 if config.get("automotive_mode") else min(2, max(1, len(scan_jobs)))
            executor = concurrent.futures.ThreadPoolExecutor(max_workers=worker_count, thread_name_prefix="netscope-nmap")
            scan_futures: list[concurrent.futures.Future[Any]] = []
            for job in scan_jobs:
                if config["capture"]["enabled"] and job["source_id"] not in healthy_capture_sources:
                    skipped = {
                        **job,
                        "status": "skipped",
                        "ended_at": utc_now(),
                        "error": "Associated capture did not remain healthy through preflight; active scanning was not started",
                    }
                    self._update_scan(session_id, skipped)
                    continue
                scan_futures.append(
                    executor.submit(
                        run_scan_job,
                        job,
                        self._scan_stop[session_id],
                        lambda job_id, process, sid=session_id: self._register_scan_process(sid, job_id, process),
                        lambda updated, sid=session_id: self._update_scan(sid, updated),
                    )
                )

            while True:
                capture_running = False
                capture_stop = self._capture_stop[session_id].is_set()
                with self._lock:
                    capture_processes = list(self._capture_processes.get(session_id, {}).items())
                for capture_id, process in capture_processes:
                    path = Path(next(row["path"] for row in self.get_session(session_id)["captures"] if row["id"] == capture_id))
                    size = path.stat().st_size if path.exists() else 0
                    if process.poll() is None:
                        capture_running = True
                        self._update_capture(session_id, capture_id, size_bytes=size)
                        if capture_stop:
                            self._terminate_capture(process)
                    else:
                        stopped_by_user = capture_stop
                        status = "stopped" if stopped_by_user else ("completed" if process.returncode == 0 else "failed")
                        error = None if status != "failed" else f"Capture helper exited with code {process.returncode}; see stderr artifact"
                        self._update_capture(
                            session_id,
                            capture_id,
                            status=status,
                            ended_at=utc_now(),
                            exit_code=process.returncode,
                            pid=None,
                            size_bytes=size,
                            error=error,
                        )
                        self._register_capture_process(session_id, capture_id, None)
                        handle = capture_handles.pop(capture_id, None)
                        if handle:
                            handle.close()
                scans_running = any(not future.done() for future in scan_futures)
                if capture_running and scans_running:
                    status = "capturing-and-scanning"
                elif capture_running:
                    status = "stopping" if capture_stop else "capturing"
                elif scans_running:
                    status = "scanning"
                else:
                    break
                self._set(session_id, status=status)
                time.sleep(0.75)

            for future in scan_futures:
                try:
                    future.result()
                except Exception as exc:  # Defensive: preserve capture if a worker fails.
                    with self._lock:
                        self._states[session_id]["errors"].append(f"Scan worker error: {exc}")
            executor.shutdown(wait=True, cancel_futures=False)

            self._set(session_id, status="analyzing")
            tshark = self._system["tools"]["tshark"]["path"]
            analyses: list[dict[str, Any]] = []
            artifact_additions: dict[str, str] = {}
            current = self.get_session(session_id)
            for capture_row in current["captures"]:
                path = Path(capture_row["path"])
                if not tshark or not path.exists() or path.stat().st_size < 24:
                    if capture_row.get("status") != "failed":
                        with self._lock:
                            self._states[session_id]["warnings"].append(f"No analyzable capture data for {capture_row.get('source_alias')}")
                    continue
                source = next(item for item in config["sources"] if item["source_id"] == capture_row["source_id"])
                try:
                    analysis = analyze_capture(
                        tshark,
                        path,
                        include_vin_in_reports=config.get("include_vin_in_reports") is True,
                        privacy_context=session_id,
                        cancel_event=self._shutdown_event,
                        on_process=lambda process, sid=session_id, aid=source["source_id"]: self._register_analysis_process(sid, aid, process),
                    )
                    analysis_path = session_dir / "analysis" / f"{source['source_id']}.json"
                    analysis = self._write_analysis_result(session_id, analysis_path, analysis)
                    vlan_exports: dict[str, Any] = {}
                    observed_vlan_views: dict[int, dict[str, Any]] = {}
                    observed_vlan_ids = sorted(
                        int(value)
                        for value in analysis.get("vlan_partitions", {})
                        if str(value).isdigit() and 0 <= int(value) <= 4095
                    )
                    requested_vlan_ids = list(dict.fromkeys(source.get("vlan_ids", []) + observed_vlan_ids))
                    if len(requested_vlan_ids) > 128:
                        with self._lock:
                            self._states[session_id]["warnings"].append(
                                f"{source.get('alias')} exposed {len(requested_vlan_ids)} VLAN views; only the first 128 were split into individual PCAPNG files."
                            )
                        requested_vlan_ids = requested_vlan_ids[:128]
                    for vlan_id in requested_vlan_ids:
                        if str(vlan_id) not in analysis.get("vlan_partitions", {}):
                            continue
                        vlan_path = session_dir / "captures" / f"{source['source_id']}-vlan-{vlan_id}.pcapng"
                        vlan_analysis_id = f"{source['source_id']}-vlan-{vlan_id}"
                        export = split_vlan_capture(
                            tshark,
                            path,
                            vlan_id,
                            vlan_path,
                            cancel_event=self._shutdown_event,
                            on_process=lambda process, sid=session_id, aid=vlan_analysis_id: self._register_analysis_process(sid, aid, process),
                        )
                        vlan_exports[str(vlan_id)] = export
                        if export.get("ok"):
                            artifact_additions[f"capture_{source['source_id']}_vlan_{vlan_id}"] = export["path"]
                            try:
                                vlan_analysis = analyze_capture(
                                    tshark,
                                    vlan_path,
                                    packet_sample_limit=500,
                                    include_vin_in_reports=config.get("include_vin_in_reports") is True,
                                    privacy_context=session_id,
                                    cancel_event=self._shutdown_event,
                                    on_process=lambda process, sid=session_id, aid=vlan_analysis_id: self._register_analysis_process(sid, aid, process),
                                )
                                vlan_analysis_path = session_dir / "analysis" / f"{source['source_id']}-vlan-{vlan_id}.json"
                                vlan_analysis = self._write_analysis_result(
                                    session_id,
                                    vlan_analysis_path,
                                    vlan_analysis,
                                )
                                observed_vlan_views[vlan_id] = {
                                    "analysis": vlan_analysis,
                                    "analysis_path": str(vlan_analysis_path),
                                    "export_path": export.get("path"),
                                }
                                artifact_additions[f"analysis_{source['source_id']}_vlan_{vlan_id}"] = str(vlan_analysis_path)
                            except Exception as vlan_exc:
                                export["analysis_error"] = str(vlan_exc)
                                with self._lock:
                                    self._states[session_id]["warnings"].append(
                                        f"VLAN {vlan_id} analysis failed for {source.get('alias')}: {vlan_exc}"
                                    )
                    vlan_views, vlan_attribution, tag_preservation = build_vlan_views(
                        analysis,
                        source.get("vlan_ids", []),
                        observed_vlan_views,
                    )
                    if tag_preservation["assessment"] in {"not-observed", "sparse", "partial"} and source.get("vlan_ids"):
                        with self._lock:
                            self._states[session_id]["warnings"].append(
                                f"{source.get('alias')} retained {tag_preservation['tagged_frames']:,} "
                                f"802.1Q-tagged frames out of {tag_preservation['total_packets']:,}; "
                                "configured logical VLAN attribution is reported separately from packet-tag evidence."
                            )
                    if any(row.get("basis") == "unattributable" for row in vlan_attribution):
                        with self._lock:
                            self._states[session_id]["warnings"].append(
                                f"{source.get('alias')} has configured VLANs that cannot be attributed "
                                "because multiple logical VLANs share untagged or conflicting capture evidence."
                            )
                    analyses.append(
                        {
                            "source_id": source["source_id"],
                            "source_alias": source.get("alias"),
                            "role": source.get("role"),
                            "switch_port": source.get("switch_port"),
                            "interface": source.get("interface"),
                            "analysis": analysis,
                            "vlan_exports": vlan_exports,
                            "vlan_views": vlan_views,
                            "vlan_attribution": vlan_attribution,
                            "tag_preservation": tag_preservation,
                        }
                    )
                    artifact_additions[f"capture_{source['source_id']}"] = str(path)
                    artifact_additions[f"analysis_{source['source_id']}"] = str(analysis_path)
                except Exception as exc:
                    with self._lock:
                        self._states[session_id]["errors"].append(f"Analysis failed for {source.get('alias')}: {exc}")

            scan_records: list[dict[str, Any]] = []
            current = self.get_session(session_id)
            for job in current["scans"]:
                xml_path = Path(job["xml_path"])
                parsed = parse_nmap_xml(xml_path) if xml_path.exists() else {"path": str(xml_path), "hosts": [], "scan": {}, "parse_error": "No XML output"}
                scan_records.append(
                    {
                        "id": job["id"],
                        "source_id": job["source_id"],
                        "profile": job["profile"],
                        "family": job["family"],
                        "status": job["status"],
                        "started_at": job.get("started_at"),
                        "ended_at": job.get("ended_at"),
                        "exit_code": job.get("exit_code"),
                        "parsed": parsed,
                    }
                )
                if xml_path.exists():
                    artifact_additions[f"nmap_{job['id']}_xml"] = str(xml_path)
                normal_path = Path(job["normal_path"])
                if normal_path.exists():
                    artifact_additions[f"nmap_{job['id']}_text"] = str(normal_path)

            assets, services = build_inventory(scan_records)
            include_vin = config.get("include_vin_in_reports") is True
            assets = sanitize_vin_data(assets, session_id, include_plaintext=include_vin)
            services = sanitize_vin_data(services, session_id, include_plaintext=include_vin)
            findings = build_findings(config, analyses, services)
            findings = sanitize_vin_data(findings, session_id, include_plaintext=include_vin)
            test_cases = evaluate_test_cases(
                config,
                analyses,
                services,
                findings,
                captures=current.get("captures", []),
                scans=scan_records,
            )
            with self._lock:
                state_ref = self._states[session_id]
                state_ref["analyses"] = analyses
                state_ref["assets"] = assets
                state_ref["services"] = services
                state_ref["findings"] = findings
                state_ref["test_cases"] = test_cases
                state_ref["artifacts"].update(artifact_additions)
                self._write_state_dict(state_ref)

            self._set(session_id, status="reporting")
            current = self.get_session(session_id)
            has_failures = bool(current["errors"]) or any(row.get("status") == "failed" for row in current["captures"] + current["scans"])
            final_status = "completed-with-errors" if has_failures else "completed"
            final_ended_at = utc_now()
            final_summary = {
                "packets": sum((row.get("analysis") or {}).get("packets", 0) for row in analyses),
                "bytes": sum((row.get("analysis") or {}).get("bytes", 0) for row in analyses),
                "assets": len(assets),
                "open_services": len([row for row in services if row.get("state") == "open"]),
                "findings": len(findings),
                "findings_by_severity": severity_counts(findings),
            }
            report_state = copy.deepcopy(current)
            report_state["status"] = final_status
            report_state["ended_at"] = final_ended_at
            report_state["summary"] = final_summary
            reports_started = True
            _, report_artifacts = generate_reports(session_dir, report_state, analyses, scan_records, assets, services, findings)
            with self._lock:
                final = self._states[session_id]
                final["artifacts"].update(report_artifacts)
                final["ended_at"] = final_ended_at
                final["status"] = final_status
                final["summary"] = final_summary
                self._write_state_dict(final)
                self._audit(session_id, "session_completed", {"status": final_status, "summary": final_summary})
            refresh_evidence_bundle(session_dir)
        except Exception as exc:
            cleanup_errors, evidence_safe = self._quiesce_session(session_id, executor, capture_handles)
            quiesced = True
            if reports_started:
                cleanup_errors.extend(self._remove_partial_reports(session_dir))
            manifest_path = session_dir / "reports" / "sha256-manifest.txt"
            bundle_path = session_dir / "reports" / "reports-and-evidence.zip"
            with self._lock:
                failed = self._states[session_id]
                failed["status"] = "failed"
                failed["ended_at"] = utc_now()
                failed["errors"].append(str(exc))
                failed["errors"].extend(cleanup_errors)
                if reports_started:
                    for key in list(failed["artifacts"]):
                        if key in {
                            "assets_csv",
                            "services_csv",
                            "findings_csv",
                            "topology_nodes_csv",
                            "topology_flows_csv",
                            "support_diagnostics_json",
                        } or key.startswith("report_"):
                            failed["artifacts"].pop(key, None)
                if evidence_safe:
                    failed["artifacts"].update(
                        {
                            "sha256_manifest": str(manifest_path),
                            "evidence_bundle": str(bundle_path),
                        }
                    )
                else:
                    failed["artifacts"].pop("sha256_manifest", None)
                    failed["artifacts"].pop("evidence_bundle", None)
                    failed["errors"].append("Evidence bundle was not refreshed because child processes did not stop")
                self._write_state_dict(failed)
                self._audit(session_id, "session_failed", {"error": str(exc)})
            if evidence_safe:
                try:
                    refresh_evidence_bundle(session_dir)
                except Exception as evidence_exc:  # Preserve the original failure even if packaging also fails.
                    with self._lock:
                        failed = self._states[session_id]
                        failed["errors"].append(f"Evidence bundle generation failed: {evidence_exc}")
                        self._write_state_dict(failed)
                        self._audit(session_id, "evidence_bundle_failed", {"error": str(evidence_exc)})
        finally:
            if not quiesced:
                self._quiesce_session(session_id, executor, capture_handles)

    def stop_capture(self, session_id: str) -> dict[str, Any]:
        with self._lock:
            if session_id not in self._states:
                raise KeyError("Unknown session")
            if self._states[session_id].get("status") not in ACTIVE_STATES:
                raise ValidationError("The capture is not active")
            self._capture_stop[session_id].set()
            self._states[session_id]["status"] = "stopping"
            self._write_state_dict(self._states[session_id])
            self._audit(session_id, "capture_stop_requested")
        return self.get_session(session_id)

    def cancel_scans(self, session_id: str) -> dict[str, Any]:
        with self._lock:
            if session_id not in self._states:
                raise KeyError("Unknown session")
            self._scan_stop[session_id].set()
            self._audit(session_id, "scan_cancel_requested")
        return self.get_session(session_id)

    def artifact_path(self, session_id: str, artifact_key: str) -> Path:
        state = self.get_session(session_id)
        value = state.get("artifacts", {}).get(artifact_key)
        if not value:
            raise KeyError("Unknown artifact")
        session_dir = self._session_dir(session_id)
        recorded = Path(value)
        path = (recorded if recorded.is_absolute() else session_dir / recorded).resolve()
        if session_dir in path.parents and path.is_file():
            return path

        # Evidence folders are often copied to an analyst workstation or case
        # repository. Older state files record absolute paths, so rebase only a
        # well-known artifact-relative suffix and never modify the evidence.
        artifact_roots = {"captures", "nmap", "analysis", "reports"}
        parts = recorded.parts
        for index in range(len(parts) - 1, -1, -1):
            if parts[index].lower() not in artifact_roots:
                continue
            rebased = (session_dir / Path(*parts[index:])).resolve()
            if session_dir in rebased.parents and rebased.is_file():
                return rebased
            break
        raise KeyError("Artifact is unavailable")

    def shutdown(self) -> None:
        with self._lock:
            self._closing = True
            self._shutdown_event.set()
            session_ids = list(self._threads)
            for session_id in session_ids:
                self._capture_stop.get(session_id, threading.Event()).set()
                self._scan_stop.get(session_id, threading.Event()).set()
            capture_processes = [
                process
                for processes in self._capture_processes.values()
                for process in processes.values()
            ]
            scan_processes = [
                process
                for processes in self._scan_processes.values()
                for process in processes.values()
            ]
            analysis_processes = [
                process
                for processes in self._analysis_processes.values()
                for process in processes.values()
            ]
        for process in capture_processes + scan_processes + analysis_processes:
            if process.poll() is None:
                try:
                    process.terminate()
                except OSError:
                    pass
        deadline = time.monotonic() + 8
        for session_id in session_ids:
            thread = self._threads.get(session_id)
            if thread and thread.is_alive():
                thread.join(timeout=max(0, deadline - time.monotonic()))
        with self._lock:
            for session_id in session_ids:
                thread = self._threads.get(session_id)
                state = self._states.get(session_id)
                if thread and thread.is_alive() and state and state.get("status") in ACTIVE_STATES:
                    state["status"] = "interrupted"
                    state["ended_at"] = utc_now()
                    state.setdefault("errors", []).append("Application shutdown interrupted active work; completed evidence was preserved.")
                    self._write_state_dict(state)
                    self._audit(session_id, "session_interrupted", {"reason": "application shutdown timeout"})
