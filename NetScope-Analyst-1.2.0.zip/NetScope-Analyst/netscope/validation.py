"""Input validation and defensive scope controls."""

from __future__ import annotations

import ipaddress
import platform
import re
from typing import Any


class ValidationError(ValueError):
    pass


LOCAL_V4 = tuple(ipaddress.ip_network(value) for value in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "127.0.0.0/8", "169.254.0.0/16"))
LOCAL_V6 = tuple(ipaddress.ip_network(value) for value in ("fc00::/7", "fe80::/10", "::1/128"))
PROFILE_NAMES = {
    "host_discovery",
    "quick_tcp",
    "standard_tcp",
    "full_tcp",
    "full_tcp_services",
    "quick_udp",
    "full_udp",
    "service_detection",
    "os_detection",
    "automotive_discovery",
    "safe_enumeration",
    "vulnerability_checks",
}
HIGH_IMPACT_PROFILES = {"full_tcp", "full_tcp_services", "quick_udp", "full_udp", "service_detection", "os_detection", "safe_enumeration", "vulnerability_checks"}
INTRUSIVE_PROFILES = {"vulnerability_checks"}


def clean_text(value: Any, maximum: int = 500) -> str:
    text = str(value or "").replace("\x00", "").strip()
    if len(text) > maximum:
        raise ValidationError(f"Text value exceeds {maximum} characters")
    if any(ord(char) < 32 and char not in "\t\r\n" for char in text):
        raise ValidationError("Control characters are not allowed")
    return text


def parse_int(value: Any, name: str, minimum: int, maximum: int) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError) as exc:
        raise ValidationError(f"{name} must be an integer") from exc
    if not minimum <= number <= maximum:
        raise ValidationError(f"{name} must be between {minimum} and {maximum}")
    return number


def parse_bool(value: Any, name: str, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    raise ValidationError(f"{name} must be a JSON boolean")


def parse_ports(value: Any) -> list[int]:
    if value in (None, "", []):
        return []
    tokens = value if isinstance(value, list) else re.split(r"[\s,;]+", str(value).strip())
    result: set[int] = set()
    for token in tokens:
        if token in (None, ""):
            continue
        number = parse_int(token, "port", 0, 65535)
        result.add(number)
    return sorted(result)


def parse_vlan_ids(value: Any) -> list[int]:
    if value in (None, "", []):
        return []
    tokens = value if isinstance(value, list) else re.split(r"[\s,;]+", str(value).strip())
    return sorted({parse_int(token, "VLAN ID", 0, 4095) for token in tokens if token not in (None, "")})


def _is_local_network(network: ipaddress._BaseNetwork) -> bool:
    pools = LOCAL_V4 if network.version == 4 else LOCAL_V6
    return any(network.subnet_of(pool) for pool in pools)


_ZONE_ID = re.compile(r"[A-Za-z0-9_.-]{1,64}")


def _interface_ipv6_zone(interface: dict[str, Any]) -> str | None:
    for entry in interface.get("addresses", []):
        value = str(entry.get("address") or "")
        if entry.get("family") == "IPv6" and "%" in value:
            zone = value.rsplit("%", 1)[1]
            if _ZONE_ID.fullmatch(zone):
                return zone
    if platform.system() == "Windows" and interface.get("if_index") is not None:
        return str(interface["if_index"])
    name = str(interface.get("name") or "")
    return name if _ZONE_ID.fullmatch(name) else None


def _scope_link_local_targets(targets: list[str], interface: dict[str, Any], bind_interface: bool) -> list[str]:
    scoped: list[str] = []
    zone = _interface_ipv6_zone(interface)
    for target in targets:
        network = ipaddress.ip_network(target, strict=False)
        address = network.network_address
        if network.version != 6 or not address.is_link_local:
            scoped.append(target)
            continue
        if not bind_interface:
            raise ValidationError("IPv6 link-local targets require interface binding so their zone and evidence source are unambiguous")
        supplied_zone = getattr(address, "scope_id", None)
        if not zone:
            raise ValidationError("The selected interface has no usable IPv6 zone ID for a link-local target")
        if supplied_zone and str(supplied_zone).casefold() != zone.casefold():
            raise ValidationError(f"IPv6 link-local target zone %{supplied_zone} does not match selected interface zone %{zone}")
        scoped.append(target if supplied_zone else f"{address.compressed}%{zone}")
    return scoped


def _attribution_scopes_overlap(left: ipaddress._BaseNetwork, right: ipaddress._BaseNetwork) -> bool:
    if left.version != right.version or not left.overlaps(right):
        return False
    if left.version == 6 and left.network_address.is_link_local and right.network_address.is_link_local:
        left_zone = getattr(left.network_address, "scope_id", None)
        right_zone = getattr(right.network_address, "scope_id", None)
        if left_zone and right_zone and str(left_zone).casefold() != str(right_zone).casefold():
            return False
    return True


def _network_parts(value: str) -> tuple[ipaddress._BaseNetwork, str | None]:
    """Return an unscoped network plus an optional IPv6 zone identifier."""
    text = str(value)
    zone: str | None = None
    if "%" in text:
        address, scoped_suffix = text.rsplit("%", 1)
        if "/" in scoped_suffix:
            zone, prefix = scoped_suffix.split("/", 1)
            text = f"{address}/{prefix}"
        else:
            zone = scoped_suffix
            text = address
    return ipaddress.ip_network(text, strict=False), zone


def _zones_compatible(
    left: ipaddress._BaseNetwork,
    left_zone: str | None,
    right: ipaddress._BaseNetwork,
    right_zone: str | None,
) -> bool:
    if left.version != 6 or not left.network_address.is_link_local or not right.network_address.is_link_local:
        return True
    return not (left_zone and right_zone and left_zone.casefold() != right_zone.casefold())


def _exclusion_applies(target: str, exclusion: str) -> bool:
    target_network, target_zone = _network_parts(target)
    exclusion_network, exclusion_zone = _network_parts(exclusion)
    return (
        target_network.version == exclusion_network.version
        and _zones_compatible(target_network, target_zone, exclusion_network, exclusion_zone)
        and target_network.overlaps(exclusion_network)
    )


def _network_fully_excluded(target: str, exclusions: list[str]) -> bool:
    target_network, target_zone = _network_parts(target)
    remaining = [target_network]
    for exclusion in exclusions:
        exclusion_network, exclusion_zone = _network_parts(exclusion)
        if exclusion_network.version != target_network.version:
            continue
        if not _zones_compatible(target_network, target_zone, exclusion_network, exclusion_zone):
            continue
        next_remaining: list[ipaddress._BaseNetwork] = []
        for network in remaining:
            if not network.overlaps(exclusion_network):
                next_remaining.append(network)
            elif network.subnet_of(exclusion_network):
                continue
            elif exclusion_network.subnet_of(network):
                next_remaining.extend(network.address_exclude(exclusion_network))
            else:  # CIDR networks of the same family cannot partially overlap.
                next_remaining.append(network)
        remaining = next_remaining
        if not remaining:
            return True
    return False


def _protected_host_value(value: Any, interface: dict[str, Any]) -> str | None:
    text = str(value or "").strip()
    if not text:
        return None
    supplied_zone: str | None = None
    address_text = text
    if "%" in text:
        address_text, supplied_zone = text.rsplit("%", 1)
    try:
        address = ipaddress.ip_address(address_text)
    except ValueError:
        return None
    if address.is_unspecified or address.is_multicast:
        return None
    if address.version == 6 and address.is_link_local:
        zone = supplied_zone or _interface_ipv6_zone(interface)
        return f"{address.compressed}%{zone}" if zone else None
    return address.compressed


def _automatic_protected_exclusions(
    interface_inventory: list[dict[str, Any]],
) -> tuple[list[str], list[dict[str, Any]]]:
    exclusions: list[str] = []
    details: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()
    for interface in interface_inventory:
        interface_id = str(interface.get("id") or "")
        interface_name = str(interface.get("name") or interface.get("capture_description") or interface_id)
        protected: list[tuple[str, Any]] = [
            ("host-interface-address", row.get("address"))
            for row in interface.get("addresses", [])
            if isinstance(row, dict)
        ]
        protected.extend(("default-gateway", value) for value in interface.get("gateways", []))
        for reason, raw_value in protected:
            value = _protected_host_value(raw_value, interface)
            if not value:
                continue
            if value not in exclusions:
                exclusions.append(value)
            detail_key = (value.casefold(), reason, interface_id.casefold())
            if detail_key in seen:
                continue
            seen.add(detail_key)
            details.append(
                {
                    "target": value,
                    "reason": reason,
                    "interface_id": interface_id,
                    "interface_name": interface_name,
                }
            )
    return exclusions, details


def _relevant_exclusions(targets: list[str], exclusions: list[str]) -> list[str]:
    return [value for value in exclusions if any(_exclusion_applies(target, value) for target in targets)]


def _verified_scan_link(interface: dict[str, Any]) -> bool:
    return str(interface.get("status") or "").strip().lower() in {"up", "connected"}


def _route_prefixes(interface: dict[str, Any]) -> list[ipaddress._BaseNetwork]:
    values: list[Any] = list(interface.get("networks", []))
    values.extend(
        row.get("destination_prefix")
        for row in interface.get("routes", [])
        if isinstance(row, dict) and row.get("destination_prefix")
    )
    result: list[ipaddress._BaseNetwork] = []
    for value in values:
        try:
            network, _ = _network_parts(str(value))
        except ValueError:
            continue
        if network not in result:
            result.append(network)
    return result


def _verify_selected_interface_routes(
    targets: list[str],
    selected_interface: dict[str, Any],
    interface_inventory: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    if not _verified_scan_link(selected_interface):
        raise ValidationError(
            f"Selected scan interface {selected_interface.get('name') or selected_interface.get('id')} "
            "is not positively reported Up/Connected"
        )
    selected_networks: list[ipaddress._BaseNetwork] = []
    for value in selected_interface.get("networks", []):
        try:
            network, _ = _network_parts(str(value))
            selected_networks.append(network)
        except ValueError:
            continue
    proofs: list[dict[str, Any]] = []
    selected_id = str(selected_interface.get("id") or "")
    for target in targets:
        target_network, target_zone = _network_parts(target)
        matching = [
            network
            for network in selected_networks
            if network.version == target_network.version and target_network.subnet_of(network)
        ]
        if not matching:
            raise ValidationError(
                f"Bound target {target} is not inside a directly connected prefix on "
                f"{selected_interface.get('name') or selected_id}"
            )
        connected = max(matching, key=lambda network: network.prefixlen)
        for candidate in interface_inventory:
            candidate_id = str(candidate.get("id") or "")
            if candidate_id == selected_id:
                continue
            candidate_status = str(candidate.get("status") or "").strip().lower()
            if candidate_status in {"down", "disabled", "disconnected", "not present", "dormant"}:
                continue
            if target_network.version == 6 and target_network.network_address.is_link_local:
                candidate_zone = _interface_ipv6_zone(candidate)
                if target_zone and candidate_zone and target_zone.casefold() != candidate_zone.casefold():
                    continue
            for route in _route_prefixes(candidate):
                if (
                    route.version == target_network.version
                    and route.prefixlen >= connected.prefixlen
                    and route.overlaps(target_network)
                ):
                    raise ValidationError(
                        f"Route for {target} is ambiguous: {candidate.get('name') or candidate_id} "
                        f"also owns overlapping prefix {route}. Disable the competing route/interface "
                        "or use narrower verified targets."
                    )
        proofs.append(
            {
                "target": target,
                "verified": True,
                "method": "direct-prefix-without-equal-or-more-specific-competing-route",
                "interface_id": selected_id,
                "interface_name": selected_interface.get("name") or selected_interface.get("capture_description"),
                "if_index": selected_interface.get("if_index"),
                "nmap_interface": selected_interface.get("nmap_name"),
                "connected_prefix": str(connected),
            }
        )
    return proofs


def parse_targets(
    value: Any,
    *,
    allow_public: bool = False,
    allow_large: bool = False,
    maximum_addresses: int = 4096,
    allow_loopback: bool = False,
) -> tuple[list[str], list[str], int]:
    raw = value if isinstance(value, list) else re.split(r"[\s,;]+", str(value or "").strip())
    targets: list[str] = []
    warnings: list[str] = []
    total = 0
    for token_value in raw:
        token = clean_text(token_value, 160)
        if not token:
            continue
        if token.startswith("-"):
            raise ValidationError(f"Unsupported target syntax: {token}")
        try:
            network = ipaddress.ip_network(token, strict=False)
        except ValueError as exc:
            raise ValidationError(f"Targets must be literal IP addresses or CIDRs: {token}") from exc
        if network.prefixlen == 0:
            raise ValidationError("A /0 target is never accepted")
        scope_id = getattr(network.network_address, "scope_id", None)
        if scope_id is not None and (
            network.version != 6
            or not network.network_address.is_link_local
            or network.prefixlen != 128
            or not _ZONE_ID.fullmatch(str(scope_id))
        ):
            raise ValidationError(f"Unsupported IPv6 zone syntax: {token}")
        if network.version == 6 and network.network_address.is_link_local and network.prefixlen != 128:
            raise ValidationError("IPv6 link-local targets must be individual addresses, not CIDR ranges")
        loopback = ipaddress.ip_network("127.0.0.0/8") if network.version == 4 else ipaddress.ip_network("::1/128")
        if not allow_loopback and network.overlaps(loopback):
            raise ValidationError(f"Loopback targets would scan this host and are not allowed: {token}")
        if network.network_address.is_multicast or network.network_address.is_unspecified:
            raise ValidationError(f"Multicast or unspecified target is not allowed: {token}")
        if network.version == 4 and network.broadcast_address.is_multicast:
            raise ValidationError(f"Multicast target is not allowed: {token}")
        if not _is_local_network(network):
            if not allow_public:
                raise ValidationError(f"Non-local target requires explicit public-scope opt-in: {token}")
            warnings.append(f"Non-local scope explicitly enabled for {network}")
        count = int(network.num_addresses)
        total += count
        normalized = str(network.network_address) if network.prefixlen == network.max_prefixlen else str(network)
        if normalized not in targets:
            targets.append(normalized)
    if total > maximum_addresses and not allow_large:
        raise ValidationError(f"Scope contains {total:,} addresses; explicit large-scope opt-in is required above {maximum_addresses:,}")
    if total > maximum_addresses:
        warnings.append(f"Large scope explicitly enabled: {total:,} addresses")
    if sum(len(target) + 1 for target in targets) > 12_000:
        raise ValidationError("Target list is too long for reliable Windows process execution; combine addresses into approved CIDRs")
    return targets, warnings, total


def _parse_known_target_provenance(
    value: Any,
    targets: list[str],
    configured_vlans: list[int],
    effective_exclusions: list[str],
) -> list[dict[str, Any]]:
    """Validate sanitized provenance emitted by the ifconfig preview helper.

    Provenance never expands scan scope: every address must already be covered by
    the independently validated target list.
    """

    if value in (None, "", []):
        return []
    if not isinstance(value, list) or len(value) > 512:
        raise ValidationError("Known ECU target provenance must be a list of at most 512 rows")
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    target_networks = [_network_parts(target)[0] for target in targets]
    for row in value:
        if not isinstance(row, dict):
            raise ValidationError("Each known ECU target provenance row must be an object")
        raw_address = clean_text(row.get("address"), 160)
        if not raw_address or "/" in raw_address or "%" in raw_address:
            raise ValidationError("Known ECU target provenance must contain exact unscoped host addresses")
        try:
            address = ipaddress.ip_address(raw_address)
        except ValueError as exc:
            raise ValidationError(f"Known ECU target provenance contains an invalid address: {raw_address}") from exc
        if address.is_loopback or address.is_unspecified or address.is_multicast:
            raise ValidationError("Known ECU target provenance contains a non-scannable host address")
        if address.version == 6 and address.is_link_local:
            raise ValidationError("ECU-scoped IPv6 link-local addresses cannot be imported as known targets")
        normalized = address.compressed
        key = normalized.casefold()
        if key in seen:
            continue
        if not any(network.version == address.version and address in network for network in target_networks):
            raise ValidationError(
                f"Known ECU target {normalized} is not covered by this source's validated scan targets"
            )
        protected_by = [
            exclusion
            for exclusion in effective_exclusions
            if _network_fully_excluded(normalized, [exclusion])
        ]
        if protected_by:
            raise ValidationError(
                f"Known ECU target {normalized} conflicts with a protected host, gateway, or manual exclusion; "
                "the exclusion remains enforced and this plan cannot start"
            )
        vlan_raw = row.get("vlan_id")
        vlan_id = None if vlan_raw in (None, "") else parse_int(vlan_raw, "known target VLAN ID", 0, 4095)
        if vlan_id is not None and vlan_id not in configured_vlans:
            raise ValidationError(
                f"Known ECU target VLAN {vlan_id} is not configured on this selected source"
            )
        mapping_basis = clean_text(row.get("mapping_basis") or "explicit-source", 40)
        if mapping_basis not in {"explicit-source", "unique-vlan-match"}:
            raise ValidationError("Unsupported known ECU target mapping basis")
        prefix_raw = row.get("prefix_length")
        prefix_length = None
        network_text = None
        broadcast_text = None
        if prefix_raw not in (None, ""):
            prefix_length = parse_int(
                prefix_raw,
                "known target prefix length",
                0,
                32 if address.version == 4 else 128,
            )
            reported_network = ipaddress.ip_network(
                f"{normalized}/{prefix_length}",
                strict=False,
            )
            network_text = reported_network.network_address.compressed
            if address.version == 4:
                broadcast_text = reported_network.broadcast_address.compressed
        result.append(
            {
                "address": normalized,
                "family": f"IPv{address.version}",
                "ecu_interface": clean_text(row.get("ecu_interface"), 64),
                "vlan_id": vlan_id,
                "prefix_length": prefix_length,
                "reported_network": network_text,
                "reported_broadcast": broadcast_text,
                "prefix_conflict": parse_bool(
                    row.get("prefix_conflict"),
                    "known target prefix-conflict flag",
                    False,
                ),
                "scope_safety_note": (
                    "prefix-conflict; exact-host only; subnet expansion prohibited"
                    if parse_bool(
                        row.get("prefix_conflict"),
                        "known target prefix-conflict flag",
                        False,
                    )
                    else "exact-host only"
                ),
                "mapping_basis": mapping_basis,
                "excluded_by_protection": False,
            }
        )
        seen.add(key)
    return result


def validate_session_config(raw: dict[str, Any], interface_inventory: list[dict[str, Any]]) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise ValidationError("Request body must be an object")
    automotive_mode = parse_bool(raw.get("automotive_mode"), "automotive mode", True)
    inventory = {item["id"]: item for item in interface_inventory}
    source_rows = raw.get("sources")
    if not isinstance(source_rows, list) or not source_rows:
        raise ValidationError("Select at least one interface")
    if len(source_rows) > 32:
        raise ValidationError("At most 32 capture sources are allowed per session")

    capture_raw = raw.get("capture") if isinstance(raw.get("capture"), dict) else {}
    capture_enabled = parse_bool(capture_raw.get("enabled"), "capture enabled", True)
    capture = {
        "enabled": capture_enabled,
        "duration_seconds": parse_int(capture_raw.get("duration_seconds", 300), "duration", 0, 86400),
        "max_file_mb": parse_int(capture_raw.get("max_file_mb", 512), "maximum capture size", 0, 32768),
        "packet_limit": parse_int(capture_raw.get("packet_limit", 0), "packet limit", 0, 2_000_000_000),
        "snaplen": parse_int(capture_raw.get("snaplen", 0), "snap length", 0, 262144),
        "promiscuous": parse_bool(capture_raw.get("promiscuous"), "promiscuous mode", True),
        "bpf_filter": clean_text(capture_raw.get("bpf_filter"), 1000),
    }
    if capture_enabled and capture["duration_seconds"] == 0 and capture["max_file_mb"] == 0 and capture["packet_limit"] == 0:
        raise ValidationError("An unlimited capture needs a duration, file-size ceiling, or packet limit")

    scan_raw = raw.get("scan") if isinstance(raw.get("scan"), dict) else {}
    scan_enabled = parse_bool(scan_raw.get("enabled"), "scan enabled", False)
    authorized = parse_bool(scan_raw.get("authorized"), "scan authorization", False)
    if scan_enabled and not authorized:
        raise ValidationError("Active scanning requires authorization acknowledgement")
    profiles = scan_raw.get("profiles", ["automotive_discovery"] if automotive_mode else ["host_discovery"])
    if not isinstance(profiles, list) or not profiles:
        profiles = []
    if not all(isinstance(profile, str) for profile in profiles):
        raise ValidationError("Scan profiles must be strings")
    unknown = set(profiles) - PROFILE_NAMES
    if unknown:
        raise ValidationError(f"Unknown scan profiles: {', '.join(sorted(unknown))}")
    profiles = list(dict.fromkeys(profiles))
    if scan_enabled and not profiles:
        raise ValidationError("Select at least one active scan profile")
    allow_high_impact = parse_bool(scan_raw.get("allow_high_impact"), "high-impact scan opt-in", False)
    if scan_enabled and set(profiles) & HIGH_IMPACT_PROFILES and not allow_high_impact:
        raise ValidationError("Selected scan profiles require high-impact scan opt-in")
    allow_intrusive = parse_bool(scan_raw.get("allow_intrusive"), "intrusive-check opt-in", False)
    if set(profiles) & INTRUSIVE_PROFILES and not allow_intrusive:
        raise ValidationError("Vulnerability checks require the separate intrusive-check opt-in")
    allow_public = parse_bool(scan_raw.get("allow_public"), "public-scope opt-in", False)
    allow_large = parse_bool(scan_raw.get("allow_large"), "large-scope opt-in", False)
    include_port_zero = parse_bool(scan_raw.get("include_port_zero"), "port-zero opt-in", False)
    max_rate = parse_int(scan_raw.get("max_rate", 50 if automotive_mode else 500), "maximum scan rate", 1, 100000)
    timing = parse_int(scan_raw.get("timing", 2 if automotive_mode else 3), "Nmap timing", 0, 5)

    exclusions, exclusion_warnings, _ = parse_targets(
        scan_raw.get("exclusions", []),
        allow_public=True,
        allow_large=True,
        maximum_addresses=2**32,
        allow_loopback=True,
    ) if scan_raw.get("exclusions") else ([], [], 0)
    automatic_exclusions, automatic_exclusion_details = _automatic_protected_exclusions(interface_inventory)
    effective_exclusions = list(dict.fromkeys([*exclusions, *automatic_exclusions]))

    sources: list[dict[str, Any]] = []
    seen_interfaces: set[str] = set()
    all_warnings: list[str] = list(exclusion_warnings)
    for position, row in enumerate(source_rows):
        if not isinstance(row, dict):
            raise ValidationError("Each source must be an object")
        interface_id = clean_text(row.get("interface_id"), 200)
        if interface_id not in inventory:
            raise ValidationError(f"Interface is no longer available: {interface_id}")
        if interface_id in seen_interfaces:
            raise ValidationError("Select each physical/OS interface once and list all of its VLAN views in that source")
        seen_interfaces.add(interface_id)
        interface = inventory[interface_id]
        bind_interface = parse_bool(row.get("bind_interface"), "interface binding", True)
        if scan_enabled and automotive_mode and not bind_interface:
            raise ValidationError(
                f"Automotive scanning requires verified binding to the selected interface: "
                f"{interface.get('name') or interface_id}"
            )
        if capture_enabled and not interface.get("capture_ready"):
            raise ValidationError(f"Interface is not capture-ready: {interface.get('name') or interface_id}")
        configured_vlans = parse_vlan_ids(row.get("vlan_ids"))
        targets: list[str] = []
        target_count = 0
        known_targets: list[dict[str, Any]] = []
        scan_plan: dict[str, Any] = {
            "targets": [],
            "known_targets": [],
            "manual_exclusions": [],
            "automatic_exclusions": [],
            "effective_exclusions": [],
            "route_verification": [],
        }
        if scan_enabled:
            targets, warnings, target_count = parse_targets(
                row.get("targets", []),
                allow_public=allow_public,
                allow_large=allow_large,
            )
            targets = _scope_link_local_targets(targets, interface, bind_interface)
            all_warnings.extend(warnings)
            if not targets:
                raise ValidationError(f"Active scan targets are missing for {interface.get('name') or interface_id}")
            if bind_interface and not interface.get("scan_ready"):
                raise ValidationError(
                    f"{interface.get('name') or interface_id} is not positively verified scan-ready; "
                    "use capture-only mode until link and route state are confirmed"
                )
            if bind_interface and not _verified_scan_link(interface):
                raise ValidationError(
                    f"{interface.get('name') or interface_id} is not positively reported Up/Connected"
                )
            if automotive_mode and platform.system() == "Windows" and not interface.get("nmap_name"):
                raise ValidationError(
                    f"Nmap could not verify its interface mapping for {interface.get('name') or interface_id}"
                )
            route_verification: list[dict[str, Any]] = []
            if bind_interface:
                route_verification = _verify_selected_interface_routes(targets, interface, interface_inventory)
            relevant_manual = _relevant_exclusions(targets, exclusions)
            relevant_automatic = _relevant_exclusions(targets, automatic_exclusions)
            relevant_effective = list(dict.fromkeys([*relevant_manual, *relevant_automatic]))
            known_targets = _parse_known_target_provenance(
                row.get("known_targets"),
                targets,
                configured_vlans,
                relevant_effective,
            )
            fully_excluded = [
                target for target in targets if _network_fully_excluded(target, relevant_effective)
            ]
            if fully_excluded:
                raise ValidationError(
                    "Target scope is entirely protected/excluded and would not be scanned: "
                    + ", ".join(fully_excluded)
                )
            scan_plan = {
                "targets": list(targets),
                "known_targets": known_targets,
                "target_count": target_count,
                "manual_exclusions": relevant_manual,
                "automatic_exclusions": relevant_automatic,
                "effective_exclusions": relevant_effective,
                "route_verification": route_verification,
            }
        sources.append(
            {
                "source_id": f"source-{position + 1}",
                "interface_id": interface_id,
                "interface": interface,
                "alias": clean_text(row.get("alias") or interface.get("name") or f"Interface {position + 1}", 120),
                "role": clean_text(row.get("role"), 240),
                "switch_port": clean_text(row.get("switch_port"), 120),
                "vlan_ids": configured_vlans,
                "targets": targets,
                "target_count": target_count,
                "known_targets": known_targets,
                "bind_interface": bind_interface,
                "scan_plan": scan_plan,
                "expected_ports": parse_ports(row.get("expected_ports")),
            }
        )

    if scan_enabled:
        aggregate_target_count = sum(int(source.get("target_count", 0)) for source in sources)
        if aggregate_target_count > 4096 and not allow_large:
            raise ValidationError(
                f"Combined session scope contains {aggregate_target_count:,} address attempts; large-scope opt-in is required above 4,096"
            )
        if aggregate_target_count > 4096:
            all_warnings.append(f"Large combined session scope explicitly enabled: {aggregate_target_count:,} address attempts")
        for left_index, left in enumerate(sources):
            if not left.get("bind_interface"):
                continue
            left_targets = [ipaddress.ip_network(value, strict=False) for value in left.get("targets", [])]
            for right in sources[left_index + 1 :]:
                if not right.get("bind_interface"):
                    continue
                right_targets = [ipaddress.ip_network(value, strict=False) for value in right.get("targets", [])]
                if any(_attribution_scopes_overlap(a, b) for a in left_targets for b in right_targets):
                    raise ValidationError(
                        f"Overlapping bound scan scopes on {left.get('alias')} and {right.get('alias')} cannot be attributed reliably"
                    )

    return {
        "name": clean_text(raw.get("name") or "Network assessment", 120),
        "operator": clean_text(raw.get("operator"), 120),
        "authorization_note": clean_text(raw.get("authorization_note"), 1000),
        "topology_notes": clean_text(raw.get("topology_notes"), 4000),
        "automotive_mode": automotive_mode,
        "include_vin_in_reports": parse_bool(
            raw.get("include_vin_in_reports"),
            "VIN report opt-in",
            False,
        ),
        "capture": capture,
        "scan": {
            "enabled": scan_enabled,
            "authorized": authorized,
            "profiles": profiles,
            "allow_public": allow_public,
            "allow_large": allow_large,
            "allow_high_impact": allow_high_impact,
            "allow_intrusive": allow_intrusive,
            "include_port_zero": include_port_zero,
            "max_rate": max_rate,
            "max_retries": parse_int(scan_raw.get("max_retries", 1), "maximum retries", 0, 10),
            "timing": timing,
            "host_timeout_seconds": parse_int(scan_raw.get("host_timeout_seconds", 900), "host timeout", 30, 86400),
            "script_timeout_seconds": parse_int(scan_raw.get("script_timeout_seconds", 120), "script timeout", 10, 3600),
            "exclusions": exclusions,
            "automatic_exclusions": automatic_exclusions,
            "automatic_exclusion_details": automatic_exclusion_details,
            "effective_exclusions": effective_exclusions,
        },
        "sources": sources,
        "warnings": all_warnings,
    }
