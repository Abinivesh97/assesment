"""Correlation, asset inventory, and evidence-based finding generation."""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from typing import Any


RISKY_PORTS: dict[tuple[str, int], tuple[str, str, str]] = {
    ("tcp", 21): ("medium", "FTP service exposed", "Prefer an authenticated encrypted transfer protocol and restrict management reachability."),
    ("tcp", 23): ("high", "Telnet service exposed", "Disable Telnet or replace it with an authenticated encrypted management channel."),
    ("udp", 69): ("medium", "TFTP service exposed", "Restrict or disable unauthenticated TFTP and verify that firmware/configuration data is not exposed."),
    ("tcp", 111): ("medium", "RPC port mapper exposed", "Restrict RPC services to required management hosts and review registered programs."),
    ("tcp", 139): ("medium", "Legacy NetBIOS/SMB exposure", "Remove legacy SMB dependencies and restrict the service to approved management segments."),
    ("tcp", 445): ("medium", "SMB service exposed", "Restrict SMB reachability, require signing where applicable, and verify patch state."),
    ("udp", 161): ("medium", "SNMP service exposed", "Use SNMPv3, remove default communities, and restrict source addresses."),
    ("tcp", 1433): ("medium", "Database service exposed", "Restrict database access to approved clients and require strong authentication and encryption."),
    ("tcp", 1521): ("medium", "Database listener exposed", "Restrict database access to approved clients and require strong authentication and encryption."),
    ("tcp", 2375): ("high", "Unencrypted Docker API exposed", "Disable the plaintext Docker API or require mutually authenticated TLS and strict network controls."),
    ("tcp", 3306): ("medium", "Database service exposed", "Restrict database access to approved clients and require strong authentication and encryption."),
    ("tcp", 3389): ("medium", "Remote Desktop service exposed", "Restrict RDP to a management plane, require NLA/MFA, and verify patch state."),
    ("tcp", 5432): ("medium", "Database service exposed", "Restrict database access to approved clients and require strong authentication and encryption."),
    ("tcp", 5900): ("medium", "VNC service exposed", "Restrict VNC and require a protected management tunnel with strong authentication."),
    ("tcp", 6379): ("high", "Redis service exposed", "Bind Redis to trusted interfaces, require authentication/TLS, and restrict network access."),
    ("tcp", 9200): ("high", "Elasticsearch API exposed", "Restrict the API, require authentication/TLS, and verify authorization settings."),
    ("tcp", 11211): ("high", "Memcached service exposed", "Restrict Memcached to trusted local clients and disable UDP unless explicitly required."),
    ("udp", 11211): ("high", "Memcached UDP exposed", "Disable UDP and restrict Memcached to trusted local clients."),
    ("tcp", 13400): ("medium", "DoIP diagnostic endpoint exposed", "Restrict diagnostic reachability by vehicle state and trust zone; require an approved diagnostic gateway and authentication controls."),
    ("udp", 13400): ("medium", "DoIP discovery endpoint exposed", "Constrain DoIP discovery/routing activation to the intended diagnostic segment and approved vehicle states."),
    ("tcp", 27017): ("high", "MongoDB service exposed", "Restrict MongoDB, require authentication/TLS, and verify authorization settings."),
}

CLEARTEXT_PROTOCOLS = {
    "TELNET": ("high", "Telnet traffic observed"),
    "FTP": ("medium", "FTP traffic observed"),
    "HTTP": ("low", "Cleartext HTTP traffic observed"),
    "POP": ("medium", "Cleartext POP traffic observed"),
    "IMAP": ("medium", "Cleartext IMAP traffic observed"),
    "SNMP": ("low", "SNMP traffic observed"),
}

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}


def _stable_id(prefix: str, value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")
    return f"{prefix}-{hashlib.sha256(encoded).hexdigest()[:16]}"


def _primary_address(host: dict[str, Any]) -> str:
    for family in ("ipv4", "ipv6", "mac"):
        for address in host.get("addresses", []):
            if address.get("addrtype") == family:
                return address.get("addr", "unknown")
    return "unknown"


def build_inventory(scan_records: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    assets_by_address: dict[tuple[str, str], dict[str, Any]] = {}
    services_by_key: dict[tuple[str, str, str, int, str], dict[str, Any]] = {}
    for record in scan_records:
        parsed = record.get("parsed") or {}
        source_id = record.get("source_id")
        for host in parsed.get("hosts", []):
            address = _primary_address(host)
            asset_key = (str(source_id), address)
            asset = assets_by_address.setdefault(
                asset_key,
                {
                    "id": _stable_id("asset", asset_key),
                    "primary_address": address,
                    "addresses": [],
                    "mac": None,
                    "vendor": None,
                    "hostnames": [],
                    "status": host.get("status", {}).get("state", "unknown"),
                    "sources": [],
                    "os_matches": [],
                },
            )
            for address_row in host.get("addresses", []):
                if address_row not in asset["addresses"]:
                    asset["addresses"].append(address_row)
                if address_row.get("addrtype") == "mac":
                    asset["mac"] = address_row.get("addr")
                    asset["vendor"] = address_row.get("vendor")
            for hostname in host.get("hostnames", []):
                if hostname not in asset["hostnames"]:
                    asset["hostnames"].append(hostname)
            if source_id and source_id not in asset["sources"]:
                asset["sources"].append(source_id)
            for os_match in host.get("os_matches", []):
                if os_match not in asset["os_matches"]:
                    asset["os_matches"].append(os_match)
            for port in host.get("ports", []):
                key = (str(source_id), address, str(port.get("protocol")), int(port.get("port", 0)), str(port.get("state")))
                service_data = port.get("service") or {}
                candidate = {
                        "id": _stable_id("service", key),
                        "asset_id": asset["id"],
                        "address": address,
                        "source_id": source_id,
                        "protocol": port.get("protocol"),
                        "port": port.get("port"),
                        "state": port.get("state"),
                        "reason": port.get("reason"),
                        "service": service_data.get("name"),
                        "product": service_data.get("product"),
                        "version": service_data.get("version"),
                        "extra_info": service_data.get("extrainfo"),
                        "method": service_data.get("method"),
                        "confidence": service_data.get("conf"),
                        "cpe": service_data.get("cpes") or service_data.get("cpe"),
                        "scripts": port.get("scripts", []),
                    }
                existing = services_by_key.get(key)
                if existing is None:
                    services_by_key[key] = candidate
                else:
                    for field in ("reason", "service", "product", "version", "extra_info", "method", "confidence", "cpe"):
                        if candidate.get(field) and not existing.get(field):
                            existing[field] = candidate[field]
                    known_scripts = {(script.get("id"), script.get("output")) for script in existing.get("scripts", [])}
                    for script in candidate.get("scripts", []):
                        if (script.get("id"), script.get("output")) not in known_scripts:
                            existing.setdefault("scripts", []).append(script)
    assets = sorted(assets_by_address.values(), key=lambda item: (item["primary_address"], ",".join(item.get("sources", []))))
    services = list(services_by_key.values())
    services.sort(key=lambda item: (item["address"], item["protocol"] or "", item["port"] or 0))
    return assets, services


def _finding(
    category: str,
    title: str,
    severity: str,
    description: str,
    remediation: str,
    *,
    confidence: str = "medium",
    source_ids: list[str] | None = None,
    assets: list[str] | None = None,
    services: list[str] | None = None,
    evidence: list[dict[str, Any]] | None = None,
    status: str = "needs-review",
    cve_ids: list[str] | None = None,
) -> dict[str, Any]:
    identity = (category, title, source_ids or [], assets or [], services or [])
    return {
        "id": _stable_id("finding", identity),
        "category": category,
        "title": title,
        "severity": severity,
        "confidence": confidence,
        "status": status,
        "description": description,
        "remediation": remediation,
        "source_ids": source_ids or [],
        "asset_ids": assets or [],
        "service_ids": services or [],
        "evidence": evidence or [],
        "cve_ids": cve_ids or [],
    }


def build_findings(config: dict[str, Any], analyses: list[dict[str, Any]], services: list[dict[str, Any]]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    source_map = {source["source_id"]: source for source in config.get("sources", [])}

    for service in services:
        if service.get("state") != "open":
            continue
        source_id = service.get("source_id")
        source = source_map.get(source_id, {})
        port = int(service.get("port") or 0)
        protocol = str(service.get("protocol") or "tcp")
        evidence = [{"type": "nmap-port", "address": service.get("address"), "protocol": protocol, "port": port, "state": service.get("state"), "reason": service.get("reason")}]
        if source.get("expected_ports") and port not in source["expected_ports"]:
            findings.append(
                _finding(
                    "policy-deviation",
                    f"Unexpected {protocol.upper()} port {port} on {service.get('address')}",
                    "medium",
                    "The port is open but is not in the operator-supplied expected-port baseline. This is a policy deviation requiring owner review, not proof that the service is unnecessary.",
                    "Confirm the ECU/asset role and business need. Close the service or update the approved baseline with an owner and rationale.",
                    confidence="high",
                    source_ids=[source_id] if source_id else [],
                    services=[service["id"]],
                    assets=[service["asset_id"]],
                    evidence=evidence,
                )
            )
        risk = RISKY_PORTS.get((protocol, port))
        if risk:
            severity, title, remediation = risk
            findings.append(
                _finding(
                    "exposure",
                    f"{title} at {service.get('address')}:{port}",
                    severity,
                    "Nmap reported the port open from this scan vantage. Exposure may be intentional; configuration, authentication, and patch state require verification.",
                    remediation,
                    confidence="high",
                    source_ids=[source_id] if source_id else [],
                    services=[service["id"]],
                    assets=[service["asset_id"]],
                    evidence=evidence,
                )
            )
        for script in service.get("scripts", []):
            script_id = script.get("id", "unknown")
            output = script.get("output", "")
            upper = output.upper()
            if "VULNERABLE" in upper and "NOT VULNERABLE" not in upper:
                cve_ids = sorted(set(re.findall(r"\bCVE-\d{4}-\d{4,7}\b", upper)))
                findings.append(
                    _finding(
                        "potential-vulnerability",
                        f"Nmap script {script_id} reported a potential issue on {service.get('address')}:{port}",
                        "high",
                        "A curated Nmap script returned vulnerability-like evidence. Script results are not exploit proof and can contain false positives.",
                        "Validate the exact product, version, vendor backports, configuration, and advisory applicability before remediation or risk acceptance.",
                        confidence="medium",
                        source_ids=[source_id] if source_id else [],
                        services=[service["id"]],
                        assets=[service["asset_id"]],
                        evidence=[{"type": "nmap-script", "script": script_id, "output_excerpt": output[:1200]}],
                        cve_ids=cve_ids,
                    )
                )
            lower = output.lower()
            if script_id == "ftp-anon" and "anonymous ftp login allowed" in lower:
                findings.append(
                    _finding(
                        "misconfiguration",
                        f"Anonymous FTP access reported on {service.get('address')}:{port}",
                        "high",
                        "The ftp-anon script reported anonymous access. Verify the exposed directories and whether write access is possible.",
                        "Disable anonymous access or strictly limit it to approved read-only content on an isolated network.",
                        confidence="high",
                        source_ids=[source_id] if source_id else [],
                        services=[service["id"]],
                        assets=[service["asset_id"]],
                        evidence=[{"type": "nmap-script", "script": script_id, "output_excerpt": output[:1200]}],
                    )
                )
            if script_id == "smb2-security-mode" and "message signing enabled but not required" in lower:
                findings.append(
                    _finding(
                        "misconfiguration",
                        f"SMB signing not required on {service.get('address')}:{port}",
                        "medium",
                        "The SMB service reported that message signing is enabled but not required.",
                        "Require SMB signing where compatible and restrict SMB to the approved management plane.",
                        confidence="high",
                        source_ids=[source_id] if source_id else [],
                        services=[service["id"]],
                        assets=[service["asset_id"]],
                        evidence=[{"type": "nmap-script", "script": script_id, "output_excerpt": output[:1200]}],
                    )
                )

    for analysis_row in analyses:
        source_id = analysis_row.get("source_id")
        analysis = analysis_row.get("analysis") or {}
        observed_protocols = {str(row.get("protocol", "")).upper(): int(row.get("count", 0)) for row in analysis.get("protocols", [])}
        for protocol, (severity, title) in CLEARTEXT_PROTOCOLS.items():
            if observed_protocols.get(protocol, 0):
                findings.append(
                    _finding(
                        "traffic-observation",
                        title,
                        severity,
                        f"Passive capture observed {observed_protocols[protocol]:,} packets decoded as {protocol}. This does not by itself prove that credentials or sensitive payloads were present.",
                        "Confirm whether the protocol is required and protect sensitive exchanges with authenticated encryption and network segmentation.",
                        confidence="high",
                        source_ids=[source_id] if source_id else [],
                        evidence=[{"type": "packet-statistic", "protocol": protocol, "packets": observed_protocols[protocol]}],
                    )
                )
        source = source_map.get(source_id, {})
        expected_vlans = {str(value) for value in source.get("vlan_ids", [])}
        observed_vlans = {str(value) for value in analysis.get("vlan_partitions", {}) if value != "untagged"}
        for vlan in sorted(observed_vlans - expected_vlans) if expected_vlans else []:
            findings.append(
                _finding(
                    "vlan-policy",
                    f"Unexpected VLAN {vlan} observed on {source.get('alias') or source_id}",
                    "medium",
                    "Tagged traffic for this VLAN was present but the VLAN was not in the operator-supplied expected list for this capture source.",
                    "Verify the Marvell switch port membership, trunk/native VLAN configuration, mirror selection, and intended vehicle network segmentation.",
                    confidence="high",
                    source_ids=[source_id] if source_id else [],
                    evidence=[{"type": "vlan-statistic", "vlan": vlan, "packets": analysis["vlan_partitions"][vlan].get("packets", 0)}],
                )
            )
        grandmasters = analysis.get("automotive", {}).get("ptp_grandmasters", [])
        if len(grandmasters) > 1:
            findings.append(
                _finding(
                    "timing-observation",
                    "Multiple PTP grandmaster identities observed",
                    "low",
                    "More than one grandmaster identity was decoded. This can be legitimate during best-master selection or a topology change; hardware timestamp provenance is required for timing conclusions.",
                    "Correlate with the expected gPTP domain, Marvell switch configuration, BMCA events, and a hardware-timestamped reference trace.",
                    confidence="medium",
                    source_ids=[source_id] if source_id else [],
                    evidence=[{"type": "ptp-statistic", "grandmasters": grandmasters[:10]}],
                )
            )
        if int(analysis.get("reported_capture_drops", 0)):
            findings.append(
                _finding(
                    "capture-health",
                    f"Capture drops reported on {source.get('alias') or source_id}",
                    "high",
                    f"The capture metadata reported at least {int(analysis.get('reported_capture_drops', 0)):,} dropped packets. Protocol, timing, conversation, and absence-based conclusions are incomplete.",
                    "Reduce capture load, increase capture buffers, verify VN5620/driver queues and disk throughput, then repeat the measurement.",
                    confidence="high",
                    source_ids=[source_id] if source_id else [],
                    evidence=[{"type": "capture-statistic", "reported_drops": int(analysis.get("reported_capture_drops", 0))}],
                )
            )
        expert_events = analysis.get("automotive_expert_events", [])
        if expert_events:
            findings.append(
                _finding(
                    "protocol-anomaly",
                    f"Automotive protocol anomalies decoded on {source.get('alias') or source_id}",
                    "medium",
                    "TShark exposed malformed, truncated, overlap, sequence, NACK, or related automotive-protocol fields. These are protocol-analysis observations and can also result from truncation, capture loss, missing reassembly, or dissector context.",
                    "Review the referenced frames in Wireshark, verify capture health and project decode configuration, then correlate with ECU and switch logs.",
                    confidence="medium",
                    source_ids=[source_id] if source_id else [],
                    evidence=[{"type": "tshark-field-statistic", "events": expert_events[:30]}],
                )
            )
        uds_rows = analysis.get("automotive", {}).get("uds_services", [])
        sensitive_tokens = {
            "0x11": "ECUReset",
            "17": "ECUReset",
            "0x27": "SecurityAccess",
            "39": "SecurityAccess",
            "0x28": "CommunicationControl",
            "40": "CommunicationControl",
            "0x2e": "WriteDataByIdentifier",
            "46": "WriteDataByIdentifier",
            "0x31": "RoutineControl",
            "49": "RoutineControl",
            "0x34": "RequestDownload",
            "52": "RequestDownload",
            "0x36": "TransferData",
            "54": "TransferData",
            "0x37": "RequestTransferExit",
            "55": "RequestTransferExit",
        }
        sensitive_seen = []
        for row in uds_rows:
            raw_value = str(row.get("value", "")).strip()
            label = sensitive_tokens.get(raw_value.lower())
            if not label:
                label = next((name for token, name in sensitive_tokens.items() if name.lower() in raw_value.lower()), None)
            if label:
                sensitive_seen.append({"sid": raw_value, "service": label, "packets": row.get("count", 0)})
        if sensitive_seen:
            findings.append(
                _finding(
                    "diagnostic-activity",
                    f"Operationally sensitive UDS services observed on {source.get('alias') or source_id}",
                    "medium",
                    "The trace contains diagnostic service identifiers associated with reset, security access, communication control, writes, routines, or software transfer. Observation does not prove that an unauthorized request succeeded.",
                    "Confirm the vehicle/bench state, tester identity, DoIP routing controls, diagnostic authorization, and ECU audit logs. Investigate unexpected successful responses.",
                    confidence="high",
                    source_ids=[source_id] if source_id else [],
                    evidence=[{"type": "uds-statistic", "services": sensitive_seen[:30]}],
                )
            )
        return_codes = analysis.get("automotive", {}).get("someip_return_codes", [])
        non_success = [
            row
            for row in return_codes
            if str(row.get("value", "")).strip().lower() not in {"0", "0x00", "0x0", "e_ok", "ok"}
        ]
        if non_success:
            findings.append(
                _finding(
                    "service-health",
                    f"Non-success SOME/IP return codes observed on {source.get('alias') or source_id}",
                    "low",
                    "One or more SOME/IP responses carried a non-success return code. This is an availability/interoperability lead, not a vulnerability by itself.",
                    "Correlate service/method identifiers with ARXML/FIBEX, ECU logs, state transitions, and expected negative-response behavior.",
                    confidence="high",
                    source_ids=[source_id] if source_id else [],
                    evidence=[{"type": "someip-statistic", "return_codes": non_success[:30]}],
                )
            )

    unique = {item["id"]: item for item in findings}
    result = list(unique.values())
    result.sort(key=lambda item: (SEVERITY_ORDER.get(item["severity"], 9), item["title"]))
    return result


def severity_counts(findings: list[dict[str, Any]]) -> dict[str, int]:
    counter = Counter(item.get("severity", "info") for item in findings)
    return {severity: counter.get(severity, 0) for severity in ("critical", "high", "medium", "low", "info")}
