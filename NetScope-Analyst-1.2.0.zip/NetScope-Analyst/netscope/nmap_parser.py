"""Nmap XML parsing into a stable report model."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any


def _script_element(node: ET.Element) -> dict[str, Any]:
    result: dict[str, Any] = {"id": node.get("id", ""), "output": node.get("output", "")}
    structured: list[dict[str, Any]] = []
    for child in list(node):
        structured.append(_xml_value(child))
    if structured:
        result["structured"] = structured
    return result


def _xml_value(node: ET.Element) -> dict[str, Any]:
    value: dict[str, Any] = {"type": node.tag}
    if node.get("key") is not None:
        value["key"] = node.get("key")
    if node.text and node.text.strip():
        value["value"] = node.text.strip()
    children = [_xml_value(child) for child in list(node)]
    if children:
        value["children"] = children
    return value


def parse_nmap_xml(path: str | Path) -> dict[str, Any]:
    xml_path = Path(path)
    try:
        root = ET.parse(xml_path).getroot()
    except (ET.ParseError, OSError) as exc:
        return {"path": str(xml_path), "parse_error": str(exc), "hosts": [], "scan": {}}

    scan: dict[str, Any] = {
        "scanner": root.get("scanner"),
        "args": root.get("args"),
        "start": root.get("start"),
        "startstr": root.get("startstr"),
        "version": root.get("version"),
    }
    scaninfo = root.find("scaninfo")
    if scaninfo is not None:
        scan["scaninfo"] = dict(scaninfo.attrib)
    finished = root.find("./runstats/finished")
    hosts_stats = root.find("./runstats/hosts")
    if finished is not None:
        scan["finished"] = dict(finished.attrib)
    if hosts_stats is not None:
        scan["host_stats"] = dict(hosts_stats.attrib)

    hosts: list[dict[str, Any]] = []
    for host_node in root.findall("host"):
        status_node = host_node.find("status")
        addresses = [dict(node.attrib) for node in host_node.findall("address")]
        hostnames = [node.get("name", "") for node in host_node.findall("./hostnames/hostname") if node.get("name")]
        ports: list[dict[str, Any]] = []
        for port_node in host_node.findall("./ports/port"):
            state_node = port_node.find("state")
            service_node = port_node.find("service")
            scripts = [_script_element(script) for script in port_node.findall("script")]
            service = dict(service_node.attrib) if service_node is not None else {}
            if service_node is not None:
                cpes = [node.text.strip() for node in service_node.findall("cpe") if node.text and node.text.strip()]
                if cpes:
                    service["cpes"] = cpes
            port: dict[str, Any] = {
                "protocol": port_node.get("protocol"),
                "port": int(port_node.get("portid", "0")),
                "state": state_node.get("state") if state_node is not None else "unknown",
                "reason": state_node.get("reason") if state_node is not None else None,
                "reason_ttl": state_node.get("reason_ttl") if state_node is not None else None,
                "service": service,
                "scripts": scripts,
            }
            ports.append(port)
        os_matches: list[dict[str, Any]] = []
        for os_node in host_node.findall("./os/osmatch"):
            os_matches.append(
                {
                    **dict(os_node.attrib),
                    "classes": [dict(child.attrib) for child in os_node.findall("osclass")],
                }
            )
        host_scripts = [_script_element(script) for script in host_node.findall("./hostscript/script")]
        uptime = host_node.find("uptime")
        distance = host_node.find("distance")
        hosts.append(
            {
                "status": dict(status_node.attrib) if status_node is not None else {},
                "addresses": addresses,
                "hostnames": hostnames,
                "ports": ports,
                "os_matches": os_matches,
                "host_scripts": host_scripts,
                "uptime": dict(uptime.attrib) if uptime is not None else None,
                "distance": dict(distance.attrib) if distance is not None else None,
                "starttime": host_node.get("starttime"),
                "endtime": host_node.get("endtime"),
            }
        )
    return {"path": str(xml_path), "hosts": hosts, "scan": scan}
