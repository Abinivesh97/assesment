"""Strictly allowlisted, privacy-minimized support diagnostics.

This module intentionally does not serialize a report or session object.  It
derives only coarse counters, fixed lifecycle enums, recognized protocol
labels, and numeric tool versions.  Unknown strings are collapsed to
``other`` instead of being echoed.
"""

from __future__ import annotations

import re
from collections import Counter
from typing import Any, Iterable


TOOL_NAMES = ("tshark", "dumpcap", "capinfos", "editcap", "mergecap", "nmap")
SESSION_STATUSES = {
    "queued",
    "starting",
    "capturing",
    "capturing-and-scanning",
    "scanning",
    "stopping",
    "analyzing",
    "reporting",
    "completed",
    "completed-with-errors",
    "interrupted",
    "cancelled",
    "stopped",
    "failed",
}
JOB_STATUSES = {"queued", "running", "completed", "stopped", "failed", "skipped", "cancelled"}
FINDING_CATEGORIES = {
    "policy-deviation",
    "exposure",
    "potential-vulnerability",
    "misconfiguration",
    "traffic-observation",
    "vlan-policy",
    "timing-observation",
    "capture-health",
    "protocol-anomaly",
    "diagnostic-activity",
    "service-health",
}
FINDING_SEVERITIES = {"critical", "high", "medium", "low", "info"}
_VERSION_PATTERN = re.compile(r"(?<![\d.])(\d{1,4}\.\d{1,4}(?:\.\d{1,4})?)(?![\d.])")

_PROTOCOL_LABELS = (
    "ETHERNET",
    "ARP",
    "IP",
    "IPv4",
    "IPv6",
    "ICMP",
    "ICMPv6",
    "TCP",
    "UDP",
    "HTTP",
    "HTTP/2",
    "HTTPS",
    "TLS",
    "TLSv1",
    "TLSv1.1",
    "TLSv1.2",
    "TLSv1.3",
    "SSL",
    "DNS",
    "mDNS",
    "LLMNR",
    "DHCP",
    "DHCPv6",
    "BOOTP",
    "NTP",
    "PTP",
    "gPTP",
    "LLDP",
    "VLAN",
    "IEEE 802.1Q",
    "STP",
    "RSTP",
    "MSTP",
    "SOME/IP",
    "SOME/IP-SD",
    "DoIP",
    "UDS",
    "AUTOSAR-NM",
    "AVTP",
    "AVDECC",
    "MRP",
    "MMRP",
    "MVRP",
    "MSRP",
    "FRER",
    "HSR",
    "PRP",
    "MACsec",
    "MKA",
    "EAPOL",
    "SSH",
    "TELNET",
    "FTP",
    "TFTP",
    "SMB",
    "SMB2",
    "RDP",
    "MQTT",
    "CoAP",
    "SIP",
    "RTP",
    "RTCP",
    "QUIC",
    "OCSP",
    "RPC",
    "MODBUS",
    "ENIP",
    "PROFINET",
    "PN-RT",
    "PNIO",
    "PN-DCP",
    "SSDP",
    "NBNS",
    "KERBEROS",
    "LDAP",
    "SNMP",
    "SYSLOG",
    "BFD",
    "VRRP",
    "IGMP",
    "MLD",
    "OSPF",
    "BGP",
    "LACP",
    "CDP",
    "ESP",
    "AH",
    "ISAKMP",
    "IKEv2",
)


def _normalized_protocol(value: Any) -> str:
    normalized = re.sub(r"[^A-Z0-9]+", "", str(value or "").upper())
    labels = {re.sub(r"[^A-Z0-9]+", "", label.upper()): label for label in _PROTOCOL_LABELS}
    return labels.get(normalized, "OTHER")


def _safe_enum(value: Any, allowed: set[str]) -> str:
    candidate = str(value or "").strip().lower()
    return candidate if candidate in allowed else "other"


def _safe_version(value: Any) -> str | None:
    match = _VERSION_PATTERN.search(str(value or ""))
    return match.group(1) if match else None


def _count(value: Any) -> int:
    try:
        return max(0, int(value or 0))
    except (TypeError, ValueError):
        return 0


def _rows(counter: Counter[str], label: str) -> list[dict[str, Any]]:
    return [{label: key, "count": counter[key]} for key in sorted(counter) if counter[key] > 0]


def _source_key(row: dict[str, Any]) -> str:
    value = row.get("source_id")
    return str(value) if value not in (None, "") else "__unattributed__"


def _tag_depth(value: Any) -> int:
    stack = str(value or "").split(" ", 1)[0]
    return sum(1 for item in stack.split("/") if item.isdigit())


def _list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _ordered_source_keys(state: dict[str, Any], analyses: list[dict[str, Any]]) -> list[str]:
    keys: list[str] = []
    seen: set[str] = set()
    rows: list[dict[str, Any]] = []
    rows.extend(_list(_dict(state.get("config")).get("sources")))
    rows.extend(_list(state.get("captures")))
    rows.extend(_list(state.get("scans")))
    rows.extend(analyses)
    for row in rows:
        if not isinstance(row, dict):
            continue
        key = _source_key(row)
        if key not in seen:
            seen.add(key)
            keys.append(key)
    return keys


def build_support_diagnostics(
    state: dict[str, Any],
    analyses: list[dict[str, Any]],
    scan_records: list[dict[str, Any]],
    assets: list[dict[str, Any]],
    services: list[dict[str, Any]],
    findings: list[dict[str, Any]],
) -> dict[str, Any]:
    """Return a standalone support summary made exclusively from allowlisted fields."""

    source_keys = _ordered_source_keys(state, analyses)
    aliases = {key: f"SOURCE_{index}" for index, key in enumerate(source_keys, start=1)}
    source_data: dict[str, dict[str, Any]] = {
        key: {
            "capture_statuses": Counter(),
            "scan_statuses": Counter(),
            "protocols": Counter(),
            "analysis_record_count": 0,
            "packets_analyzed": 0,
            "tagged_packet_observations": 0,
            "untagged_packet_observations": 0,
            "tag_stack_variants": set(),
            "observed_tag_partition_count": 0,
            "maximum_observed_tag_depth": 0,
            "reported_capture_drop_count": 0,
        }
        for key in source_keys
    }

    for row in _list(state.get("captures")):
        if not isinstance(row, dict):
            continue
        key = _source_key(row)
        if key in source_data:
            source_data[key]["capture_statuses"][_safe_enum(row.get("status"), JOB_STATUSES)] += 1
    for row in _list(state.get("scans")):
        if not isinstance(row, dict):
            continue
        key = _source_key(row)
        if key in source_data:
            source_data[key]["scan_statuses"][_safe_enum(row.get("status"), JOB_STATUSES)] += 1

    for row in analyses:
        if not isinstance(row, dict):
            continue
        key = _source_key(row)
        if key not in source_data:
            continue
        aggregate = source_data[key]
        analysis = _dict(row.get("analysis"))
        tag_summary = _dict(row.get("tag_preservation"))
        aggregate["analysis_record_count"] += 1
        packet_count = _count(
            tag_summary.get("total_packets")
            if "total_packets" in tag_summary
            else analysis.get("packets")
        )
        aggregate["packets_analyzed"] += packet_count
        aggregate["reported_capture_drop_count"] += _count(analysis.get("reported_capture_drops"))
        for protocol in _list(analysis.get("protocols")):
            if isinstance(protocol, dict):
                aggregate["protocols"][_normalized_protocol(protocol.get("protocol"))] += _count(protocol.get("count"))
        raw_tagged_count = 0
        for stack in _list(analysis.get("vlan_stacks")):
            if not isinstance(stack, dict):
                continue
            raw_stack = str(stack.get("stack") or "")
            aggregate["tag_stack_variants"].add(raw_stack)
            raw_tagged_count += _count(stack.get("count"))
            aggregate["maximum_observed_tag_depth"] = max(
                aggregate["maximum_observed_tag_depth"],
                _tag_depth(raw_stack),
            )
        tagged_count = _count(tag_summary.get("tagged_frames")) if "tagged_frames" in tag_summary else raw_tagged_count
        aggregate["tagged_packet_observations"] += tagged_count
        partitions = _dict(analysis.get("vlan_partitions"))
        aggregate["observed_tag_partition_count"] += len(
            [key_name for key_name in partitions if str(key_name).lower() != "untagged"]
        )
        aggregate["untagged_packet_observations"] += (
            max(0, packet_count - tagged_count)
            if tag_summary
            else _count(_dict(partitions.get("untagged")).get("packets"))
        )

    source_rows = []
    for key in source_keys:
        aggregate = source_data[key]
        packet_count = aggregate["packets_analyzed"]
        tagged_count = aggregate["tagged_packet_observations"]
        tag_status = "no-packets-analyzed" if packet_count == 0 else ("tags-observed" if tagged_count else "no-tags-observed")
        source_rows.append(
            {
                "alias": aliases[key],
                "analysis_record_count": aggregate["analysis_record_count"],
                "capture_status_counts": _rows(aggregate["capture_statuses"], "status"),
                "scan_status_counts": _rows(aggregate["scan_statuses"], "status"),
                "protocol_counts": _rows(aggregate["protocols"], "protocol"),
                "tag_preservation_aggregates": {
                    "tag_observation_status": tag_status,
                    "packets_analyzed": packet_count,
                    "tagged_packet_observations": tagged_count,
                    "untagged_packet_observations": aggregate["untagged_packet_observations"],
                    "tag_stack_variant_count": len(aggregate["tag_stack_variants"]),
                    "observed_tag_partition_count": aggregate["observed_tag_partition_count"],
                    "maximum_observed_tag_depth": aggregate["maximum_observed_tag_depth"],
                    "reported_capture_drop_count": aggregate["reported_capture_drop_count"],
                },
            }
        )

    tools = _dict(_dict(state.get("system")).get("tools"))
    tool_rows = []
    for name in TOOL_NAMES:
        tool = _dict(tools.get(name))
        tool_rows.append(
            {
                "name": name,
                "available": tool.get("available") is True,
                "version": _safe_version(tool.get("version")),
            }
        )

    category_counts: Counter[str] = Counter()
    severity_counts: Counter[str] = Counter()
    for finding in findings:
        if not isinstance(finding, dict):
            continue
        category_counts[_safe_enum(finding.get("category"), FINDING_CATEGORIES)] += 1
        severity_counts[_safe_enum(finding.get("severity"), FINDING_SEVERITIES)] += 1

    captures = _list(state.get("captures"))
    scans = _list(state.get("scans"))
    return {
        "schema_version": "1.0",
        "redacted": True,
        "sharing_notice": (
            "Review before sharing. This label applies only to this standalone privacy-minimized diagnostic; "
            "reports, captures, scan output, manifests, and evidence bundles may contain sensitive data."
        ),
        "session_status": _safe_enum(state.get("status"), SESSION_STATUSES),
        "tools": tool_rows,
        "totals": {
            "source_count": len(source_rows),
            "capture_job_count": len(captures),
            "scan_job_count": len(scans),
            "scan_result_count": len(scan_records),
            "analysis_record_count": len(analyses),
            "asset_record_count": len(assets),
            "service_record_count": len(services),
            "open_service_record_count": len(
                [row for row in services if isinstance(row, dict) and str(row.get("state") or "").lower() == "open"]
            ),
            "finding_count": len(findings),
        },
        "message_counts": {
            "warning_count": len(_list(state.get("warnings"))),
            "error_count": len(_list(state.get("errors"))),
            "capture_error_count": len([row for row in captures if isinstance(row, dict) and row.get("error")]),
            "scan_error_count": len([row for row in scans if isinstance(row, dict) and row.get("error")]),
            "analysis_error_count": len([row for row in analyses if isinstance(row, dict) and row.get("error")]),
        },
        "finding_counts": {
            "by_category": _rows(category_counts, "category"),
            "by_severity": _rows(severity_counts, "severity"),
        },
        "sources": source_rows,
    }
