"""NetScope Analyst core package."""

__version__ = "1.2.0"
