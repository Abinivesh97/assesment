"""JSON, HTML, CSV, manifest, and evidence-bundle generation."""

from __future__ import annotations

import csv
import html
import json
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .analysis import sha256_file
from .diagnostics import build_support_diagnostics
from .findings import severity_counts
from .privacy import sanitize_vin_data
from .testcases import evaluate_test_cases
from .topology import build_topology, link_findings_to_topology


LIMITATIONS = [
    "A capture sees only traffic delivered to the measurement point. Full switched-segment visibility normally requires an authorized TAP or mirror/SPAN configuration.",
    "VLAN offload or the selected capture provider can remove 802.1Q tags. A missing tag in the trace does not prove the frame was untagged on the wire.",
    "Cross-source latency and ordering are not authoritative unless timestamp origin, resolution, and synchronization were independently verified.",
    "Nmap scan packets are part of captures taken at the same time and can change load, discovery, and timing observations.",
    "Open ports, service banners, script output, and protocol expert observations are leads for validation, not automatic proof of a vulnerability.",
    "Network-only analysis cannot prove patch state, vendor backports, local configuration, credentials, access-control policy, or physical-layer behavior.",
    "Encrypted traffic and MACsec remain opaque unless authorized keys and an isolated analysis profile are supplied.",
    "Observed TSN/AVB traffic cannot by itself prove Qbv schedules, Qci policing, queue shaping, or worst-case deterministic latency.",
]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def build_report(
    state: dict[str, Any],
    analyses: list[dict[str, Any]],
    scan_records: list[dict[str, Any]],
    assets: list[dict[str, Any]],
    services: list[dict[str, Any]],
    findings: list[dict[str, Any]],
) -> dict[str, Any]:
    session_id = str(state["id"])
    include_vin = state.get("config", {}).get("include_vin_in_reports") is True
    state = sanitize_vin_data(state, session_id, include_plaintext=include_vin)
    analyses = sanitize_vin_data(analyses, session_id, include_plaintext=include_vin)
    scan_records = sanitize_vin_data(scan_records, session_id, include_plaintext=include_vin)
    assets = sanitize_vin_data(assets, session_id, include_plaintext=include_vin)
    services = sanitize_vin_data(services, session_id, include_plaintext=include_vin)
    findings = sanitize_vin_data(findings, session_id, include_plaintext=include_vin)
    config = state["config"]
    topology = build_topology(session_id, config, analyses, assets, services)
    findings = link_findings_to_topology(findings, topology)
    scan_records_by_id = {row.get("id"): row for row in scan_records if row.get("id")}
    scan_evidence_rows = []
    for row in state.get("scans", []):
        record = scan_records_by_id.get(row.get("id"))
        parsed = (record or {}).get("parsed") or {}
        scan_evidence_rows.append(
            {
                **row,
                "analysis_available": bool(record) and not bool(parsed.get("parse_error")),
            }
        )
    capture_totals = {
        "packets": sum((row.get("analysis") or {}).get("packets", 0) for row in analyses),
        "bytes": sum((row.get("analysis") or {}).get("bytes", 0) for row in analyses),
        "capture_files": len([row for row in state.get("captures", []) if row.get("path")]),
        "capture_failures": len([row for row in state.get("captures", []) if row.get("status") == "failed"]),
        "scan_jobs": len(state.get("scans", [])),
        "scan_failures": len([row for row in state.get("scans", []) if row.get("status") == "failed"]),
        "scan_cancellations": len([row for row in state.get("scans", []) if row.get("status") == "cancelled"]),
    }
    open_services = [service for service in services if service.get("state") == "open"]
    report = {
        "schema_version": "1.1",
        "report_id": f"report-{state['id']}",
        "generated_at_utc": utc_now(),
        "session": {
            "id": state["id"],
            "name": state.get("name"),
            "operator": config.get("operator"),
            "authorization_note": config.get("authorization_note"),
            "automotive_mode": config.get("automotive_mode"),
            "topology_notes": config.get("topology_notes"),
            "created_at": state.get("created_at"),
            "started_at": state.get("started_at"),
            "ended_at": state.get("ended_at"),
            "status": state.get("status"),
            "system": state.get("system"),
        },
        "scope": {
            "sources": config.get("sources", []),
            "capture_configuration": config.get("capture", {}),
            "capture_commands": [
                {
                    "source_id": row.get("source_id"),
                    "source_alias": row.get("source_alias"),
                    "capture_id": row.get("capture_id"),
                    "command": row.get("command_display"),
                    "started_at": row.get("started_at"),
                    "ended_at": row.get("ended_at"),
                    "exit_code": row.get("exit_code"),
                    "status": row.get("status"),
                    "size_bytes": row.get("size_bytes"),
                }
                for row in state.get("captures", [])
            ],
            "scan_configuration": config.get("scan", {}),
            "effective_nmap_commands": [
                {
                    "id": row.get("id"),
                    "source_id": row.get("source_id"),
                    "profile": row.get("profile"),
                    "family": row.get("family"),
                    "command": row.get("command_display"),
                    "started_at": row.get("started_at"),
                    "ended_at": row.get("ended_at"),
                    "exit_code": row.get("exit_code"),
                    "status": row.get("status"),
                    "binding_mode": row.get("binding_mode"),
                    "binding_note": row.get("binding_note"),
                    "analysis_available": row.get("analysis_available"),
                }
                for row in scan_evidence_rows
            ],
        },
        "coverage": capture_totals,
        "privacy": {
            "include_vin_in_reports": include_vin,
            "vin_handling": "explicit-local-inclusion" if include_vin else "session-pseudonymized",
            "statement": (
                "Valid 17-character ISO-style DoIP VINs are retained in this local derived report by "
                "explicit operator choice; opaque or invalid field values remain session aliases. "
                "A VIN is identity evidence and is never classified as a vulnerability."
                if include_vin
                else "VIN-like values are replaced with stable session aliases in derived analysis and reports. "
                "A VIN is identity evidence and is never classified as a vulnerability."
            ),
        },
        "topology": topology,
        "executive_summary": {
            "assets": len(assets),
            "open_services": len(open_services),
            "findings": len(findings),
            "findings_by_severity": severity_counts(findings),
            "observed_vlans": sorted(
                {
                    vlan
                    for row in analyses
                    for vlan in (row.get("analysis") or {}).get("vlan_partitions", {})
                    if vlan != "untagged"
                }
            ),
        },
        "assets": assets,
        "services": services,
        "traffic_analysis": analyses,
        "nmap_results": scan_records,
        "findings": findings,
        "test_case_matrix": evaluate_test_cases(
            config,
            analyses,
            services,
            findings,
            captures=state.get("captures", []),
            scans=scan_evidence_rows,
        ),
        "recommendations": _recommendations(findings, config),
        "warnings": state.get("warnings", []),
        "errors": state.get("errors", []),
        "limitations": LIMITATIONS,
    }
    return sanitize_vin_data(report, session_id, include_plaintext=include_vin)


def _recommendations(findings: list[dict[str, Any]], config: dict[str, Any]) -> list[str]:
    result: list[str] = []
    if any(item.get("category") == "policy-deviation" for item in findings):
        result.append("Reconcile unexpected ports with an ECU/asset owner and maintain a version-controlled expected-service baseline per VLAN and vehicle state.")
    if any(item.get("category") == "vlan-policy" for item in findings):
        result.append("Review Marvell switch access/trunk membership, native VLAN behavior, mirror sources, and inter-VLAN routing controls.")
    if any(item.get("category") == "traffic-observation" for item in findings):
        result.append("Replace or contain cleartext management/application protocols and verify that diagnostics and credentials are not exposed across trust boundaries.")
    if config.get("automotive_mode"):
        result.extend(
            [
                "Import the project ARXML/FIBEX/ODX or an approved ECU/service catalogue before deciding whether a SOME/IP, DoIP, UDS, or dynamic port is unexpected.",
                "Validate capture completeness, VN5620 timestamp provenance, Vector channel mapping, VLAN tag fidelity, and packet drops against a known bench trace.",
                "Run intrusive or full-range enumeration only in an authorized stationary bench state, one ECU at a time, with recovery access available.",
            ]
        )
    if not result:
        result.append("Retain the evidence and compare it with an approved asset, service, VLAN, and timing baseline; absence of a finding is not proof of absence.")
    return result


def _write_csv(path: Path, fieldnames: list[str], rows: Iterable[dict[str, Any]]) -> None:
    def safe(value: Any) -> Any:
        if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@")):
            return "'" + value
        return value

    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: safe(value) for key, value in row.items()})


def _text(value: Any) -> str:
    if value is None:
        return "—"
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def _table(headers: list[tuple[str, str]], rows: Iterable[dict[str, Any]], empty: str = "No data") -> str:
    values = list(rows)
    if not values:
        return f'<p class="muted">{html.escape(empty)}</p>'
    head = "".join(f"<th>{html.escape(label)}</th>" for _, label in headers)
    body = []
    for row in values:
        cells = "".join(f"<td>{html.escape(_text(row.get(key)))}</td>" for key, _ in headers)
        body.append(f"<tr>{cells}</tr>")
    return f'<div class="table-wrap"><table><thead><tr>{head}</tr></thead><tbody>{"".join(body)}</tbody></table></div>'


def _analysis_vlan_attributions(row: dict[str, Any]) -> list[dict[str, Any]]:
    records = [item for item in row.get("vlan_attribution", []) if isinstance(item, dict)]
    if records:
        return records
    result = []
    for view in row.get("vlan_views", []):
        if not isinstance(view, dict) or not isinstance(view.get("attribution"), dict):
            continue
        result.append({"vlan_id": view.get("vlan_id"), **view["attribution"]})
    return result


def _configured_vlan_ids(source: dict[str, Any]) -> list[int]:
    result = []
    for value in source.get("vlan_ids", []):
        try:
            vlan_id = int(value)
        except (TypeError, ValueError):
            continue
        if 0 <= vlan_id <= 4095 and vlan_id not in result:
            result.append(vlan_id)
    return result


def _vlan_attribution_rows(
    analyses: list[dict[str, Any]],
    sources: list[dict[str, Any]],
    selected_vlan_id: int | None = None,
) -> list[dict[str, Any]]:
    source_map = {str(row.get("source_id")): row for row in sources}
    result = []
    for row in analyses:
        source_id = str(row.get("source_id") or "")
        configured = _configured_vlan_ids(source_map.get(source_id, {}))
        summary = row.get("tag_preservation") or {}
        attribution = _analysis_vlan_attributions(row)
        if selected_vlan_id is not None:
            attribution = [
                item
                for item in attribution
                if str(item.get("vlan_id")) == str(selected_vlan_id)
            ]
        if not attribution and selected_vlan_id is None:
            attribution = [{}]
        blocked_vlans = {
            int(item["vlan_id"])
            for item in attribution
            if str(item.get("vlan_id", "")).isdigit() and item.get("basis") == "unattributable"
        }
        for item in attribution:
            try:
                vlan_id = int(item["vlan_id"])
            except (KeyError, TypeError, ValueError):
                vlan_id = None
            basis = str(item.get("basis") or "not-attributed")
            confidence = str(item.get("confidence") or "none").lower()
            attribution_scope = str(item.get("attribution_scope") or "").lower()
            if attribution_scope not in {"full-source", "retained-membership", "unattributable"}:
                if basis == "configured-source":
                    attribution_scope = "full-source"
                elif basis == "configured-and-observed" and confidence == "medium":
                    attribution_scope = "full-source"
                elif basis in {"configured-and-observed", "observed-8021q"}:
                    attribution_scope = "retained-membership"
                else:
                    attribution_scope = "unattributable"
            active_scan_attributable = (
                vlan_id is not None
                and len(configured) == 1
                and configured[0] == vlan_id
                and basis in {"configured-source", "configured-and-observed"}
                and attribution_scope == "full-source"
                and vlan_id not in blocked_vlans
            )
            tagged_packets = int(item.get("tagged_packets") or 0)
            total_packets = int(item.get("total_packets") or summary.get("total_packets") or 0)
            summary_tagged = int(summary.get("tagged_frames") or 0)
            summary_total = int(summary.get("total_packets") or total_packets)
            note_parts = [str(item.get("note") or "").strip(), str(summary.get("note") or "").strip()]
            result.append(
                {
                    "source": row.get("source_alias") or row.get("source_id"),
                    "vlan": f"VLAN {vlan_id}" if vlan_id is not None else "No attributable VLAN view",
                    "vlan_id": vlan_id,
                    "basis": basis,
                    "attribution_scope": attribution_scope,
                    "confidence": confidence,
                    "tag_observed": "yes" if item.get("tag_observed") is True else "no",
                    "tagged_vs_total": f"{tagged_packets:,} / {total_packets:,}",
                    "source_tagged_vs_total": f"{summary_tagged:,} / {summary_total:,}",
                    "tag_assessment": summary.get("assessment") or "not-available",
                    "active_scan_attribution": "yes" if active_scan_attributable else "no — traffic evidence only",
                    "note": " ".join(part for part in note_parts if part) or "No attribution note is available.",
                }
            )
    return result


def _render_vlan_attribution_banner(rows: list[dict[str, Any]], vlan_id: int | None) -> str:
    if vlan_id is None:
        return ""
    row = next((item for item in rows if item.get("vlan_id") == vlan_id), None)
    if not row:
        return (
            '<section class="vlan-attribution-banner"><h2>VLAN attribution statement</h2>'
            '<div class="callout"><strong>Basis:</strong> unavailable · <strong>Confidence:</strong> none · '
            '<strong>Tagged / total:</strong> unavailable<br>No authoritative VLAN attribution record is available; '
            'traffic, assets, services, and scans must not be assigned to this VLAN.</div></section>'
        )
    return (
        '<section class="vlan-attribution-banner"><h2>VLAN attribution statement</h2><div class="callout">'
        f'<strong>{html.escape(_text(row.get("vlan")))}</strong> · '
        f'<strong>Basis:</strong> {html.escape(_text(row.get("basis")))} · '
        f'<strong>Scope:</strong> {html.escape(_text(row.get("attribution_scope")))} · '
        f'<strong>Confidence:</strong> {html.escape(_text(row.get("confidence")))} · '
        f'<strong>Tagged / total:</strong> {html.escape(_text(row.get("tagged_vs_total")))} · '
        f'<strong>Active-scan attribution:</strong> {html.escape(_text(row.get("active_scan_attribution")))}'
        f'<br>{html.escape(_text(row.get("note")))}</div></section>'
    )


def _render_topology_map(topology: dict[str, Any], source_ids: set[str], vlan_id: int | None) -> str:
    nodes = [
        row
        for row in topology.get("nodes", [])
        if not source_ids or set(row.get("source_ids", [])) & source_ids
    ]
    edges = [
        row
        for row in topology.get("edges", [])
        if not source_ids or set(row.get("source_ids", [])) & source_ids
    ]
    if vlan_id is not None:
        edges = [row for row in edges if vlan_id in row.get("vlan_ids", [])]
        connected = {endpoint for row in edges for endpoint in (row.get("source"), row.get("target"))}
        nodes = [row for row in nodes if vlan_id in row.get("vlan_ids", []) or row.get("id") in connected]
    node_ids = {row.get("id") for row in nodes}
    edges = [row for row in edges if row.get("source") in node_ids and row.get("target") in node_ids]
    aliases = {row.get("id"): row.get("alias") for row in nodes}
    vlan_catalog = [
        row
        for row in topology.get("vlans", [])
        if not source_ids or set(row.get("source_ids", [])) & source_ids
    ]
    vlan_catalog_by_id = {row.get("vlan_id"): row for row in vlan_catalog}

    def evidence_text(row: dict[str, Any]) -> str:
        return "; ".join(
            f"VLAN {item.get('vlan_id')}: {', '.join(item.get('bases', []))}"
            for item in row.get("vlan_evidence", [])
        )

    node_rows = []
    for row in nodes:
        vehicle_ids = row.get("observed_vins") or row.get("vehicle_aliases") or []
        node_rows.append(
            {
                **row,
                "names_text": ", ".join(row.get("names", [])),
                "addresses_text": ", ".join(row.get("addresses", [])),
                "mac_text": ", ".join(row.get("mac_addresses", [])),
                "vlans_text": ", ".join(map(str, row.get("vlan_ids", []))) or "untagged / unknown",
                "vlan_evidence_text": evidence_text(row) or "No attributed VLAN evidence",
                "vehicle_text": ", ".join(vehicle_ids),
            }
        )
    edge_rows = [
        {
            **row,
            "source_alias": aliases.get(row.get("source"), row.get("source")),
            "target_alias": aliases.get(row.get("target"), row.get("target")),
            "protocols_text": ", ".join(row.get("protocols", [])),
            "vlans_text": ", ".join(map(str, row.get("vlan_ids", []))) or "unattributed",
            "vlan_evidence_text": evidence_text(row) or "No attributed VLAN evidence",
            "ports_text": ", ".join(map(str, row.get("destination_ports", []))),
        }
        for row in edges
    ]

    map_vlans = [vlan_id] if vlan_id is not None else sorted(
        {value for row in nodes for value in row.get("vlan_ids", [])}
        | {value for value in vlan_catalog_by_id if isinstance(value, int)}
    )
    lanes = []
    for value in map_vlans:
        members = [row for row in nodes if value in row.get("vlan_ids", [])]
        chips = "".join(
            f'<span class="topology-node topology-node--{html.escape(_text(row.get("role")))}">'
            f'<b>{html.escape(_text(row.get("alias")))}</b><small>{html.escape(_text(row.get("role")))}</small></span>'
            for row in members
        ) or '<span class="muted">No nodes assigned; attribution is informational only.</span>'
        catalog = vlan_catalog_by_id.get(value, {})
        basis = ", ".join(catalog.get("evidence_bases", [])) or "no evidence basis"
        lanes.append(
            f'<article class="topology-lane"><h3>VLAN {value}</h3>'
            f'<p class="muted">Evidence basis: {html.escape(basis)}</p><div>{chips}</div></article>'
        )
    unscoped = [row for row in nodes if not row.get("vlan_ids")]
    if unscoped:
        chips = "".join(
            f'<span class="topology-node topology-node--{html.escape(_text(row.get("role")))}">'
            f'<b>{html.escape(_text(row.get("alias")))}</b><small>{html.escape(_text(row.get("role")))}</small></span>'
            for row in unscoped
        )
        lanes.append(f'<article class="topology-lane"><h3>Untagged / VLAN unknown</h3><div>{chips}</div></article>')

    return (
        '<div class="topology-map">'
        + ("".join(lanes) if lanes else '<p class="muted">No VLAN-linked topology nodes were inferred.</p>')
        + '</div><h3>Mapped nodes</h3>'
        + _table(
            [
                ("alias", "Stable alias"),
                ("role", "Inferred role"),
                ("names_text", "Observed name"),
                ("addresses_text", "IP addresses"),
                ("mac_text", "MAC addresses"),
                ("vlans_text", "VLANs"),
                ("vlan_evidence_text", "VLAN evidence basis"),
                ("vehicle_text", "VIN / vehicle alias"),
                ("evidence", "Inference evidence"),
            ],
            node_rows,
            "No topology nodes inferred",
        )
        + '<h3>Observed relations</h3>'
        + _table(
            [
                ("source_alias", "Node A"),
                ("target_alias", "Node B"),
                ("relation", "Relation"),
                ("protocols_text", "Protocols"),
                ("vlans_text", "VLANs"),
                ("vlan_evidence_text", "VLAN evidence basis"),
                ("ports_text", "Destination ports"),
                ("packets", "Conversation packets"),
                ("bytes", "Conversation bytes"),
                ("sample_packets", "Sampled packets"),
            ],
            edge_rows,
            "No endpoint relations inferred",
        )
    )


def _render_html(report: dict[str, Any], source_id: str | None = None, vlan_id: int | None = None) -> str:
    session = report["session"]
    sources = report["scope"]["sources"]
    if source_id:
        sources = [row for row in sources if row.get("source_id") == source_id]
    source_ids = {row.get("source_id") for row in sources}
    assets = [row for row in report["assets"] if not source_id or set(row.get("sources", [])) & source_ids]
    services = [row for row in report["services"] if not source_id or row.get("source_id") in source_ids]
    findings = [row for row in report["findings"] if not source_id or set(row.get("source_ids", [])) & source_ids]
    analyses = [row for row in report["traffic_analysis"] if not source_id or row.get("source_id") in source_ids]
    attribution_rows = _vlan_attribution_rows(analyses, sources, vlan_id)
    vlan_attribution_banner = _render_vlan_attribution_banner(attribution_rows, vlan_id)
    topology_html = _render_topology_map(report.get("topology", {}), source_ids, vlan_id)
    vlan_service_attribution = True
    vlan_attribution_note = ""
    if vlan_id is not None:
        vlan_service_attribution = any(
            row.get("vlan_id") == vlan_id and row.get("active_scan_attribution") == "yes"
            for row in attribution_rows
        )
        if not vlan_service_attribution:
            assets = []
            services = []
            findings = [
                finding
                for finding in findings
                if any(str(evidence.get("vlan")) == str(vlan_id) for evidence in finding.get("evidence", []))
            ]
            vlan_attribution_note = (
                "This is a traffic-only retained 802.1Q membership view. Active-scan assets, services, findings, "
                "and commands are excluded because source attribution does not establish this VLAN as the scan egress."
            )
    title_suffix = f" — {sources[0].get('alias')}" if source_id and sources else ""
    if vlan_id is not None:
        title_suffix += f" — VLAN {vlan_id}"
    counts = Counter(item.get("severity", "info") for item in findings)

    source_cards = []
    for source in sources:
        interface = source.get("interface", {})
        addresses = ", ".join(f"{row.get('address')}/{row.get('prefix_length')}" for row in interface.get("addresses", [])) or "No L3 address"
        scan_targets = ", ".join(map(str, source.get("targets", []))) or "Not supplied"
        known_target_rows = []
        for row in source.get("known_targets", []):
            if not isinstance(row, dict):
                continue
            detail = str(row.get("address") or "")
            if row.get("ecu_interface"):
                detail += f" via {row['ecu_interface']}"
            if row.get("vlan_id") is not None:
                detail += f" / VLAN {row['vlan_id']}"
            if row.get("prefix_length") is not None:
                detail += f" / reported /{row['prefix_length']}"
            if row.get("prefix_conflict"):
                detail += " / PREFIX CONFLICT — exact-host only"
            known_target_rows.append(detail)
        known_targets = "; ".join(known_target_rows) or "None applied"
        source_cards.append(
            f"""<article class="source-card">
            <h3>{html.escape(_text(source.get('alias')))}</h3>
            <p>{html.escape(_text(interface.get('description') or interface.get('name')))}</p>
            <dl><dt>Role / switch port</dt><dd>{html.escape(_text(source.get('role') or source.get('switch_port')))}</dd>
            <dt>Capture provider</dt><dd>{html.escape(_text(interface.get('provider')))}</dd>
            <dt>Addresses</dt><dd>{html.escape(addresses)}</dd>
            <dt>Expected VLANs</dt><dd>{html.escape(', '.join(map(str, source.get('vlan_ids', []))) or 'Not supplied')}</dd>
            <dt>Validated scan targets</dt><dd>{html.escape(scan_targets)}</dd>
            <dt>Known ECU exact hosts</dt><dd>{html.escape(known_targets)}</dd>
            <dt>Expected ports</dt><dd>{html.escape(', '.join(map(str, source.get('expected_ports', []))) or 'Not supplied')}</dd></dl>
            </article>"""
        )

    analysis_sections = []
    for row in analyses:
        analysis = row.get("analysis") or {}
        if vlan_id is not None:
            vlan_view = next((item for item in row.get("vlan_views", []) if int(item.get("vlan_id", -1)) == vlan_id), None)
            if not vlan_view:
                continue
            analysis = vlan_view.get("analysis") or {}
        protocol_table = _table([("protocol", "Protocol"), ("count", "Packets")], analysis.get("protocols", [])[:25])
        vlan_table = _table(
            [("vlan", "Retained 802.1Q membership"), ("packets", "Packets"), ("bytes", "Bytes")],
            [{"vlan": key, "packets": value.get("packets"), "bytes": value.get("bytes")} for key, value in analysis.get("vlan_partitions", {}).items()],
        )
        auto = analysis.get("automotive", {})
        auto_rows = []
        for category, entries in auto.items():
            for entry in entries[:20]:
                auto_rows.append({"category": category.replace("_", " "), "value": entry.get("value"), "count": entry.get("count")})
        automotive_table = _table([("category", "Category"), ("value", "Decoded value"), ("count", "Packets")], auto_rows, "No supported automotive fields were decoded")
        endpoint_table = _table(
            [("address", "Endpoint"), ("sent_packets", "Sent packets"), ("sent_bytes", "Sent bytes"), ("received_packets", "Received packets"), ("received_bytes", "Received bytes")],
            analysis.get("top_endpoints", [])[:50],
        )
        conversation_table = _table(
            [("protocol", "Protocol"), ("endpoint_a", "Endpoint A"), ("endpoint_b", "Endpoint B"), ("packets", "Packets"), ("bytes", "Bytes")],
            analysis.get("conversations", [])[:75],
        )
        port_table = _table(
            [("transport", "Transport"), ("port", "Destination port"), ("service_guess", "Service guess"), ("packets", "Packets")],
            analysis.get("destination_ports", [])[:75],
        )
        name_rows = (
            [{"type": "DNS query", **item} for item in analysis.get("dns_names", [])[:50]]
            + [{"type": "TLS SNI", **item} for item in analysis.get("tls_server_names", [])[:50]]
            + [{"type": "HTTP Host", **item} for item in analysis.get("http_hosts", [])[:50]]
        )
        name_table = _table([("type", "Type"), ("name", "Name"), ("count", "Packets")], name_rows, "No DNS, TLS SNI, or HTTP host metadata decoded")
        lldp_table = _table([("neighbor", "LLDP neighbor"), ("count", "Packets")], analysis.get("lldp_neighbors", []), "No LLDP neighbors decoded")
        event_rows = [{"event": key.replace("_", " "), "count": value} for key, value in analysis.get("tcp_events", {}).items()]
        event_rows.extend(analysis.get("automotive_expert_events", [])[:100])
        event_table = _table([("event", "Event / field"), ("count", "Count")], event_rows, "No selected transport or automotive expert events decoded")
        vlan_stack_table = _table([("stack", "Tag stack / PCP / DEI"), ("count", "Packets")], analysis.get("vlan_stacks", []), "No retained VLAN tag stacks")
        analysis_sections.append(
            f"""<section><h2>Traffic — {html.escape(_text(row.get('source_alias') or row.get('source_id')))}</h2>
            <div class="metrics"><div><b>{analysis.get('packets', 0):,}</b><span>packets</span></div><div><b>{analysis.get('bytes', 0):,}</b><span>bytes</span></div><div><b>{analysis.get('duration_seconds', 0):.3f}</b><span>seconds</span></div><div><b>{analysis.get('reported_capture_drops', 0):,}</b><span>reported drops</span></div><div><b>{len(analysis.get('vlan_partitions', {}))}</b><span>membership views</span></div></div>
            <h3>Protocol hierarchy</h3>{protocol_table}<h3>Retained 802.1Q membership views</h3>{vlan_table}<p class="muted">These are membership views based on tags retained by the capture API. QinQ frames can appear in more than one VLAN view.</p><h3>Retained 802.1Q tag stacks</h3>{vlan_stack_table}
            <h3>Automotive Ethernet</h3>{automotive_table}<h3>Transport and protocol events</h3>{event_table}
            <h3>Top endpoints</h3>{endpoint_table}<h3>Top conversations</h3>{conversation_table}<h3>Observed destination ports</h3>{port_table}
            <h3>Name and application metadata</h3>{name_table}<h3>LLDP topology observations</h3>{lldp_table}</section>"""
        )

    service_rows = [{**row, "product_version": " ".join(filter(None, (row.get("product"), row.get("version")))), "scripts_text": "; ".join(script.get("id", "") for script in row.get("scripts", []))} for row in services]
    findings_rows = [
        {
            **row,
            "sources_text": ", ".join(row.get("source_ids", [])),
            "cves_text": ", ".join(row.get("cve_ids", [])),
            "topology_text": ", ".join(row.get("topology_aliases", [])),
            "vehicle_context_text": ", ".join(row.get("vehicle_context", [])),
        }
        for row in findings
    ]
    command_rows = [
        row
        for row in report["scope"].get("effective_nmap_commands", [])
        if (not source_id or row.get("source_id") in source_ids) and vlan_service_attribution
    ]
    capture_command_rows = [
        row
        for row in report["scope"].get("capture_commands", [])
        if not source_id or row.get("source_id") in source_ids
    ]
    matrix_analyses = []
    for row in analyses:
        if vlan_id is None:
            matrix_analyses.append(row)
            continue
        vlan_view = next(
            (item for item in row.get("vlan_views", []) if int(item.get("vlan_id", -1)) == vlan_id),
            None,
        )
        if vlan_view:
            matrix_analyses.append({**row, "analysis": vlan_view.get("analysis") or {}, "vlan_views": [vlan_view]})
    visible_packets = sum((row.get("analysis") or {}).get("packets", 0) for row in matrix_analyses)
    if source_id or vlan_id is not None:
        matrix_config = {
            "automotive_mode": session.get("automotive_mode"),
            "capture": report["scope"].get("capture_configuration", {}),
            "scan": report["scope"].get("scan_configuration", {}),
            "sources": sources,
        }
        test_case_rows = evaluate_test_cases(
            matrix_config,
            matrix_analyses,
            services,
            findings,
            captures=capture_command_rows,
            scans=command_rows,
        )
    else:
        test_case_rows = report.get("test_case_matrix", [])
    generated = report.get("generated_at_utc")
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>{html.escape(_text(session.get('name')))}{html.escape(title_suffix)} — NetScope Report</title>
    <style>
    :root{{--ink:#182528;--muted:#607174;--line:#dbe5e3;--paper:#fff;--wash:#f3f7f6;--navy:#0c2c33;--teal:#0b8177;--red:#b2333e;--amber:#b06700}}
    *{{box-sizing:border-box}} body{{margin:0;background:var(--wash);color:var(--ink);font:14px/1.55 Inter,Segoe UI,Arial,sans-serif}} main{{max-width:1160px;margin:0 auto;background:var(--paper);min-height:100vh;padding:48px 54px}} header{{border-bottom:4px solid var(--teal);padding-bottom:26px}} .eyebrow{{letter-spacing:.16em;text-transform:uppercase;color:var(--teal);font-weight:700}} h1{{font-size:34px;line-height:1.15;margin:8px 0}} h2{{font-size:22px;margin:40px 0 14px;border-bottom:1px solid var(--line);padding-bottom:8px}} h3{{font-size:16px;margin:24px 0 8px}} .muted{{color:var(--muted)}} .metrics{{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin:24px 0}} .metrics div{{background:var(--navy);color:white;padding:18px;border-radius:8px}} .metrics b{{font-size:24px;display:block}} .metrics span{{color:#b8d2d1;text-transform:uppercase;font-size:10px;letter-spacing:.1em}} .source-grid{{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}} .source-card{{border:1px solid var(--line);border-radius:8px;padding:18px}} .source-card h3{{margin-top:0}} dl{{display:grid;grid-template-columns:140px 1fr;gap:6px 10px}} dt{{color:var(--muted)}} dd{{margin:0}} .table-wrap{{overflow:auto;border:1px solid var(--line);border-radius:7px}} table{{width:100%;border-collapse:collapse;font-size:12px}} th{{background:#edf4f2;text-align:left;color:#31494c}} th,td{{padding:8px 10px;border-bottom:1px solid var(--line);vertical-align:top}} .severity{{text-transform:uppercase;font-weight:700}} .severity.high,.severity.critical{{color:var(--red)}} .severity.medium{{color:var(--amber)}} .callout{{border-left:4px solid var(--amber);background:#fff6e8;padding:12px 16px;margin:12px 0}} .topology-map{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin:16px 0}} .topology-lane{{border:1px solid var(--line);border-radius:8px;padding:14px;background:#f8fbfa}} .topology-lane h3{{margin:0 0 10px;color:var(--teal)}} .topology-lane>div{{display:flex;flex-wrap:wrap;gap:8px}} .topology-node{{display:inline-flex;flex-direction:column;border:1px solid #9ab7b2;border-radius:7px;padding:7px 10px;background:#fff}} .topology-node small{{color:var(--muted);text-transform:uppercase;font-size:9px}} .topology-node--ecu{{border-color:#0b8177}} .topology-node--switch{{border-color:#b06700}} .topology-node--host{{border-color:#365f9d}} footer{{margin-top:50px;border-top:1px solid var(--line);padding-top:16px;color:var(--muted);font-size:11px}}
    @media print{{body{{background:#fff}}main{{max-width:none;padding:20px}}.table-wrap{{overflow:visible}}}}
    </style></head><body><main>
    <header><div class="eyebrow">NetScope Analyst · evidence report</div><h1>{html.escape(_text(session.get('name')))}{html.escape(title_suffix)}</h1><p class="muted">Session {html.escape(_text(session.get('id')))} · Generated {html.escape(_text(generated))}</p></header>
    {vlan_attribution_banner}
    <section><h2>Executive summary</h2><div class="metrics"><div><b>{len(assets)}</b><span>assets</span></div><div><b>{len([row for row in services if row.get('state') == 'open'])}</b><span>open services</span></div><div><b>{counts['high'] + counts['critical']}</b><span>high / critical</span></div><div><b>{counts['medium']}</b><span>medium</span></div><div><b>{visible_packets:,}</b><span>packets</span></div></div>
    <div class="callout">Open ports and automated protocol observations require validation. They are not automatically confirmed vulnerabilities or unnecessary services.</div></section>
    <section><h2>Scope and topology</h2><p>{html.escape(_text(session.get('topology_notes') or 'No topology notes supplied.'))}</p><div class="source-grid">{''.join(source_cards)}</div></section>
    <section><h2>Tag preservation + VLAN attribution</h2>{_table([('source','Source'),('vlan','VLAN view'),('basis','Attribution basis'),('attribution_scope','Attribution scope'),('confidence','Confidence'),('tag_observed','Tag observed'),('tagged_vs_total','VLAN tagged / total'),('source_tagged_vs_total','All tagged / total'),('tag_assessment','Tag observation'),('active_scan_attribution','Active-scan attribution'),('note','Evidence note')], attribution_rows, 'No analyzed source has VLAN attribution evidence')}</section>
    <section><h2>Local network map</h2><div class="callout">{html.escape(_text(report.get('privacy', {}).get('statement')))}</div>{topology_html}</section>
    {f'<div class="callout">{html.escape(vlan_attribution_note)}</div>' if vlan_attribution_note else ''}
    <section><h2>Assets and services</h2>{_table([('address','Address'),('protocol','Protocol'),('port','Port'),('state','State'),('service','Service'),('product_version','Product / version'),('reason','Reason'),('scripts_text','Scripts')], service_rows, 'No Nmap service data')}</section>
    <section><h2>Findings</h2>{_table([('severity','Severity'),('title','Finding'),('confidence','Confidence'),('status','Status'),('cves_text','CVE IDs'),('sources_text','Sources'),('topology_text','Mapped nodes'),('vehicle_context_text','Vehicle / VIN context'),('description','Evidence interpretation'),('remediation','Recommendation')], findings_rows, 'No automated findings')}</section>
    <section><h2>Eleven-test automotive security coverage</h2>{_table([('id','Test case'),('title','Objective'),('coverage','Coverage'),('status','Scoped status'),('evidence_summary','Evidence summary'),('limitation','Limitation / requirement')], test_case_rows, 'No test-case evaluation')}</section>
    {''.join(analysis_sections)}
    <section><h2>Capture evidence trail</h2>{_table([('source_id','Source'),('capture_id','Capture interface'),('status','Status'),('started_at','Started'),('ended_at','Ended'),('exit_code','Exit'),('size_bytes','Bytes'),('command','Exact command')], capture_command_rows, 'No live capture command was run')}</section>
    <section><h2>Active scan audit trail</h2>{_table([('source_id','Source'),('profile','Profile'),('family','IP family'),('status','Status'),('binding_mode','Vantage binding'),('binding_note','Attribution note'),('started_at','Started'),('ended_at','Ended'),('exit_code','Exit'),('command','Exact command')], command_rows, 'Active scanning was not run')}</section>
    <section><h2>Warnings and incomplete work</h2>{_table([('type','Type'),('message','Message')], [{'type':'warning','message':item} for item in report.get('warnings', [])] + [{'type':'error','message':item} for item in report.get('errors', [])], 'No application warnings or errors')}</section>
    <section><h2>Recommendations</h2><ol>{''.join(f'<li>{html.escape(item)}</li>' for item in report['recommendations'])}</ol></section>
    <section><h2>Limitations</h2><ul>{''.join(f'<li>{html.escape(item)}</li>' for item in report['limitations'])}</ul></section>
    <footer>NetScope Analyst report · Exact commands, raw XML, capture files, and hashes are retained as separate evidence artifacts.</footer>
    </main></body></html>"""


def generate_reports(
    session_dir: Path,
    state: dict[str, Any],
    analyses: list[dict[str, Any]],
    scan_records: list[dict[str, Any]],
    assets: list[dict[str, Any]],
    services: list[dict[str, Any]],
    findings: list[dict[str, Any]],
) -> tuple[dict[str, Any], dict[str, str]]:
    reports_dir = session_dir / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    report = build_report(state, analyses, scan_records, assets, services, findings)
    json_path = reports_dir / "report.json"
    html_path = reports_dir / "report.html"
    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    html_path.write_text(_render_html(report), encoding="utf-8")

    assets_csv = reports_dir / "assets.csv"
    services_csv = reports_dir / "services.csv"
    findings_csv = reports_dir / "findings.csv"
    topology_nodes_csv = reports_dir / "topology-nodes.csv"
    topology_flows_csv = reports_dir / "topology-flows.csv"
    support_diagnostics_path = reports_dir / "support-diagnostics.json"
    report_assets = report.get("assets", [])
    report_services = report.get("services", [])
    report_findings = report.get("findings", [])
    _write_csv(assets_csv, ["id", "primary_address", "mac", "vendor", "hostnames", "status", "sources", "os_matches"], ({**row, "hostnames": "; ".join(row.get("hostnames", [])), "sources": "; ".join(row.get("sources", [])), "os_matches": _text(row.get("os_matches", []))} for row in report_assets))
    _write_csv(services_csv, ["id", "asset_id", "address", "source_id", "protocol", "port", "state", "reason", "service", "product", "version", "extra_info", "method", "confidence", "cpe"], report_services)
    _write_csv(findings_csv, ["id", "severity", "confidence", "status", "category", "title", "cve_ids", "description", "remediation", "source_ids", "asset_ids", "service_ids", "topology_node_ids", "topology_aliases", "vehicle_context"], ({**row, "cve_ids": "; ".join(row.get("cve_ids", [])), "source_ids": "; ".join(row.get("source_ids", [])), "asset_ids": "; ".join(row.get("asset_ids", [])), "service_ids": "; ".join(row.get("service_ids", [])), "topology_node_ids": "; ".join(row.get("topology_node_ids", [])), "topology_aliases": "; ".join(row.get("topology_aliases", [])), "vehicle_context": "; ".join(row.get("vehicle_context", []))} for row in report_findings))
    _write_csv(
        topology_nodes_csv,
        ["id", "alias", "role", "names", "addresses", "mac_addresses", "vlan_ids", "vlan_evidence", "source_ids", "asset_ids", "vehicle_identifiers", "evidence"],
        (
            {
                **row,
                "names": "; ".join(row.get("names", [])),
                "addresses": "; ".join(row.get("addresses", [])),
                "mac_addresses": "; ".join(row.get("mac_addresses", [])),
                "vlan_ids": "; ".join(map(str, row.get("vlan_ids", []))),
                "vlan_evidence": "; ".join(
                    f"VLAN {item.get('vlan_id')}: {', '.join(item.get('bases', []))}"
                    for item in row.get("vlan_evidence", [])
                ),
                "source_ids": "; ".join(row.get("source_ids", [])),
                "asset_ids": "; ".join(row.get("asset_ids", [])),
                "vehicle_identifiers": "; ".join(row.get("observed_vins") or row.get("vehicle_aliases") or []),
                "evidence": "; ".join(row.get("evidence", [])),
            }
            for row in report.get("topology", {}).get("nodes", [])
        ),
    )
    topology_aliases = {
        row.get("id"): row.get("alias")
        for row in report.get("topology", {}).get("nodes", [])
    }
    _write_csv(
        topology_flows_csv,
        ["id", "source", "target", "relation", "source_ids", "vlan_ids", "vlan_evidence", "protocols", "destination_ports", "packets", "bytes", "sample_packets"],
        (
            {
                **row,
                "source": topology_aliases.get(row.get("source"), row.get("source")),
                "target": topology_aliases.get(row.get("target"), row.get("target")),
                "source_ids": "; ".join(row.get("source_ids", [])),
                "vlan_ids": "; ".join(map(str, row.get("vlan_ids", []))),
                "vlan_evidence": "; ".join(
                    f"VLAN {item.get('vlan_id')}: {', '.join(item.get('bases', []))}"
                    for item in row.get("vlan_evidence", [])
                ),
                "protocols": "; ".join(row.get("protocols", [])),
                "destination_ports": "; ".join(map(str, row.get("destination_ports", []))),
            }
            for row in report.get("topology", {}).get("edges", [])
        ),
    )
    support_diagnostics = build_support_diagnostics(
        state,
        analyses,
        scan_records,
        assets,
        services,
        findings,
    )
    support_diagnostics_path.write_text(
        json.dumps(support_diagnostics, indent=2, ensure_ascii=True),
        encoding="utf-8",
    )

    artifacts: dict[str, str] = {
        "report_html": str(html_path),
        "report_json": str(json_path),
        "assets_csv": str(assets_csv),
        "services_csv": str(services_csv),
        "findings_csv": str(findings_csv),
        "topology_nodes_csv": str(topology_nodes_csv),
        "topology_flows_csv": str(topology_flows_csv),
        "support_diagnostics_json": str(support_diagnostics_path),
    }
    for source in report["scope"].get("sources", []):
        source_id = source["source_id"]
        source_path = reports_dir / f"report-{source_id}.html"
        source_path.write_text(_render_html(report, source_id=source_id), encoding="utf-8")
        artifacts[f"report_{source_id}"] = str(source_path)
        analysis_row = next((row for row in report.get("traffic_analysis", []) if row.get("source_id") == source_id), None)
        for vlan_view in (analysis_row or {}).get("vlan_views", []):
            vlan_id = int(vlan_view["vlan_id"])
            vlan_path = reports_dir / f"report-{source_id}-vlan-{vlan_id}.html"
            vlan_path.write_text(_render_html(report, source_id=source_id, vlan_id=vlan_id), encoding="utf-8")
            artifacts[f"report_{source_id}_vlan_{vlan_id}"] = str(vlan_path)

    manifest_path, bundle_path = refresh_evidence_bundle(session_dir)
    artifacts["sha256_manifest"] = str(manifest_path)
    artifacts["evidence_bundle"] = str(bundle_path)
    return report, artifacts


def refresh_evidence_bundle(session_dir: Path) -> tuple[Path, Path]:
    reports_dir = session_dir / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = reports_dir / "sha256-manifest.txt"
    bundle_path = reports_dir / "reports-and-evidence.zip"
    excluded = {manifest_path.resolve(), bundle_path.resolve()}
    evidence_files: list[Path] = [
        path
        for path in (session_dir / "state.json", session_dir / "session-metadata.json", session_dir / "audit.jsonl")
        if path.is_file()
    ]
    for folder in (session_dir / "captures", session_dir / "nmap", session_dir / "analysis", reports_dir):
        if folder.exists():
            evidence_files.extend(path for path in folder.rglob("*") if path.is_file() and path.resolve() not in excluded)
    manifest_lines = []
    for path in sorted(set(evidence_files)):
        relative = path.relative_to(session_dir).as_posix()
        manifest_lines.append(f"{sha256_file(path)}  {relative}")
    manifest_path.write_text("\n".join(manifest_lines) + "\n", encoding="utf-8")

    with zipfile.ZipFile(bundle_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
        bundle.writestr("README.txt", "This bundle excludes packet captures by default because they can be large and contain sensitive payloads. Verify all retained artifacts against sha256-manifest.txt.\n")
        for path in sorted(set(evidence_files + [manifest_path])):
            if path.suffix.lower() in (".pcap", ".pcapng", ".cap", ".blf", ".erf", ".snoop"):
                continue
            bundle.write(path, path.relative_to(session_dir).as_posix())
    return manifest_path, bundle_path
