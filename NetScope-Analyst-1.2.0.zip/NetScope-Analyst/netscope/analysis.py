"""Streaming TShark analysis for general and automotive Ethernet traffic."""

from __future__ import annotations

import hashlib
import json
import socket
import subprocess
import sys
import tempfile
import threading
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Callable, Iterable

from .automotive_fields import (
    SOMEIP_HEURISTIC_SHORT_NAMES,
    deepest_protocol_label,
    flatten_resolved_fields,
    parse_heuristic_registry,
    resolve_semantic_fields,
    someip_heuristic_cli_args,
)
from .privacy import is_valid_vin_value, protect_vin_value
from .tools import CREATE_NO_WINDOW


FIELD_CANDIDATES = [
    "frame.number",
    "frame.time_epoch",
    "frame.len",
    "frame.interface_id",
    "frame.interface_name",
    "frame.interface_description",
    "frame.drop_count",
    "frame.protocols",
    "_ws.col.Protocol",
    "eth.src",
    "eth.dst",
    "eth.type",
    "eth.fcs.status",
    "eth.fcs_bad",
    "vlan.id",
    "vlan.priority",
    "vlan.dei",
    "vlan.etype",
    "vlan.too_many_tags",
    "ip.src",
    "ip.dst",
    "ipv6.src",
    "ipv6.dst",
    "ip.dsfield.dscp",
    "tcp.srcport",
    "tcp.dstport",
    "udp.srcport",
    "udp.dstport",
    "dns.qry.name",
    "tls.handshake.extensions_server_name",
    "http.host",
    "http.request.method",
    "http.request.uri",
    "tcp.flags.syn",
    "tcp.flags.ack",
    "tcp.flags.reset",
    "tcp.analysis.retransmission",
    "tcp.analysis.fast_retransmission",
    "tcp.analysis.zero_window",
    "arp.opcode",
    "icmpv6.type",
    "lldp.chassis.id",
    "lldp.port.id",
    "lldp.system.name",
    "lldp.system.desc",
    "stp.proto",
    "stp.root.hw",
    "stp.bridge.hw",
    "someip.serviceid",
    "someip.methodid",
    "someip.clientid",
    "someip.sessionid",
    "someip.protover",
    "someip.interfaceversion",
    "someip.messagetype",
    "someip.returncode",
    "someipsd.entry.type",
    "someipsd.entry.serviceid",
    "someipsd.entry.instanceid",
    "someipsd.entry.majorver",
    "someipsd.entry.ttl",
    "someipsd.entry.eventgroupid",
    "someipsd.option.ipv4_address",
    "someipsd.option.ipv6_address",
    "someipsd.option.port",
    "doip.payload_type",
    "doip.source_address",
    "doip.target_address",
    "doip.vin",
    "doip.eid",
    "doip.gid",
    "doip.routing_activation_response",
    "uds.sid",
    "uds.reply",
    "uds.err.sid",
    "uds.err.code",
    "ptp.v2.messagetype",
    "ptp.v2.domainnumber",
    "ptp.v2.sequenceid",
    "ptp.v2.clockidentity",
    "ptp.v2.grandmasteridentity",
    "ptp.v2.correction.ns",
    "ptp.v2.flags.twoStep",
    "avtp.stream_id",
    "avtp.subtype",
    "avtp.sequence_num",
    "ieee1722.stream_id",
    "ieee1722.subtype",
    "ieee1722.sequence_num",
    "ieee1722.seqnum",
    "mrp-msrp.stream_id",
    "mrp-msrp.vlan_id",
    "mrp-msrp.priority",
    "ieee8021cb.stream_id",
    "rtag.sequence_number",
]

AUTOMOTIVE_PREFIXES = (
    "someip.",
    "someipsd.",
    "doip.",
    "uds.",
    "ptp.",
    "avtp.",
    "ieee1722.",
    "iec61883.",
    "aaf.",
    "crf.",
    "cvf.",
    "ntscf.",
    "tscf.",
    "mrp-msrp.",
    "mvrp.",
    "ieee8021cb.",
    "rtag.",
    "macsec.",
    "mka.",
)
ANOMALY_TOKENS = (
    "malformed",
    "truncated",
    "overlap",
    "conflict",
    "missing",
    "duplicate",
    "out_of_order",
    "nack",
    "error",
    "illegal",
    "invalid",
    "incorrect",
    "unexpected",
    "wrong",
    "unsupported",
    "unknown",
    "incomplete",
    "too_many",
    ".ooo",
    ".dup",
)
MAX_ENDPOINTS = 100_000
MAX_CONVERSATIONS = 250_000
MAX_PARTITION_ENDPOINTS = 20_000
MAX_METADATA_VALUES = 50_000


def sha256_file(path: Path, block_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(block_size):
            digest.update(block)
    return digest.hexdigest()


def available_tshark_fields(
    tshark_path: str,
    *,
    cancel_event: threading.Event | None = None,
    on_process: Callable[[subprocess.Popen[Any] | None], None] | None = None,
) -> set[str]:
    try:
        proc = subprocess.Popen(
            [tshark_path, "-G", "fields"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=CREATE_NO_WINDOW,
        )
    except OSError:
        return set()
    deadline = time.monotonic() + 30
    stdout = ""
    try:
        if on_process:
            on_process(proc)
        while True:
            try:
                stdout, _ = proc.communicate(timeout=0.5)
                break
            except subprocess.TimeoutExpired:
                if not (cancel_event and cancel_event.is_set()) and time.monotonic() < deadline:
                    continue
                try:
                    proc.terminate()
                except OSError:
                    pass
                try:
                    stdout, _ = proc.communicate(timeout=5)
                except subprocess.TimeoutExpired:
                    try:
                        proc.kill()
                    except OSError:
                        pass
                    stdout, _ = proc.communicate()
                return set()
    finally:
        if proc.poll() is None:
            try:
                proc.kill()
            except OSError:
                pass
        if on_process:
            on_process(None)
    if proc.returncode != 0:
        return set()
    fields: set[str] = set()
    for line in stdout.splitlines():
        parts = line.split("\t")
        if len(parts) >= 3 and parts[0] == "F":
            fields.add(parts[2])
    return fields


def available_tshark_heuristics(
    tshark_path: str,
    *,
    cancel_event: threading.Event | None = None,
    on_process: Callable[[subprocess.Popen[Any] | None], None] | None = None,
) -> set[str]:
    """Return the installed heuristic dissector short names.

    TShark only accepts the exact short name printed by its heuristic registry
    for --enable-heuristic. Treat a failed, cancelled, or timed-out query as
    no available heuristics so analysis can continue with a coverage warning.
    """

    try:
        proc = subprocess.Popen(
            [tshark_path, "-G", "heuristic-decodes"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=CREATE_NO_WINDOW,
        )
    except OSError:
        return set()
    deadline = time.monotonic() + 30
    stdout = ""
    try:
        if on_process:
            on_process(proc)
        while True:
            try:
                stdout, _ = proc.communicate(timeout=0.5)
                break
            except subprocess.TimeoutExpired:
                if not (cancel_event and cancel_event.is_set()) and time.monotonic() < deadline:
                    continue
                try:
                    proc.terminate()
                except OSError:
                    pass
                try:
                    stdout, _ = proc.communicate(timeout=5)
                except subprocess.TimeoutExpired:
                    try:
                        proc.kill()
                    except OSError:
                        pass
                    stdout, _ = proc.communicate()
                return set()
    finally:
        if proc.poll() is None:
            try:
                proc.kill()
            except OSError:
                pass
        if on_process:
            on_process(None)
    if proc.returncode != 0:
        return set()
    return set(parse_heuristic_registry(stdout))


def _terminate_process(proc: subprocess.Popen[Any], timeout: float = 5.0) -> int | None:
    """Bound shutdown waits so cleanup cannot hang application teardown."""
    try:
        return_code = proc.poll()
        if return_code is not None:
            return return_code
    except OSError:
        pass
    try:
        proc.terminate()
    except OSError:
        pass
    try:
        return proc.wait(timeout=timeout)
    except (OSError, subprocess.TimeoutExpired):
        pass
    try:
        proc.kill()
    except OSError:
        pass
    try:
        return proc.wait(timeout=timeout)
    except (OSError, subprocess.TimeoutExpired):
        try:
            return proc.poll()
        except OSError:
            return None


def _cleanup_analysis_process(
    proc: subprocess.Popen[Any] | None,
    stderr_handle: Any,
    on_process: Callable[[subprocess.Popen[Any] | None], None] | None,
    *,
    suppress_errors: bool,
) -> None:
    cleanup_error: BaseException | None = None
    if proc is not None:
        try:
            _terminate_process(proc)
        except BaseException as exc:
            cleanup_error = exc
        try:
            if proc.stdout is not None:
                proc.stdout.close()
        except BaseException as exc:
            if cleanup_error is None:
                cleanup_error = exc
    try:
        stderr_handle.close()
    except BaseException as exc:
        if cleanup_error is None:
            cleanup_error = exc
    if proc is not None and on_process:
        try:
            on_process(None)
        except BaseException as exc:
            if cleanup_error is None:
                cleanup_error = exc
    if cleanup_error is not None and not suppress_errors:
        raise cleanup_error


def _values(value: str) -> list[str]:
    return [item.strip() for item in value.split(",") if item.strip()] if value else []


def _integer(value: str, default: int = 0) -> int:
    try:
        return int(value, 0)
    except (TypeError, ValueError):
        try:
            return int(float(value))
        except (TypeError, ValueError):
            return default


def _service_name(port: int, protocol: str) -> str | None:
    try:
        return socket.getservbyport(port, protocol)
    except OSError:
        return None


def _counter_rows(counter: Counter[str], limit: int = 100, key_name: str = "value") -> list[dict[str, Any]]:
    return [{key_name: key, "count": count} for key, count in counter.most_common(limit)]


def _bounded_increment(counter: Counter[str], key: str, limit: int = MAX_METADATA_VALUES) -> None:
    if not key:
        return
    if key in counter or len(counter) < limit:
        counter[key] += 1
    else:
        counter["<additional values omitted>"] += 1


def _endpoint_rows(endpoints: dict[str, dict[str, int]], limit: int = 100) -> list[dict[str, Any]]:
    rows = [{"address": address, **stats} for address, stats in endpoints.items()]
    rows.sort(key=lambda row: row["sent_bytes"] + row["received_bytes"], reverse=True)
    return rows[:limit]


def _conversation_rows(conversations: dict[tuple[str, ...], dict[str, Any]], limit: int = 200) -> list[dict[str, Any]]:
    rows = []
    for key, stats in conversations.items():
        protocol, endpoint_a, endpoint_b = key
        rows.append({"protocol": protocol, "endpoint_a": endpoint_a, "endpoint_b": endpoint_b, **stats})
    rows.sort(key=lambda row: row["bytes"], reverse=True)
    return rows[:limit]


def _partition() -> dict[str, Any]:
    return {
        "packets": 0,
        "bytes": 0,
        "protocols": Counter(),
        "endpoints": defaultdict(lambda: {"sent_packets": 0, "sent_bytes": 0, "received_packets": 0, "received_bytes": 0}),
        "destination_ports": Counter(),
    }


def _partition_add(partition: dict[str, Any], protocol: str, length: int, src: str, dst: str, transport: str, dst_port: str) -> None:
    partition["packets"] += 1
    partition["bytes"] += length
    partition["protocols"][protocol] += 1
    if src and (src in partition["endpoints"] or len(partition["endpoints"]) < MAX_PARTITION_ENDPOINTS):
        partition["endpoints"][src]["sent_packets"] += 1
        partition["endpoints"][src]["sent_bytes"] += length
    if dst and (dst in partition["endpoints"] or len(partition["endpoints"]) < MAX_PARTITION_ENDPOINTS):
        partition["endpoints"][dst]["received_packets"] += 1
        partition["endpoints"][dst]["received_bytes"] += length
    if transport and dst_port:
        partition["destination_ports"][f"{transport}/{dst_port}"] += 1


def _finalize_partition(partition: dict[str, Any]) -> dict[str, Any]:
    return {
        "packets": partition["packets"],
        "bytes": partition["bytes"],
        "protocols": _counter_rows(partition["protocols"], 50, "protocol"),
        "top_endpoints": _endpoint_rows(partition["endpoints"], 50),
        "destination_ports": _counter_rows(partition["destination_ports"], 50, "port"),
    }


def analyze_capture(
    tshark_path: str,
    capture_path: str | Path,
    packet_sample_limit: int = 1000,
    *,
    include_vin_in_reports: bool = False,
    privacy_context: str = "",
    cancel_event: threading.Event | None = None,
    on_process: Callable[[subprocess.Popen[Any] | None], None] | None = None,
) -> dict[str, Any]:
    path = Path(capture_path)
    all_fields = available_tshark_fields(tshark_path, cancel_event=cancel_event, on_process=on_process)
    if not all_fields:
        raise RuntimeError("Unable to query the installed TShark field registry")
    semantic_fields = resolve_semantic_fields(all_fields)
    selected = [field for field in FIELD_CANDIDATES if field in all_fields]
    for field in flatten_resolved_fields(semantic_fields):
        if field not in selected:
            selected.append(field)
    anomaly_fields = sorted(
        field
        for field in all_fields
        if field.startswith(AUTOMOTIVE_PREFIXES)
        and not field.startswith(("macsec.", "mka."))
        and any(token in field.lower() for token in ANOMALY_TOKENS)
        and field not in selected
    )[:120]
    selected.extend(anomaly_fields)
    if not {"frame.number", "frame.time_epoch", "frame.len"}.issubset(selected):
        raise RuntimeError("The installed TShark did not expose required frame fields")

    heuristic_registry = available_tshark_heuristics(
        tshark_path,
        cancel_event=cancel_event,
        on_process=on_process,
    )
    available_someip_heuristics = tuple(
        name for name in SOMEIP_HEURISTIC_SHORT_NAMES if name in heuristic_registry
    )
    enabled_someip_heuristics = available_someip_heuristics
    argv = [
        tshark_path,
        *someip_heuristic_cli_args(enabled_someip_heuristics),
        "-n",
        "-r",
        str(path),
        "-T",
        "fields",
        "-E",
        "separator=/t",
        "-E",
        "quote=n",
        "-E",
        "occurrence=a",
        "-E",
        "aggregator=,",
    ]
    for field in selected:
        argv.extend(["-e", field])

    stderr_handle = tempfile.TemporaryFile(mode="w+", encoding="utf-8", errors="replace")
    proc: subprocess.Popen[Any] | None = None
    try:
        proc = subprocess.Popen(
            argv,
            stdout=subprocess.PIPE,
            stderr=stderr_handle,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=CREATE_NO_WINDOW,
        )
        if on_process:
            on_process(proc)
        return _consume_tshark_output(
            proc,
            stderr_handle,
            path,
            selected,
            anomaly_fields,
            packet_sample_limit,
            include_vin_in_reports,
            privacy_context or path.parent.parent.name,
            cancel_event,
            semantic_fields=semantic_fields,
            someip_heuristics_available=available_someip_heuristics,
            someip_heuristics_enabled=enabled_someip_heuristics,
        )
    finally:
        _cleanup_analysis_process(
            proc,
            stderr_handle,
            on_process,
            suppress_errors=sys.exc_info()[0] is not None,
        )


def _consume_tshark_output(
    proc: subprocess.Popen[Any],
    stderr_handle: Any,
    path: Path,
    selected: list[str],
    anomaly_fields: list[str],
    packet_sample_limit: int,
    include_vin_in_reports: bool,
    privacy_context: str,
    cancel_event: threading.Event | None,
    *,
    semantic_fields: dict[str, tuple[str, ...]] | None = None,
    someip_heuristics_available: tuple[str, ...] = (),
    someip_heuristics_enabled: tuple[str, ...] = (),
) -> dict[str, Any]:
    assert proc.stdout is not None
    semantic_fields = semantic_fields or resolve_semantic_fields(selected)
    index = {name: position for position, name in enumerate(selected)}
    protocols: Counter[str] = Counter()
    vlan_stacks: Counter[str] = Counter()
    vlan_partitions: dict[str, dict[str, Any]] = defaultdict(_partition)
    endpoints: dict[str, dict[str, int]] = defaultdict(lambda: {"sent_packets": 0, "sent_bytes": 0, "received_packets": 0, "received_bytes": 0})
    conversations: dict[tuple[str, ...], dict[str, Any]] = {}
    destination_ports: Counter[str] = Counter()
    dns_names: Counter[str] = Counter()
    tls_sni: Counter[str] = Counter()
    http_hosts: Counter[str] = Counter()
    lldp_neighbors: Counter[str] = Counter()
    tcp_events: Counter[str] = Counter()
    expert_events: Counter[str] = Counter()
    broadcast_packets = 0
    multicast_packets = 0
    reported_drops = 0
    total_packets = 0
    total_bytes = 0
    first_timestamp: float | None = None
    last_timestamp: float | None = None
    packet_sample: list[dict[str, Any]] = []
    invalid_vin_value_count = 0
    endpoint_overflow_packets = 0
    conversation_overflow_packets = 0
    automotive: dict[str, Any] = {
        "someip_services": Counter(),
        "someip_return_codes": Counter(),
        "someip_sd_services": Counter(),
        "someip_sd_entry_types": Counter(),
        "someip_sd_ipv4_endpoints": Counter(),
        "someip_sd_ipv6_endpoints": Counter(),
        "someip_sd_endpoint_ports": Counter(),
        "doip_payload_types": Counter(),
        "doip_logical_pairs": Counter(),
        "doip_vins": Counter(),
        "uds_services": Counter(),
        "uds_negative_responses": Counter(),
        "ptp_message_types": Counter(),
        "ptp_domains": Counter(),
        "ptp_source_clocks": Counter(),
        "ptp_grandmasters": Counter(),
        "avtp_streams": Counter(),
        "avtp_subtypes": Counter(),
        "avtp_sequence_numbers": Counter(),
        "frer_sequence_numbers": Counter(),
        "macsec_security_channels": Counter(),
        "macsec_security_policy": Counter(),
        "macsec_association_numbers": Counter(),
        "macsec_verification_status": Counter(),
        "mka_participants": Counter(),
        "mka_policy": Counter(),
        "mka_cipher_suites": Counter(),
    }

    def get(row: list[str], name: str) -> str:
        position = index.get(name)
        return row[position] if position is not None and position < len(row) else ""

    def first(row: list[str], *names: str) -> str:
        for name in names:
            value = get(row, name)
            if value:
                return value
        return ""

    def semantic_first(row: list[str], semantic: str) -> str:
        return first(row, *semantic_fields.get(semantic, ()))

    def semantic_all(row: list[str], semantic: str) -> list[str]:
        values: list[str] = []
        for field in semantic_fields.get(semantic, ()):
            values.extend(_values(get(row, field)))
        return values

    for raw_line in proc.stdout:
        if cancel_event and cancel_event.is_set():
            raise RuntimeError("TShark analysis cancelled during application shutdown")
        row = raw_line.rstrip("\r\n").split("\t")
        if len(row) < len(selected):
            row.extend([""] * (len(selected) - len(row)))
        frame_number = _integer(get(row, "frame.number"))
        timestamp_raw = get(row, "frame.time_epoch")
        try:
            timestamp = float(timestamp_raw)
        except ValueError:
            timestamp = 0.0
        length = _integer(get(row, "frame.len"))
        protocol_source = semantic_fields.get("protocol_stack", ("",))[0]
        protocol_value = semantic_first(row, "protocol_stack")
        protocol = deepest_protocol_label(
            protocol_value if protocol_source == "frame.protocols" else "",
            protocol_value if protocol_source != "frame.protocols" else "",
        )
        eth_src, eth_dst = get(row, "eth.src"), get(row, "eth.dst")
        ip_src = get(row, "ip.src") or get(row, "ipv6.src")
        ip_dst = get(row, "ip.dst") or get(row, "ipv6.dst")
        src = ip_src or eth_src
        dst = ip_dst or eth_dst
        tcp_src, tcp_dst = get(row, "tcp.srcport"), get(row, "tcp.dstport")
        udp_src, udp_dst = get(row, "udp.srcport"), get(row, "udp.dstport")
        transport = "tcp" if tcp_src or tcp_dst else ("udp" if udp_src or udp_dst else "")
        src_port, dst_port = (tcp_src, tcp_dst) if transport == "tcp" else ((udp_src, udp_dst) if transport == "udp" else ("", ""))

        total_packets += 1
        total_bytes += length
        reported_drops = max(reported_drops, _integer(get(row, "frame.drop_count")))
        protocols[protocol] += 1
        if timestamp:
            first_timestamp = timestamp if first_timestamp is None else min(first_timestamp, timestamp)
            last_timestamp = timestamp if last_timestamp is None else max(last_timestamp, timestamp)
        if src and (src in endpoints or len(endpoints) < MAX_ENDPOINTS):
            endpoints[src]["sent_packets"] += 1
            endpoints[src]["sent_bytes"] += length
        elif src:
            endpoint_overflow_packets += 1
        if dst and (dst in endpoints or len(endpoints) < MAX_ENDPOINTS):
            endpoints[dst]["received_packets"] += 1
            endpoints[dst]["received_bytes"] += length
        elif dst:
            endpoint_overflow_packets += 1
        if transport and dst_port:
            destination_ports[f"{transport}/{dst_port}"] += 1
        if src and dst:
            left = f"{src}:{src_port}" if src_port else src
            right = f"{dst}:{dst_port}" if dst_port else dst
            endpoint_a, endpoint_b = sorted((left, right))
            key = (transport or protocol, endpoint_a, endpoint_b)
            stats = conversations.get(key)
            if stats is None and len(conversations) < MAX_CONVERSATIONS:
                stats = {"packets": 0, "bytes": 0, "first_timestamp": timestamp, "last_timestamp": timestamp}
                conversations[key] = stats
            if stats is not None:
                stats["packets"] += 1
                stats["bytes"] += length
                if timestamp:
                    stats["first_timestamp"] = min(stats["first_timestamp"] or timestamp, timestamp)
                    stats["last_timestamp"] = max(stats["last_timestamp"] or timestamp, timestamp)
            else:
                conversation_overflow_packets += 1

        destination = eth_dst.replace(":", "").replace("-", "")
        if destination == "ffffffffffff":
            broadcast_packets += 1
        elif len(destination) >= 2:
            try:
                if int(destination[:2], 16) & 1:
                    multicast_packets += 1
            except ValueError:
                pass

        vlan_ids = _values(get(row, "vlan.id"))
        vlan_priorities = _values(get(row, "vlan.priority"))
        vlan_dei = _values(get(row, "vlan.dei"))
        if vlan_ids:
            stack = "/".join(vlan_ids)
            detail = stack
            if vlan_priorities:
                detail += " pcp=" + "/".join(vlan_priorities)
            if vlan_dei:
                detail += " dei=" + "/".join(vlan_dei)
            _bounded_increment(vlan_stacks, detail)
            for vlan_id in set(vlan_ids):
                _partition_add(vlan_partitions[vlan_id], protocol, length, src, dst, transport, dst_port)
        else:
            _partition_add(vlan_partitions["untagged"], protocol, length, src, dst, transport, dst_port)

        for name in _values(get(row, "dns.qry.name")):
            _bounded_increment(dns_names, name)
        for name in _values(get(row, "tls.handshake.extensions_server_name")):
            _bounded_increment(tls_sni, name)
        for name in _values(get(row, "http.host")):
            _bounded_increment(http_hosts, name)
        lldp_key = " | ".join(filter(None, (get(row, "lldp.system.name"), get(row, "lldp.chassis.id"), get(row, "lldp.port.id"))))
        if lldp_key:
            _bounded_increment(lldp_neighbors, lldp_key)
        if get(row, "tcp.flags.reset") in ("1", "True", "true"):
            tcp_events["resets"] += 1
        if get(row, "tcp.analysis.retransmission"):
            tcp_events["retransmissions"] += 1
        if get(row, "tcp.analysis.fast_retransmission"):
            tcp_events["fast_retransmissions"] += 1
        if get(row, "tcp.analysis.zero_window"):
            tcp_events["zero_windows"] += 1
        if get(row, "eth.fcs_bad") in ("1", "True", "true"):
            tcp_events["bad_ethernet_fcs"] += 1
        if get(row, "vlan.too_many_tags"):
            tcp_events["excess_vlan_tag_stack"] += 1
        for field in anomaly_fields:
            value = get(row, field)
            if value:
                _bounded_increment(expert_events, f"{field}={value}")

        someip_service = semantic_first(row, "someip_service_id")
        if someip_service:
            key = f"service={someip_service} method={semantic_first(row, 'someip_method_id') or '?'}"
            _bounded_increment(automotive["someip_services"], key)
        for return_code in semantic_all(row, "someip_return_code"):
            _bounded_increment(automotive["someip_return_codes"], return_code)
        sd_service = semantic_first(row, "someipsd_service_id")
        if sd_service:
            key = f"service={sd_service} instance={semantic_first(row, 'someipsd_instance_id') or '?'}"
            _bounded_increment(automotive["someip_sd_services"], key)
        for entry_type in semantic_all(row, "someipsd_entry_type"):
            _bounded_increment(automotive["someip_sd_entry_types"], entry_type)
        for address in semantic_all(row, "someipsd_ipv4_address"):
            _bounded_increment(automotive["someip_sd_ipv4_endpoints"], address)
        for address in semantic_all(row, "someipsd_ipv6_address"):
            _bounded_increment(automotive["someip_sd_ipv6_endpoints"], address)
        for port in semantic_all(row, "someipsd_endpoint_port"):
            _bounded_increment(automotive["someip_sd_endpoint_ports"], port)

        doip_type = semantic_first(row, "doip_payload_type")
        doip_source = semantic_first(row, "doip_source_address")
        doip_target = semantic_first(row, "doip_target_address")
        if doip_type:
            _bounded_increment(automotive["doip_payload_types"], doip_type)
        if doip_source or doip_target:
            _bounded_increment(
                automotive["doip_logical_pairs"],
                f"{doip_source or '?'} → {doip_target or '?'}",
            )
        raw_vin = semantic_first(row, "doip_vin")
        if raw_vin and not is_valid_vin_value(raw_vin):
            invalid_vin_value_count += 1
        protected_vin = (
            protect_vin_value(raw_vin, privacy_context, include_plaintext=include_vin_in_reports)
            if raw_vin
            else ""
        )
        if protected_vin:
            _bounded_increment(automotive["doip_vins"], protected_vin)
        for uds_service in semantic_all(row, "uds_service_id"):
            _bounded_increment(automotive["uds_services"], uds_service)
        for negative_response in semantic_all(row, "uds_negative_response_code"):
            _bounded_increment(automotive["uds_negative_responses"], negative_response)
        for message_type in semantic_all(row, "ptp_message_type"):
            _bounded_increment(automotive["ptp_message_types"], message_type)
        for domain in semantic_all(row, "ptp_domain"):
            _bounded_increment(automotive["ptp_domains"], domain)
        for source_clock in semantic_all(row, "ptp_source_clock_identity"):
            _bounded_increment(automotive["ptp_source_clocks"], source_clock)
        # Only the Announce-message grandmaster field may populate this
        # counter. A normal PTP source clock is evidence of a participant, not
        # evidence of an additional active grandmaster.
        for grandmaster in semantic_all(row, "ptp_announce_grandmaster_identity"):
            _bounded_increment(automotive["ptp_grandmasters"], grandmaster)
        for stream_id in semantic_all(row, "avtp_stream_id"):
            _bounded_increment(automotive["avtp_streams"], stream_id)
        for avtp_subtype in semantic_all(row, "avtp_subtype"):
            _bounded_increment(automotive["avtp_subtypes"], avtp_subtype)
        for sequence_number in semantic_all(row, "avtp_sequence_number"):
            _bounded_increment(automotive["avtp_sequence_numbers"], sequence_number)
        for sequence_number in semantic_all(row, "frer_sequence_number"):
            _bounded_increment(automotive["frer_sequence_numbers"], sequence_number)

        macsec_system = semantic_first(row, "macsec_sci_system")
        macsec_port = semantic_first(row, "macsec_sci_port")
        if macsec_system or macsec_port:
            _bounded_increment(
                automotive["macsec_security_channels"],
                f"system={macsec_system or '?'} port={macsec_port or '?'}",
            )
        macsec_policy = [
            f"encrypted={semantic_first(row, 'macsec_encrypted')}",
            f"changed_text={semantic_first(row, 'macsec_changed_text')}",
        ]
        if any(not value.endswith("=") for value in macsec_policy):
            _bounded_increment(
                automotive["macsec_security_policy"],
                " ".join(value for value in macsec_policy if not value.endswith("=")),
            )
        for association_number in semantic_all(row, "macsec_association_number"):
            _bounded_increment(automotive["macsec_association_numbers"], association_number)
        for verification in semantic_all(row, "macsec_verification_succeeded"):
            _bounded_increment(automotive["macsec_verification_status"], verification)

        for participant in semantic_all(row, "mka_sci"):
            _bounded_increment(automotive["mka_participants"], participant)
        mka_policy_parts: list[str] = []
        for semantic, label in (
            ("mka_key_server_priority", "key_server_priority"),
            ("mka_is_key_server", "key_server"),
            ("mka_macsec_desired", "macsec_desired"),
            ("mka_macsec_capability", "macsec_capability"),
            ("mka_plain_tx", "plain_tx"),
            ("mka_plain_rx", "plain_rx"),
            ("mka_delay_protect", "delay_protect"),
            ("mka_confidentiality_offset", "confidentiality_offset"),
        ):
            value = semantic_first(row, semantic)
            if value:
                mka_policy_parts.append(f"{label}={value}")
        if mka_policy_parts:
            _bounded_increment(automotive["mka_policy"], " ".join(mka_policy_parts))
        for cipher_suite in semantic_all(row, "mka_cipher_suite"):
            _bounded_increment(automotive["mka_cipher_suites"], cipher_suite)

        if len(packet_sample) < packet_sample_limit:
            packet_sample.append(
                {
                    "frame": frame_number,
                    "timestamp": timestamp,
                    "length": length,
                    "protocol": protocol,
                    "source": src,
                    "destination": dst,
                    "source_port": _integer(src_port) if src_port else None,
                    "destination_port": _integer(dst_port) if dst_port else None,
                    "transport": transport or None,
                    "vlan_stack": vlan_ids,
                    "info": {
                        "dns": get(row, "dns.qry.name") or None,
                        "tls_sni": get(row, "tls.handshake.extensions_server_name") or None,
                        "http_host": get(row, "http.host") or None,
                        "someip_service": someip_service or None,
                        "doip_type": doip_type or None,
                        "doip_vin": protected_vin or None,
                        "uds_sid": semantic_first(row, "uds_service_id") or None,
                    },
                }
            )

    if cancel_event and cancel_event.is_set():
        raise RuntimeError("TShark analysis cancelled during application shutdown")
    try:
        return_code = proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        return_code = _terminate_process(proc)
        if return_code is None:
            raise RuntimeError("TShark analysis process did not exit after its output stream closed")
    stderr_handle.seek(0)
    stderr = stderr_handle.read()
    if cancel_event and cancel_event.is_set():
        raise RuntimeError("TShark analysis cancelled during application shutdown")
    if return_code != 0:
        raise RuntimeError(f"TShark analysis failed ({return_code}): {stderr[-2000:]}")

    duration = max(0.0, (last_timestamp or 0.0) - (first_timestamp or 0.0))
    port_rows = []
    for key, count in destination_ports.most_common(100):
        transport, port_text = key.split("/", 1)
        port = _integer(port_text)
        port_rows.append({"transport": transport, "port": port, "service_guess": _service_name(port, transport), "packets": count})
    automotive_coverage = sorted(field for field in selected if field.startswith(AUTOMOTIVE_PREFIXES))
    analysis_warnings = [stderr.strip()[-2000:]] if stderr.strip() else []
    if invalid_vin_value_count:
        analysis_warnings.append(
            f"{invalid_vin_value_count:,} DoIP VIN field occurrence(s) did not contain a valid "
            "17-character ISO-style VIN. Opaque or invalid values are retained only as "
            "session aliases, even when plaintext VIN inclusion is enabled."
        )
    missing_someip_heuristics = [
        name
        for name in SOMEIP_HEURISTIC_SHORT_NAMES
        if name not in someip_heuristics_available
    ]
    if missing_someip_heuristics:
        analysis_warnings.append(
            "Installed TShark does not expose the following SOME/IP heuristic "
            "dissectors: "
            + ", ".join(missing_someip_heuristics)
            + ". SOME/IP on dynamic ports may remain undecoded."
        )
    disabled_someip_heuristics = [
        name
        for name in someip_heuristics_available
        if name not in someip_heuristics_enabled
    ]
    if disabled_someip_heuristics:
        analysis_warnings.append(
            "Available SOME/IP heuristic dissectors were not enabled: "
            + ", ".join(disabled_someip_heuristics)
            + "."
        )
    result = {
        "capture_file": str(path),
        "capture_size_bytes": path.stat().st_size,
        "sha256": sha256_file(path),
        "packets": total_packets,
        "bytes": total_bytes,
        "first_timestamp": first_timestamp,
        "last_timestamp": last_timestamp,
        "duration_seconds": duration,
        "average_packets_per_second": (total_packets / duration) if duration else 0,
        "average_bits_per_second": (total_bytes * 8 / duration) if duration else 0,
        "protocols": _counter_rows(protocols, 100, "protocol"),
        "top_endpoints": _endpoint_rows(endpoints, 100),
        "conversations": _conversation_rows(conversations, 200),
        "destination_ports": port_rows,
        "vlan_stacks": _counter_rows(vlan_stacks, 100, "stack"),
        "vlan_partitions": {key: _finalize_partition(value) for key, value in sorted(vlan_partitions.items())},
        "broadcast_packets": broadcast_packets,
        "multicast_packets": multicast_packets,
        "reported_capture_drops": reported_drops,
        "dns_names": _counter_rows(dns_names, 100, "name"),
        "tls_server_names": _counter_rows(tls_sni, 100, "name"),
        "http_hosts": _counter_rows(http_hosts, 100, "name"),
        "lldp_neighbors": _counter_rows(lldp_neighbors, 100, "neighbor"),
        "tcp_events": dict(tcp_events),
        "automotive_expert_events": _counter_rows(expert_events, 200, "event"),
        "automotive": {key: _counter_rows(value, 200, "value") for key, value in automotive.items()},
        "automotive_field_coverage": automotive_coverage,
        "tshark_heuristics": {
            "requested": list(SOMEIP_HEURISTIC_SHORT_NAMES),
            "available": list(someip_heuristics_available),
            "enabled": list(someip_heuristics_enabled),
        },
        "packet_sample": packet_sample,
        "analysis_warnings": analysis_warnings,
        "aggregation_limits": {
            "endpoint_overflow_packets": endpoint_overflow_packets,
            "conversation_overflow_packets": conversation_overflow_packets,
            "max_endpoints": MAX_ENDPOINTS,
            "max_conversations": MAX_CONVERSATIONS,
        },
    }
    return result


def split_vlan_capture(
    tshark_path: str,
    source_path: str | Path,
    vlan_id: int,
    output_path: str | Path,
    *,
    cancel_event: threading.Event | None = None,
    on_process: Callable[[subprocess.Popen[Any] | None], None] | None = None,
) -> dict[str, Any]:
    destination = Path(output_path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    stdout_handle = tempfile.TemporaryFile(mode="w+", encoding="utf-8", errors="replace")
    stderr_handle = tempfile.TemporaryFile(mode="w+", encoding="utf-8", errors="replace")
    proc: subprocess.Popen[Any] | None = None
    timed_out = False
    try:
        proc = subprocess.Popen(
            [tshark_path, "-n", "-r", str(source_path), "-Y", f"vlan.id == {vlan_id}", "-w", str(destination)],
            stdin=subprocess.DEVNULL,
            stdout=stdout_handle,
            stderr=stderr_handle,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=CREATE_NO_WINDOW,
        )
        if on_process:
            on_process(proc)
        deadline = time.monotonic() + 3600
        while proc.poll() is None:
            if cancel_event and cancel_event.is_set():
                try:
                    proc.terminate()
                except OSError:
                    pass
                break
            if time.monotonic() >= deadline:
                timed_out = True
                try:
                    proc.terminate()
                except OSError:
                    pass
                break
            time.sleep(0.25)
        try:
            code = proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            code = proc.wait(timeout=5)
        stdout_handle.seek(0)
        stderr_handle.seek(0)
        stdout, stderr = stdout_handle.read(), stderr_handle.read()
    finally:
        if proc is not None and proc.poll() is None:
            proc.kill()
        if on_process:
            on_process(None)
        stdout_handle.close()
        stderr_handle.close()
    if cancel_event and cancel_event.is_set():
        return {"ok": False, "error": "VLAN export cancelled during application shutdown"}
    if timed_out:
        return {"ok": False, "error": "VLAN export exceeded the 3600-second safety timeout"}
    if code != 0:
        return {"ok": False, "error": (stderr or stdout)[-2000:]}
    return {
        "ok": True,
        "path": str(destination),
        "size_bytes": destination.stat().st_size if destination.exists() else 0,
        "sha256": sha256_file(destination) if destination.exists() else None,
    }


def write_analysis_json(path: Path, analysis: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(analysis, indent=2, ensure_ascii=False), encoding="utf-8")
