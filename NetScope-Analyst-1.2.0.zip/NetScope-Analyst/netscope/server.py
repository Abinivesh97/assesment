"""Local HTTP API and static application server."""

from __future__ import annotations

import hmac
import json
import mimetypes
import os
import secrets
import threading
import urllib.parse
import webbrowser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from . import __version__
from .known_targets import preview_known_targets
from .scanner import PROFILE_LABELS
from .session import SessionManager
from .testcases import TEST_CASES
from .validation import ValidationError, clean_text


MAX_JSON_BODY = 1024 * 1024
MAX_IMPORT_BYTES = 32 * 1024 * 1024 * 1024


PROFILE_INFO = {
    "automotive_discovery": {"label": PROFILE_LABELS["automotive_discovery"], "impact": "low", "description": "Host discovery only, with conservative automotive defaults."},
    "host_discovery": {"label": PROFILE_LABELS["host_discovery"], "impact": "low", "description": "ARP/ND and standard Nmap host discovery without a port scan."},
    "quick_tcp": {"label": PROFILE_LABELS["quick_tcp"], "impact": "moderate", "description": "TCP connect scan of Nmap's top 1,000 ports."},
    "standard_tcp": {"label": PROFILE_LABELS["standard_tcp"], "impact": "high", "description": "Top 1,000 TCP ports plus lightweight service/version probes."},
    "full_tcp": {"label": PROFILE_LABELS["full_tcp"], "impact": "high", "description": "All TCP ports 1–65535; port 0 is a separate option."},
    "full_tcp_services": {"label": PROFILE_LABELS["full_tcp_services"], "impact": "very-high", "description": "All TCP ports plus service/version probes on discovered open ports; port 0 is optional."},
    "quick_udp": {"label": PROFILE_LABELS["quick_udp"], "impact": "high", "description": "Top 100 UDP ports; open|filtered is preserved distinctly."},
    "full_udp": {"label": PROFILE_LABELS["full_udp"], "impact": "very-high", "description": "All UDP ports; can take many hours and is bench-only."},
    "service_detection": {"label": PROFILE_LABELS["service_detection"], "impact": "high", "description": "Exhaustive service/version probes against the top 100 TCP ports."},
    "os_detection": {"label": PROFILE_LABELS["os_detection"], "impact": "high", "description": "Heuristic OS fingerprinting; typically needs elevated packet privileges."},
    "safe_enumeration": {"label": PROFILE_LABELS["safe_enumeration"], "impact": "high", "description": "Pinned allowlist of banner, TLS, SSH, SMB, RDP, FTP, HTTP, and DNS checks."},
    "vulnerability_checks": {"label": PROFILE_LABELS["vulnerability_checks"], "impact": "intrusive", "description": "Small pinned NSE allowlist. Results are potential findings, not exploit proof."},
}


def _is_loopback_host(host: str) -> bool:
    return host.lower() in {"127.0.0.1", "localhost"}


def _json_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, default=str).encode("utf-8")


def make_handler(manager: SessionManager, static_dir: Path, api_token: str):
    class NetScopeHandler(BaseHTTPRequestHandler):
        server_version = f"NetScope/{__version__}"

        def _security_headers(self, content_type: str, content_length: int, csp: str | None = None) -> None:
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(content_length))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header(
                "Content-Security-Policy",
                csp
                or "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
                "connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
            )

        def _send_json(self, value: Any, status: int = HTTPStatus.OK) -> None:
            body = _json_bytes(value)
            try:
                self.send_response(status)
                self._security_headers("application/json; charset=utf-8", len(body))
                self.end_headers()
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError):
                return

        def _send_error_json(self, status: int, message: str) -> None:
            self._send_json({"ok": False, "error": message}, status)

        def _host_allowed(self) -> bool:
            host_header = self.headers.get("Host", "").split(":", 1)[0].strip("[]").lower()
            return host_header in {"127.0.0.1", "localhost"}

        def _token_allowed(self) -> bool:
            provided = self.headers.get("X-NetScope-Token", "")
            return bool(provided) and hmac.compare_digest(provided, api_token)

        def _read_json(self) -> dict[str, Any]:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > MAX_JSON_BODY:
                raise ValidationError("Invalid request body size")
            body = self.rfile.read(length)
            if len(body) != length:
                raise ValidationError("Request body ended early")
            try:
                value = json.loads(body)
            except json.JSONDecodeError as exc:
                raise ValidationError("Request body is not valid JSON") from exc
            if not isinstance(value, dict):
                raise ValidationError("Request body must be an object")
            return value

        def _serve_static(self, relative: str) -> None:
            if relative in ("", "/", "index.html"):
                path = static_dir / "index.html"
                body = path.read_text(encoding="utf-8").replace("__NETSCOPE_TOKEN__", api_token).encode("utf-8")
                content_type = "text/html; charset=utf-8"
            else:
                requested = (static_dir / relative.lstrip("/")).resolve()
                if static_dir not in requested.parents or not requested.is_file():
                    self._send_error_json(HTTPStatus.NOT_FOUND, "Not found")
                    return
                body = requested.read_bytes()
                content_type = mimetypes.guess_type(requested.name)[0] or "application/octet-stream"
                if content_type.startswith("text/") or content_type in ("application/javascript", "application/json"):
                    content_type += "; charset=utf-8"
            self.send_response(HTTPStatus.OK)
            self._security_headers(content_type, len(body))
            self.end_headers()
            self.wfile.write(body)

        def _serve_artifact(self, session_id: str, artifact_key: str) -> None:
            try:
                path = manager.artifact_path(session_id, artifact_key)
            except KeyError as exc:
                self._send_error_json(HTTPStatus.NOT_FOUND, str(exc))
                return
            content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
            disposition = "inline" if path.suffix.lower() in (".html", ".json", ".txt", ".csv") else "attachment"
            stat = path.stat()
            self.send_response(HTTPStatus.OK)
            artifact_csp = (
                "default-src 'none'; style-src 'unsafe-inline'; img-src data:; object-src 'none'; "
                "frame-ancestors 'none'; base-uri 'none'; form-action 'none'"
                if path.suffix.lower() == ".html"
                else None
            )
            self._security_headers(content_type, stat.st_size, artifact_csp)
            safe_name = path.name.replace(chr(34), "")
            self.send_header("Content-Disposition", f"{disposition}; filename=\"{safe_name}\"")
            self.end_headers()
            with path.open("rb") as handle:
                while block := handle.read(1024 * 1024):
                    self.wfile.write(block)

        def do_GET(self) -> None:  # noqa: N802
            if not self._host_allowed():
                self._send_error_json(HTTPStatus.FORBIDDEN, "Host header rejected")
                return
            parsed = urllib.parse.urlparse(self.path)
            path = parsed.path.rstrip("/") or "/"
            try:
                if path == "/api/health":
                    self._send_json({"ok": True, "version": __version__})
                elif path == "/api/system":
                    self._send_json({"ok": True, "system": manager.system, "profiles": PROFILE_INFO})
                elif path == "/api/interfaces":
                    self._send_json({"ok": True, "interfaces": manager.interfaces()})
                elif path == "/api/test-cases":
                    self._send_json({"ok": True, "test_cases": TEST_CASES})
                elif path == "/api/sessions":
                    self._send_json({"ok": True, "sessions": manager.list_sessions()})
                elif path.startswith("/api/sessions/"):
                    parts = path.split("/")
                    if len(parts) == 5 and parts[4] == "artifact":
                        self._send_error_json(HTTPStatus.BAD_REQUEST, "Artifact key is missing")
                    elif len(parts) == 6 and parts[4] == "artifact":
                        self._serve_artifact(parts[3], urllib.parse.unquote(parts[5]))
                    elif len(parts) == 4:
                        self._send_json({"ok": True, "session": manager.get_session(parts[3])})
                    else:
                        self._send_error_json(HTTPStatus.NOT_FOUND, "Not found")
                elif path == "/":
                    self._serve_static("index.html")
                elif path.startswith("/static/"):
                    self._serve_static(path[len("/static/") :])
                else:
                    self._serve_static(path)
            except KeyError as exc:
                self._send_error_json(HTTPStatus.NOT_FOUND, str(exc))
            except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError):
                return
            except (OSError, ValueError) as exc:
                self._send_error_json(HTTPStatus.INTERNAL_SERVER_ERROR, str(exc))

        def do_POST(self) -> None:  # noqa: N802
            if not self._host_allowed():
                self._send_error_json(HTTPStatus.FORBIDDEN, "Host header rejected")
                return
            if not self._token_allowed():
                self._send_error_json(HTTPStatus.FORBIDDEN, "Request token rejected")
                return
            path = urllib.parse.urlparse(self.path).path.rstrip("/")
            try:
                if path == "/api/sessions":
                    state = manager.start_session(self._read_json())
                    self._send_json({"ok": True, "session": state}, HTTPStatus.CREATED)
                elif path == "/api/plan":
                    plan = manager.plan_session(self._read_json())
                    self._send_json({"ok": True, "plan": plan})
                elif path == "/api/known-targets/preview":
                    preview = preview_known_targets(self._read_json())
                    self._send_json({"ok": True, "preview": preview})
                elif path == "/api/system/refresh":
                    self._read_json()
                    self._send_json({"ok": True, "system": manager.refresh_system()})
                elif path == "/api/import":
                    self._handle_import()
                elif path.startswith("/api/sessions/"):
                    parts = path.split("/")
                    if len(parts) != 5:
                        self._send_error_json(HTTPStatus.NOT_FOUND, "Not found")
                    elif parts[4] == "stop-capture":
                        self._read_json()
                        self._send_json({"ok": True, "session": manager.stop_capture(parts[3])})
                    elif parts[4] == "cancel-scans":
                        self._read_json()
                        self._send_json({"ok": True, "session": manager.cancel_scans(parts[3])})
                    else:
                        self._send_error_json(HTTPStatus.NOT_FOUND, "Not found")
                else:
                    self._send_error_json(HTTPStatus.NOT_FOUND, "Not found")
            except ValidationError as exc:
                self._send_error_json(HTTPStatus.BAD_REQUEST, str(exc))
            except KeyError as exc:
                self._send_error_json(HTTPStatus.NOT_FOUND, str(exc))
            except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError):
                return
            except (OSError, ValueError) as exc:
                self._send_error_json(HTTPStatus.INTERNAL_SERVER_ERROR, str(exc))

        def _handle_import(self) -> None:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > MAX_IMPORT_BYTES:
                raise ValidationError("Invalid or oversized capture upload")
            filename = clean_text(urllib.parse.unquote(self.headers.get("X-NetScope-Filename", "")), 240)
            if not filename:
                raise ValidationError("Capture filename is missing")
            metadata_header = self.headers.get("X-NetScope-Metadata", "")
            try:
                metadata = json.loads(urllib.parse.unquote(metadata_header)) if metadata_header else {}
            except json.JSONDecodeError as exc:
                raise ValidationError("Import metadata is invalid") from exc
            if not isinstance(metadata, dict):
                raise ValidationError("Import metadata must be an object")
            incoming_dir = manager.data_dir / "incoming"
            incoming_dir.mkdir(parents=True, exist_ok=True)
            temporary = incoming_dir / f"{secrets.token_hex(16)}.upload"
            remaining = length
            preserve_temporary = False
            try:
                with temporary.open("wb") as handle:
                    while remaining:
                        block = self.rfile.read(min(1024 * 1024, remaining))
                        if not block:
                            raise ValidationError("Capture upload ended early")
                        handle.write(block)
                        remaining -= len(block)
                try:
                    state = manager.import_capture(temporary, filename, metadata)
                except ValidationError:
                    raise
                except Exception as exc:
                    preserve_temporary = True
                    if temporary.exists():
                        recovery = temporary.with_suffix(".failed-upload")
                        try:
                            os.replace(temporary, recovery)
                        except OSError:
                            recovery = temporary
                        recovery_note = f"; uploaded capture preserved at {recovery}"
                    else:
                        recovery_note = "; inspect the session data directory for capture evidence retained during rollback"
                    raise OSError(f"{exc}{recovery_note}") from exc
            finally:
                if temporary.exists() and not preserve_temporary:
                    temporary.unlink()
            self._send_json({"ok": True, "session": state}, HTTPStatus.CREATED)

        def log_message(self, format: str, *args: Any) -> None:
            print(f"[NetScope] {self.address_string()} - {format % args}")

    return NetScopeHandler


def run_server(
    host: str,
    port: int,
    data_dir: str | Path,
    *,
    open_browser: bool = True,
) -> None:
    if not _is_loopback_host(host):
        raise SystemExit("NetScope is intentionally local-only; bind to 127.0.0.1 or localhost")
    static_dir = Path(__file__).resolve().parent.parent / "static"
    if not (static_dir / "index.html").is_file():
        raise SystemExit(f"Static application files are missing: {static_dir}")
    manager = SessionManager(data_dir)
    api_token = secrets.token_urlsafe(32)
    handler = make_handler(manager, static_dir, api_token)
    server = ThreadingHTTPServer((host, port), handler)
    server.daemon_threads = True
    url = f"http://{host}:{server.server_address[1]}"
    print(f"NetScope Analyst {__version__} is running at {url}")
    print("Press Ctrl+C to stop. Session evidence remains in:", manager.data_dir)
    if open_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        print("\nStopping NetScope Analyst…")
    finally:
        server.shutdown()
        try:
            manager.shutdown()
        finally:
            server.server_close()
