# NetScope Analyst

NetScope Analyst is a local, Windows-first workbench for simultaneous packet capture and authorized network enumeration. It is designed for ordinary Ethernet/Wi-Fi/VLAN adapters and automotive Ethernet test setups, including Vector VN5620 workflows when the channel is visible to Wireshark/Npcap or when a recording is exported from Vector tooling.

Current release: **1.2.0**.

## What it covers

- Select one or many capture interfaces, with IPv4/IPv6, MAC, link state, speed, MTU, VLAN, and capture/scan readiness.
- Capture all selected sources concurrently into separate PCAPNG evidence files.
- Produce per-interface analysis plus evidence-qualified VLAN views: retained 802.1Q membership is kept separate from configured logical VLAN attribution.
- Set duration, packet/file-size guardrails, snap length, promiscuous mode, and a BPF capture filter.
- Analyze protocols, endpoints, conversations, ports, DNS, TLS SNI, HTTP metadata, TCP resets/retransmissions, VLANs, and packet metadata without storing payloads in the report.
- Decode supported automotive Ethernet metadata exposed by the installed TShark version, including SOME/IP, SOME/IP-SD, DoIP, UDS, VLAN priority, and PTP/gPTP fields. NetScope discovers and enables the installed, allowlisted SOME/IP UDP/TCP heuristic dissectors and records any coverage limitation.
- Optionally run multiple, explicitly scoped Nmap profiles during capture, split by interface and IP family.
- Use either a full TCP port inventory or the separate full TCP plus service/version profile when detailed identification across ports 1–65535 is required; port 0 remains a separate opt-in.
- Parse Nmap XML into hosts, ports, states, services, versions, operating-system guesses, and script evidence.
- Flag risky exposure, cleartext protocols, curated script observations, and ports outside an operator-defined allowlist. Findings are labeled with confidence and are not presented as confirmed vulnerabilities without evidence.
- Generate a combined HTML/JSON report, per-source reports, CSV tables, raw Nmap output, PCAPNG evidence, and SHA-256 manifests.
- Build a local network map from observed IP, MAC, VLAN, protocol, flow, LLDP, and asset relationships, with stable per-session node aliases and CSV exports.

## Release 1.2.0 behavior

### VIN handling and finding correlation

The **Include observed DoIP VINs in local reports** option is off by default. With the option off, VIN-like values are replaced by session-scoped pseudonyms before derived analysis, topology, and report artifacts are persisted. With the option on, only a valid, printable 17-character ISO-style DoIP VIN may appear in those local derived artifacts and in the dedicated vehicle/VIN report context. Opaque, non-printable, or invalid DoIP vehicle identifiers remain session aliases and produce a coverage warning instead of being labeled as VINs; current releases never infer a VIN from opaque bytes. A finding receives plaintext VIN context only when the evidence maps it to the exact asset or topology node; a source-only or interface-level finding does not inherit a VIN. A VIN identifies vehicle context and is never itself reported as a vulnerability.

This option does not rewrite or redact raw PCAP/PCAPNG or other raw evidence. Treat the complete session as confidential regardless of the option.

### VLAN attribution and retained tags

Every per-VLAN view states its evidence basis. A retained 802.1Q header is observed capture evidence and can support an `observed-8021q` view. QinQ frames can belong to more than one such membership view, so these are membership sets rather than mutually exclusive packet partitions.

An operating-system VLAN interface can receive untagged frames because the adapter, driver, VLAN offload, or measurement provider removed the tag before the capture API. When a source has exactly one configured VLAN and no conflicting retained tag, NetScope can attribute the complete source logically with medium confidence as `configured-source`; this is not proof that the frame carried that tag on the wire. If a source has multiple configured VLANs, or configured and observed evidence conflicts, untagged traffic is marked `unattributable` and is not assigned by guesswork. Reports include a tag-preservation summary and the attribution basis so logical configuration is never presented as observed wire evidence.

### Exact pre-start review

Opening the launch review performs a local dry run of the same validation used to start an assessment. It does not start capture or Nmap and does not create an assessment session. The resulting plan contains the validated source plan, exact Nmap job count, target-address and profile/address attempt counts, per-source targets, manual and automatic exclusions, binding mode, and route proof. Review this plan before confirming an active assessment; it is a snapshot, so the immediate pre-launch check described below still applies.

### Known ECU targets from ifconfig

The active-enumeration panel can parse pasted ECU `ifconfig`-style text into a preview of exact unicast host addresses. The parser is pure text: it never invokes a shell, never starts a scan, ignores MAC addresses, and discards the raw paste after the preview response. Only rows explicitly applied by the operator become sanitized source configuration and report provenance.

VLAN candidates are auto-mapped only when exactly one selected source has the matching configured VLAN ID. Ambiguous, untagged, or unmatched rows remain unchecked until an eligible source is explicitly selected. ECU-scoped IPv6 link-local values are skipped because an ECU zone name is not a valid Windows egress zone. Loopback, multicast, unspecified, network, and broadcast addresses are never proposed as targets.

The safe default replaces affected source target lists with selected host literals; merge mode is explicit and may retain broader existing CIDRs. Duplicate exact hosts are removed. Non-RFC1918/ULA addresses still require **Allow non-local scope**, which is never enabled automatically. The same target, direct-route, interface-binding, PC/default-gateway exclusion, overlap, and immediate pre-start checks apply unchanged. If a known ECU address collides with a protected PC, gateway, or manual exclusion, planning fails rather than silently skipping it or relaxing protection.

FreeBSD/QNX hexadecimal netmasks, dotted IPv4 masks, and prefix lengths are normalized only as provenance. NetScope never expands them into scan subnets. If the same VLAN/family is reported with conflicting prefixes or networks, the preview prominently records `prefix-conflict; exact-host only; subnet expansion prohibited`; selected individual host literals may still proceed only if all normal route and scope checks pass.

### SOME/IP heuristic coverage

NetScope queries the installed TShark heuristic registry and enables only the exact supported `someip_udp_heur` and `someip_tcp_heur` names. It also resolves supported current and legacy automotive field names. The analysis records which heuristics were requested, available, and enabled, and emits a coverage warning when the installed Wireshark/TShark cannot provide one. Heuristic decoding improves discovery of SOME/IP and SOME/IP-SD carried on non-default ports, but decoded metadata remains protocol evidence rather than automatic proof of a vulnerability.

## Evidence and chain of custody

Each assessment gets its own UUID session directory. NetScope records the immutable launch configuration and tool inventory, separate raw capture and capture-stderr files for every selected source, exact Nmap argument arrays and their XML/text/stderr results, parsed analysis JSON, per-source and attributable per-VLAN reports, timestamps, process exit states, warnings, and errors. Failed work remains visible as evidence instead of being silently discarded.

Every lifecycle transition is appended to `audit.jsonl` with a timestamp and a SHA-256 link to the previous audit entry. `sha256-manifest.txt` hashes the raw captures and every evidence file listed in it; the manifest and ZIP cannot hash themselves. The downloadable evidence ZIP contains reports, audit data, manifests, and scan output but intentionally does not duplicate large raw captures; collect the ZIP together with the separately listed PCAP/PCAPNG files. Files are not automatically deleted. The hash chain is tamper-evident, not a digital signature, so copy completed evidence to your controlled case repository and apply your normal access, retention, signing, and time-source procedures.

Observed DoIP VINs are pseudonymized in derived analysis, reports, and topology exports by default. A per-session, default-off option can retain a valid 17-character ISO-style VIN in local derived artifacts when identity correlation is explicitly required; opaque or invalid values remain aliases. Plaintext VIN context is correlated only to findings mapped to the exact asset or topology node. VINs are identity evidence, never vulnerability findings. Raw packet captures and raw scanner evidence are not redacted and must remain under the bench evidence-handling policy.

`support-diagnostics.json` is a separately downloadable, strictly allowlisted troubleshooting summary. It uses `SOURCE_1...` aliases, coarse status/enumeration values, sanitized numeric tool versions, and aggregate counts. It deliberately omits VINs and vehicle aliases, IP/MAC/host identifiers, VLAN IDs, ports and services, targets and route details, commands and paths, packet samples, timestamps, hashes, UUIDs, and raw warning/error text. It is the only artifact designed for privacy-minimized support, is labeled redacted, and must still be reviewed before sharing. That label does not apply to reports, raw captures, scan output, or the evidence ZIP.

Verify a completed or failed session without changing its evidence:

```powershell
python .\verify_evidence.py .\data\sessions\<session-uuid>
```

## Eleven automotive Ethernet test cases

The dashboard and report track all eleven IDs, but they are not all equivalent or safe to automate from a general network workbench.

| ID | Coverage in NetScope Analyst |
|---|---|
| Eth_TC_001 | Automated evidence for HTTP versus HTTPS/TLS observations and relevant services; absence remains inconclusive. |
| Eth_TC_002 | Automated open-port inventory, full TCP/UDP options, optional port 0, expected-port baseline, and risk review. |
| Eth_TC_003 | Automated service/version inventory and curated enumeration; version findings require validation against the actual ECU build. |
| Eth_TC_004 | Tracked as requiring ECU/gateway firewall configuration or host access; packet behavior alone cannot prove the installed ruleset. |
| Eth_TC_005 | Not launched automatically. An explicitly authorized, isolated MITM harness is required; NetScope can preserve before/during/after captures. |
| Eth_TC_006 | Automated authorized sniffing/capture evidence, subject to TAP/SPAN/Vector visibility and capture-drop limitations. |
| Eth_TC_007 | Not launched automatically. Replay needs a protocol-aware stationary-bench harness, timing controls, and a recoverable ECU state. |
| Eth_TC_008 | Not launched automatically. Tampering/injection needs an explicitly authorized protocol-aware harness and safety interlocks. |
| Eth_TC_009 | Not launched automatically. Fuzzing needs target-specific state monitoring, reset/recovery, rate control, and an approved corpus. |
| Eth_TC_010 | Partial automation for TLS services, cipher/certificate checks, and visible MACsec/MKA metadata; key management and endpoint crypto configuration need separate evidence. |
| Eth_TC_011 | Automated VLAN/tag-stack and cleartext/encrypted-protocol observations with per-VLAN traffic reports; encryption cannot be inferred merely from the presence of a VLAN. |

Statuses distinguish evidence collected, partial evidence, not observed, incomplete execution, manual input required, and not run. A test is never marked complete merely because its feature was enabled.

## Requirements

1. Windows 10/11 or Linux/macOS with Python 3.11+.
2. Wireshark with **TShark** and **Dumpcap**. On Windows, install Npcap during Wireshark setup.
3. Nmap for optional active enumeration.
4. Capture privileges for Dumpcap/Npcap. Run only the capture helper with the required privilege; do not expose this web UI to an untrusted network.

The application searches `PATH` and common Windows installation directories. You can also set `NETSCOPE_TSHARK`, `NETSCOPE_DUMPCAP`, `NETSCOPE_CAPINFOS`, `NETSCOPE_EDITCAP`, and `NETSCOPE_NMAP` to absolute executable paths.

## Start

Double-click `start.cmd`, or run:

```powershell
.\start.ps1
```

The UI opens at <http://127.0.0.1:8765>. Python packages are not required.

### If every interface is greyed out

Packet capture is enabled by default. Grey interface cards mean the adapter is not currently exposed to TShark/Dumpcap; they do not mean Windows failed to detect the adapter. Install Wireshark with TShark, Dumpcap, and Npcap enabled, restart NetScope, and click **Run preflight**. For Nmap-only work, use **Switch to Nmap-only** in the interface notice; the **Select scan-ready** action then uses routable adapters.

## VN5620 and automotive Ethernet notes

- If the Vector channel appears in `tshark -D` (directly, through Npcap, or through an installed extcap provider), NetScope can capture it.
- A Vector measurement channel is not automatically a Windows IP interface. Nmap needs an OS-routable adapter and a valid source route; capture-only channels remain available for passive analysis.
- IPv6 link-local targets are accepted one address at a time and are automatically given the selected Windows interface index when interface binding is enabled. Global/ULA IPv6 literals and approved CIDRs are handled normally.
- If direct capture is unavailable, export PCAP/PCAPNG/BLF from CANoe/CANalyzer or another Vector workflow and use the offline import in NetScope. BLF support depends on the installed Wireshark version.
- On a switched network, a normal endpoint sees only traffic delivered to it plus broadcast/multicast. Use an authorized mirror/SPAN port, TAP, or the correct Vector measurement topology for full-segment visibility.
- VLAN offload can remove 802.1Q headers before capture. Capturing a physical trunk plus OS VLAN subinterfaces can also duplicate packets.
- Automotive mode defaults to passive capture. Active scans can disturb ECUs, gateways, diagnostics, or timing-sensitive traffic. Use narrow targets, low rates, and a bench/test network.

## Scan safety model

- Active scanning is off by default and requires an authorization acknowledgement.
- Only literal IP addresses/CIDRs are accepted; Nmap option injection and DNS scope changes are avoided.
- Pasted ECU interface inventories can contribute only explicitly reviewed exact host literals. Raw pasted text is not retained, and reported masks are never used to enlarge scope.
- Multicast, unspecified addresses, `/0`, and oversized scopes are rejected.
- Every local interface address and default gateway discovered during planning is automatically added to the relevant scan exclusions, in addition to operator exclusions. A scope that is fully protected is rejected instead of scanning the workstation or gateway.
- On Windows, an automotive interface-bound plan requires a positively connected, scan-ready adapter, an Nmap interface mapping, a directly connected target prefix, and no equal-or-more-specific competing route. Immediately before every such Nmap job starts, NetScope re-queries interface, route, Nmap mapping, host-address, and gateway state; any unavailable or changed proof fails closed and the job is retained as failed evidence without launching Nmap.
- Public targets, scopes above 4,096 addresses, full TCP/UDP, service probes, OS detection, and curated NSE checks require explicit opt-in.
- Commands are executed as argument arrays without a shell. Exact arguments, timestamps, exit codes, XML, and stderr are retained.
- The web service binds to localhost and mutating requests require a per-process token.

## Interpretation limits

An open port is attack surface, not automatically a vulnerability. A service banner can be wrong, and vendors can backport fixes without changing the advertised version. Nmap scripts and Wireshark expert observations are evidence to investigate, not exploit proof. “Unnecessary” is only meaningful against the expected-port baseline supplied for that asset or interface. Encrypted traffic limits passive application inspection, and a network-only assessment cannot prove patch state, authentication policy, or host configuration.

Use this application only on systems and networks you own or are explicitly authorized to assess.
